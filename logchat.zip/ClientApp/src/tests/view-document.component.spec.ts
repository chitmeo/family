import {
  ChangeDetectorRef,
  NgZone,
  NO_ERRORS_SCHEMA,
  Renderer2,
} from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { WebViewerInstance } from '@pdftron/webviewer';
import {
  AuthenticationService,
  SpinnerService,
  TitleService,
} from '@wilson/wilsonng';
import { of } from 'rxjs';
import { CommunityApiService } from 'src/app/services/community-api.service';
import { InitialLoadService } from 'src/app/services/initial-load.service';
import { SessionService } from 'src/app/services/session.service';

import { ViewDocumentComponent } from '../app/components/view-document/view-document.component';
import { DocumentService } from '../app/services/document.service';
import { MockData } from './mockdata';
import { Wilson } from '../def/Wilson';
import InitialLoad = Wilson.InitialLoad;

describe('ViewDocumentComponent', () => {
  let component: ViewDocumentComponent;
  let fixture: ComponentFixture<ViewDocumentComponent>;
  let mockRouter: any;
  let mockRoute: any;
  let mockDocumentService: any;
  let mockTitleService: any;
  let mockSpinnerService: any;
  let mockSessionService: any;
  let mockCommunityService: Partial<CommunityApiService>;
  let fake: MockData;
  let mockInitialLoadService: Partial<InitialLoadService>;
  let mockAuthenticationService: Partial<AuthenticationService>;
  let mockRenderer: Renderer2;

  let mockChangeDetectorRef: any;

  beforeAll(() => {
    // on slower machines, some tests in this component take longer than
    // jasmine's default (5 seconds). Hence the temporary timeout override here.
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
  });

  afterAll(() => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 5000;
  });

  beforeEach(async () => {
    loadMockData();
    loadMockServices();
    setupTestBed();
    await setupComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should handle xsite properly', async () => {
    spyOn(component, 'getXSiteParams').and.callThrough();
    component.isXSite = true;
    component.currentDocumentId = 1;
    await component.ngAfterViewInit();
    component.documentGroup.documents = [];
    component.setupBreadcrumbs();
    expect(component.getXSiteParams).toHaveBeenCalled();
  });

  it('should set list open to be false when initialize is called with no documents', async () => {
    component.currentDocumentId = 1;
    await component.ngAfterViewInit();
    component.documentGroup.documents = [];
    component.initialize();
    expect(component.listOpen).toBeFalse();
  });

  it('should find the current page in attachments array and fetch video data', async () => {
    component.attachments = fake.pagesWithAttachments;
    component.getPageWithAttachments(1).subscribe((documentPage) => {
      expect(documentPage).toEqual(fake.pagesWithAttachments[0]);
      expect(mockCommunityService.getVideos).toHaveBeenCalled();
    });
  });

  it('should return undefined when trying to fetch video data of page that doesnt exist in attachments array', async () => {
    component.currentDocumentId = 1;
    await component.ngAfterViewInit();
    component.getPageWithAttachments(0).subscribe((documentPage) => {
      expect(documentPage).toBe(undefined);
      expect(mockCommunityService.getVideos).not.toHaveBeenCalled();
    });
  });

  it('should update the attachments and fetch the page number when document is loaded', async () => {
    component.currentDocumentId = 1;
    await component.ngAfterViewInit();
    component.attachments = fake.pagesWithAttachments;
    component.onPageNumberUpdated(null);
    const zone = TestBed.inject(NgZone);
    spyOn(zone, 'run').and.callFake((fn) => fn());

    await component.wvInstance.Core.PDFNet.initialize();
    component.currentDocumentPage.subscribe((page) => {
      expect(page).toBe(fake.pagesWithAttachments[0]);
    });
    expect(mockCommunityService.getVideos).toHaveBeenCalled();
  });

  it('should update the attachments when page number is updated', async () => {
    spyOn(component, 'getCurrentDocument').and.returnValue(
      fake.documentGroup.documents[0]
    );
    component.attachments = fake.pagesWithAttachments;
    const zone = TestBed.inject(NgZone);
    spyOn(zone, 'run').and.callFake((fn) => fn());
    component.onPageNumberUpdated(1);
    component.currentDocumentPage.subscribe((page) => {
      expect(page).toBe(fake.pagesWithAttachments[0]);
    });
    expect(mockCommunityService.getVideos).toHaveBeenCalled();
  });

  it('should dynamically hide and show certain buttons', async () => {
    const zone = TestBed.inject(NgZone);
    spyOn(zone, 'run');
    const doc = fake.documentGroup.documents[0];
    spyOn(component, 'getCurrentDocument').and.returnValue(
      fake.documentGroup.documents[0]
    );
    component.attachments = fake.pagesWithAttachments;

    // Show both Print and Save
    doc.allowPrint = true;
    doc.allowSave = true;
    component.onPageNumberUpdated(1);
    expect(component.wvInstance.UI.hotkeys.on).toHaveBeenCalled();
    expect(component.wvInstance.UI.enableElements).toHaveBeenCalledWith([
      'customPrintButton',
      'customDownloadButton',
    ]);
    expect(component.wvInstance.UI.disableElements).toHaveBeenCalledWith([]);

    // Show only Print
    doc.allowSave = false;
    component.onPageNumberUpdated(1);
    expect(component.wvInstance.UI.hotkeys.on).toHaveBeenCalled();
    expect(component.wvInstance.UI.enableElements).toHaveBeenCalledWith([
      'customPrintButton',
    ]);
    expect(component.wvInstance.UI.disableElements).toHaveBeenCalledWith([
      'customDownloadButton',
    ]);

    // Show only Save
    doc.allowPrint = false;
    doc.allowSave = true;
    component.onPageNumberUpdated(1);
    expect(component.wvInstance.UI.hotkeys.off).toHaveBeenCalled();
    expect(component.wvInstance.UI.enableElements).toHaveBeenCalledWith([
      'customDownloadButton',
    ]);
    expect(component.wvInstance.UI.disableElements).toHaveBeenCalledWith([
      'customPrintButton',
    ]);

    // Show neither
    doc.allowSave = false;
    component.onPageNumberUpdated(1);
    expect(component.wvInstance.UI.hotkeys.off).toHaveBeenCalled();
    expect(component.wvInstance.UI.enableElements).toHaveBeenCalledWith([]);
    expect(component.wvInstance.UI.disableElements).toHaveBeenCalledWith([
      'customPrintButton',
      'customDownloadButton',
    ]);
  });

  it('should setup the PDF Viewer Document', async () => {
    component.currentDocumentId = 1;
    await component.ngAfterViewInit();
    component.setupNewPDfViewerDocument();
    expect(component.wvInstance.Core.documentViewer.getCurrentPage()).toEqual(
      1
    );
    expect(component.wvInstance.UI.getFitMode()).toEqual('FitWidth');
  });

  it('should disable the printing button when printing is not allowed', async () => {
    const document = fake.documentGroup.documents[0];
    document.allowPrint = false;
    spyOn(component, 'getCurrentDocument').and.returnValue(document);

    await component.ngAfterViewInit();
    spyOn(component.wvInstance.UI, 'disableElements');

    component.currentDocumentId = 1;
    component.wvInstance.UI.setHeaderItems((header) => {
      const headerRef = header.get('menuButton');
      component.insertPrintBtn(headerRef);
      spyOn(header, 'insertBefore');
      expect(header.insertBefore).not.toHaveBeenCalled();
    });

    // Disable native print button
    expect(component.wvInstance.UI.disableElements).toHaveBeenCalledWith([
      'printButton',
    ]);
  });

  it('should enable the printing button when printing is allowed', async () => {
    const document = fake.documentGroup.documents[0];
    document.allowPrint = true;
    spyOn(component, 'getCurrentDocument').and.returnValue(document);

    await component.ngAfterViewInit();
    spyOn(component.wvInstance.UI, 'disableElements');

    component.currentDocumentId = 2;
    component.wvInstance.UI.setHeaderItems((header) => {
      const headerRef = header.get('menuButton');
      spyOn(headerRef, 'insertBefore');
      component.insertPrintBtn(headerRef);
      expect(headerRef.insertBefore).toHaveBeenCalled();
    });

    // Disable native print button
    expect(component.wvInstance.UI.disableElements).toHaveBeenCalledWith([
      'printButton',
    ]);
  });

  it('should NOT insert the "documents" panel-toggle button if there are < 2 documents', async () => {
    spyOn(component, 'getCurrentDocument').and.returnValue(
      fake.documentGroup.documents[0]
    );
    spyOn(component, 'insertDocumentsBtn');
    fake.documentGroup.documents = fake.documentGroup.documents.slice(0, 1);
    await component.ngAfterViewInit();
    expect(component.insertDocumentsBtn).not.toHaveBeenCalled();
  });

  it('should enable the download button when saving is allowed', async () => {
    const document = fake.documentGroup.documents[0];
    document.allowSave = true;
    spyOn(component, 'getCurrentDocument').and.returnValue(document);

    await component.ngAfterViewInit();
    spyOn(component.wvInstance.UI, 'disableElements');

    component.currentDocumentId = 2;
    component.wvInstance.UI.setHeaderItems((header) => {
      const headerRef = header.get('menuButton');
      spyOn(headerRef, 'insertBefore');
      component.insertDownloadBtn(headerRef);
      expect(headerRef.insertBefore).toHaveBeenCalled();
    });

    // Disable native print button
    expect(component.wvInstance.UI.disableElements).toHaveBeenCalledWith([
      'downloadButton',
    ]);
  });

  it('should set NOT show document sidebar if < 2 documents in group', async () => {
    spyOn(component, 'getCurrentDocument').and.returnValue(
      fake.documentGroup.documents[0]
    );
    component.documentGroup = fake.documentGroup;
    component.documentGroup.documents = [fake.documentGroup.documents[0]];
    component.getDocumentName();
    expect(component.documentSidebarIsActive).toBeFalse();
  });

  it('should set NOT show document sidebar if < 2 documents in group', async () => {
    spyOn(component, 'getCurrentDocument').and.returnValue(
      fake.documentGroup.documents[0]
    );
    component.documentGroup = fake.documentGroup;
    component.getDocumentName();
    expect(component.documentSidebarIsActive).toBeTrue();
  });

  it('should toggle document sidebar', () => {
    component.documentSidebarIsActive = true;
    component.toggleDocumentSidebar();
    expect(component.documentSidebarIsActive).toBeFalse();

    component.documentSidebarIsActive = false;
    component.toggleDocumentSidebar();
    expect(component.documentSidebarIsActive).toBeTrue();
  });

  it('should toggle attachments sidebar', () => {
    component.attachmentSidebarIsActive = true;
    component.toggleAttachmentSidebar();
    expect(component.attachmentSidebarIsActive).toBeFalse();

    component.attachmentSidebarIsActive = false;
    component.toggleAttachmentSidebar();
    expect(component.attachmentSidebarIsActive).toBeTrue();
  });

  it('should toggle menu properties open', () => {
    component.listOpen = false;
    component.sidebarVisible = false;
    component.toggleMenu();
    expect(component.listOpen).toBeTrue();
    expect(component.sidebarVisible).toBeTrue();
  });

  it(`should fetch video data when video property does not exist on page object`, () => {
    const ids = fake.pageWithoutVideoData.resourceIds.split(',');

    component
      .getVideoData(fake.pageWithoutVideoData)
      .subscribe((returnedData) => {
        expect(returnedData).toEqual(fake.pageWithVideoData);
      });
    expect(mockCommunityService.getVideos).toHaveBeenCalledWith(ids);
  });

  it('should return the page when video data exists already', () => {
    component.getVideoData(fake.pageWithVideoData).subscribe((returnedData) => {
      expect(returnedData).toEqual(fake.pageWithVideoData);
    });
    expect(mockCommunityService.getVideos).not.toHaveBeenCalled();
  });

  it('should return undefined when trying to fetch videos of an empty object', () => {
    component.getVideoData(undefined).subscribe((returnedData) => {
      expect(returnedData).toEqual(undefined);
    });
    expect(mockCommunityService.getVideos).not.toHaveBeenCalled();
  });

  it('should save the documents annotations', async () => {
    component.currentDocumentId = 1;
    await component.ngAfterViewInit();
    component.saveAnnotations();
  });

  it('should enable adding annotations and set up fillable settings', async () => {
    component.currentDocumentId = 1;
    await component.ngAfterViewInit();
    component.addAnnotationAndFillableSettings();
    spyOn(
      component.wvInstance.Core.documentViewer,
      'setDocumentXFDFRetriever'
    ).and.callThrough();
  });

  it('should set up breadcrumbs with documents name if document group array is 1 or less', async () => {
    component.currentDocumentId = 1;
    await component.ngAfterViewInit();
    component.documentGroup.documents = [];
    component.setupBreadcrumbs();
    expect(component.path).toBeTruthy();
  });

  it('should set the PDF to view the page called from Jump To button', async () => {
    component.currentDocumentId = 1;
    await component.ngAfterViewInit();
    component.setupNewPDfViewerDocument();
    spyOn(component.wvInstance.Core.documentViewer, 'setCurrentPage');

    component.goToPage(6);
    expect(
      component.wvInstance.Core.documentViewer.setCurrentPage
    ).toHaveBeenCalledWith(7, true);
  });

  /**
   * Setup mock services
   */
  function loadMockServices(): void {
    mockCommunityService = {
      getVideos: jasmine
        .createSpy('getVideos')
        .and.returnValue(of(fake.videos)),
      searchVideos: jasmine
        .createSpy('searchVideos')
        .and.returnValue(of(fake.videos)),
    };

    mockTitleService = {
      setPageName: jasmine.createSpy('setPageName'),
    };

    mockSpinnerService = {
      show: jasmine.createSpy('show'),
      hide: jasmine.createSpy('hide'),
    };

    mockSessionService = {
      getSessionInformation: jasmine
        .createSpy('getSessionInformation')
        .and.returnValue({ user: { id: '123' } }),
    };

    mockDocumentService = {
      getCurrentDocumentGroup: jasmine
        .createSpy('getCurrentDocumentGroup')
        .and.returnValue(fake.documentGroup),

      getDocumentRenderingLink: jasmine
        .createSpy('getDocumentRenderingLink')
        .and.returnValue(of('jeffrocks')),

      saveDocumentAnnotations: jasmine
        .createSpy('saveDocumentAnnotations')
        .and.returnValue(of(void 0)),
    };

    mockChangeDetectorRef = {
      detectChanges: jasmine.createSpy('detectChanges'),
    };

    mockInitialLoadService = {
      initialLoad: {
        tokens: [
          {
            key: 'PdfTronWebViewerKey',
            value:
              'demo:jdemers@wilsonlanguage.com:7bfd2e120200000000b3af5397d3829e76124a0969ef6c7e142074b30d',
          },
        ],
      } as unknown as InitialLoad,
    };

    mockAuthenticationService = jasmine.createSpyObj(
      'currentUser',
      [],
      ['wilsonId']
    );

    mockRenderer = jasmine.createSpyObj('Renderer2', [
      'setStyle',
      'setProperty',
    ]);
  }

  function loadMockData(): void {
    fake = new MockData();

    mockRoute = {
      params: of({ documentId: 1 }),
      snapshot: {
        queryParams: {
          page: 1,
        },
      },
    };
  }

  /**
   * Configure test bed
   */
  function setupTestBed(): void {
    TestBed.configureTestingModule({
      declarations: [ViewDocumentComponent],
      providers: [
        { provide: CommunityApiService, useValue: mockCommunityService },
        { provide: DocumentService, useValue: mockDocumentService },
        { provide: TitleService, useValue: mockTitleService },
        { provide: SpinnerService, useValue: mockSpinnerService },
        { provide: SessionService, useValue: mockSessionService },
        { provide: Router, useValue: mockRouter },
        { provide: ActivatedRoute, useValue: mockRoute },
        { provide: ChangeDetectorRef, useValue: mockChangeDetectorRef },
        { provide: InitialLoadService, useValue: mockInitialLoadService },
        { provide: AuthenticationService, useValue: mockAuthenticationService },
        { provide: Renderer2, useValue: mockRenderer },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }

  async function setupComponent(): Promise<void> {
    fixture = TestBed.createComponent(ViewDocumentComponent);
    component = fixture.componentInstance;

    component.wvInstance = {
      Core: {
        annotationManager: {
          exportAnnotations: jasmine
            .createSpy('exportAnnotations')
            .and.returnValue(of('xfdf').toPromise()),
        },
        documentViewer: {
          setWatermark: jasmine.createSpy('setWatermark'),
        },
        Tools: {
          TextSelectTool: {
            enableTextSelection: jasmine.createSpy('enableTextSelection'),
            disableTextSelection: jasmine.createSpy('disableTextSelection'),
          },
        },
      },
      UI: {
        loadDocument: jasmine
          .createSpy('loadDocument')
          .and.returnValue(of(fake.documentGroup.documents[0])),
        setFitMode: jasmine.createSpy('setFitMode'),
        hotkeys: {
          on: jasmine.createSpy('on'),
          off: jasmine.createSpy('off'),
          Keys: {
            CTRL_P: 'ctrlp',
            COMMAND_P: 'cmdp',
          },
        },
        enableElements: jasmine.createSpy('enableElements'),
        disableElements: jasmine.createSpy('disableElements'),
      },
    } as unknown as WebViewerInstance;

    component.viewerRef = fixture.debugElement.query(By.css('.viewer'));
    component.attachmentBadge = document.createElement('span');
  }
});
