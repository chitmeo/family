import { TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Session, SessionService } from 'src/app/services/session.service';
import { Guid } from 'guid-typescript';
import { of } from 'rxjs';
import { ApiService } from '@wilson/wilsonng';

describe('SessionService', () => {
  let service: SessionService;
  let session: Session;
  let mockApiService: any;

  beforeEach(() => {
    loadMockData();
    loadMockServices();
    configureTestBed();
    service = TestBed.inject(SessionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
    expect(service.key).toEqual('dv::si');
  });

  it('should set session information', () => {
    service.setSessionInformation(session);
    expect(sessionStorage.setItem).toHaveBeenCalledWith(
      service.key,
      jasmine.any(Object)
    );
  });

  it('should not try to set session information if given a falsy value as a session', () => {
    service.setSessionInformation(null);
    expect(sessionStorage.setItem).not.toHaveBeenCalled();
  });

  it('should delete session information', () => {
    service.deleteSessionInformation();
    expect(sessionStorage.removeItem).toHaveBeenCalledWith(service.key);
  });

  it('should get session information', () => {
    spyOn(window.sessionStorage, 'getItem').and.returnValue(
      'U2FsdGVkX19J6kJv/q7XEPPJCEw3AIGL9yxjeMDhiNhdNfpAJ0+g9jj0sCK/BOcwFz6Ir3astMXkzHx7ADwkfNTmLAeLtLTgPNt6GMqoydfaUqazLUxziN3WfC3OJL+7jnhZxoK7LdYXijp0J4AOEcckgCqMjLaY9ZCXweklwWQ='
    );
    service.getSessionInformation();
    expect(window.sessionStorage.getItem).toHaveBeenCalled();
  });

  it('should not try to decrypt a non-existent session', () => {
    spyOn(window.sessionStorage, 'getItem').and.returnValue(null);
    spyOn(window.JSON, 'parse');
    expect(service.getSessionInformation()).toBeUndefined();
    expect(window.sessionStorage.getItem).toHaveBeenCalled();
    expect(window.JSON.parse).not.toHaveBeenCalled();
  });

  it('should delete session information if there is an error parsing the current session', () => {
    spyOn(window.sessionStorage, 'getItem').and.returnValue(
      'someEncryptedString'
    );
    spyOn(window.JSON, 'parse').and.callFake(() => {
      throw Error('JSON Parse Error');
    });
    expect(service.getSessionInformation()).toBeNull();
    expect(window.sessionStorage.removeItem).toHaveBeenCalledWith(service.key);
  });

  it('should save directory filters', () => {
    const filters = JSON.stringify({
      filterBy: 'testVal',
      currentView: 'grid',
    });
    service.saveFilters(filters);
    expect(sessionStorage.setItem).toHaveBeenCalledWith('dvFilters', filters);
  });

  it('should clear directory filters', () => {
    service.clearFilters();
    expect(sessionStorage.removeItem).toHaveBeenCalledWith('dvFilters');
  });

  it('should get directory filters', () => {
    spyOn(window.sessionStorage, 'getItem').and.returnValue(
      'someEncryptedString'
    );
    service.getFilters();
    expect(sessionStorage.getItem).toHaveBeenCalledWith('dvFilters');
  });

  it('should register and start the keep alive subscription on initialization', () => {
    spyOn(SessionService.prototype, 'keepServerSessionAlive');
    const s = new SessionService(mockApiService);
    expect(s.keepServerSessionAlive).toHaveBeenCalled();
  });

  function configureTestBed(): void {
    TestBed.configureTestingModule({
      providers: [{ provide: ApiService, useValue: mockApiService }],
      schemas: [NO_ERRORS_SCHEMA],
    });
    spyOn(sessionStorage, 'setItem');
    spyOn(window.sessionStorage, 'removeItem');
  }

  function loadMockData(): void {
    session = {
      accessCode: 'access-code-123',
      user: {
        id: Guid.EMPTY,
        name: 'Cool Dude',
        email: 'cooldude@cool.cool',
        school: 'Too Cool School',
      },
    };
  }

  function loadMockServices(): void {
    mockApiService = {
      unAuthedGet: jasmine.createSpy('unAuthedGet').and.returnValue(of(true)),
    };
  }
});
