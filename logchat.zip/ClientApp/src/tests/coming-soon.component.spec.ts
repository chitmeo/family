import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ComingSoonComponent } from '../app/components/coming-soon/coming-soon.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { TitleService } from '@wilson/wilsonng';

describe('ComingSoonComponent', () => {
  let component: ComingSoonComponent;
  let fixture: ComponentFixture<ComingSoonComponent>;
  let mockTitleService: any;

  beforeEach(async () => {
    loadMockServices();
    setupTestBed();
  });

  beforeEach(() => {
    setupComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  function setupTestBed(): void {
    TestBed.configureTestingModule({
      declarations: [ComingSoonComponent],
      providers: [
        {
          provide: TitleService,
          useValue: mockTitleService,
        },
        {
          provide: 'productName',
          useValue: 'Document Viewer',
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }

  function setupComponent(): void {
    fixture = TestBed.createComponent(ComingSoonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    component.ngOnInit();
  }

  function loadMockServices(): void {
    mockTitleService = {
      setPageName: jasmine.createSpy('setPageName'),
    };
  }
});
