import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AccessCodeGeneratorComponent } from 'src/app/components/access-code-generator/access-code-generator.component';
import { of } from 'rxjs';
import { AdminService } from '../app/services/admin.service';
import { Wilson } from '../def/Wilson';
import Document = Wilson.Document;
import AccessCode = Wilson.AccessCode;
import Group = Wilson.Group;

describe('AccessCodeGeneratorComponent', () => {
  let component: AccessCodeGeneratorComponent;
  let fixture: ComponentFixture<AccessCodeGeneratorComponent>;
  let mockDocument: Document;
  let mockAccessCode: AccessCode;
  let mockAdminService: any;

  beforeEach(async () => {
    loadMockData();
    loadMockServices();
    setupTestBed();
  });

  beforeEach(() => {
    setupComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize correctly', () => {
    spyOn(component, 'generateURL').and.returnValue(null);
    component.ngOnChanges();

    // setupBreadCrumbs()
    expect(component.generateURL).toHaveBeenCalled();
  });

  it('should fill document suggestions', () => {
    const event = {
      query: 'doc',
      originalEvent: null,
    };
    component.code = mockAccessCode;
    component.documentFillSuggestions(event);
    expect(mockAdminService.getDocuments).toHaveBeenCalled();
    expect(component.documentSuggestions.length).toBe(1);
  });

  it('should clear selected page', () => {
    spyOn(component, 'generateURL');
    component.selectedPage = 1;
    component.clearSelectedPage();

    expect(component.selectedPage).toBeNull();
    expect(component.generateURL).toHaveBeenCalled();
  });

  it('should open a document', () => {
    spyOn(window, 'open');
    component.selectedDocument = null;
    component.openDocument();
    expect(mockAdminService.getDocument).not.toHaveBeenCalled();

    component.selectedDocument = mockDocument;
    component.openDocument();
    expect(mockAdminService.getDocument).toHaveBeenCalledWith(mockDocument.id);
    expect(window.open).toHaveBeenCalledWith(mockDocument.filePath, '_blank');
  });

  it('should generate a URL', () => {
    const mockCode = mockAccessCode;
    const mockPage = 2;
    component.code = mockCode;
    component.selectedDocument = mockDocument;
    component.selectedPage = mockPage;

    let expectedURL = window.location.origin;
    expectedURL += '?accessCode=' + mockCode.codeText;
    expectedURL += '&documentId=' + mockDocument.id;
    expectedURL += '&documentPage=' + mockPage;
    component.generateURL();
    expect(component.generatedURL).toEqual(expectedURL);

    // Should do nothing if there is no access code
    component.code = null;
    component.generatedURL = null;
    component.generateURL();
    expect(component.generatedURL).toBeNull();
  });

  it('should generate a URL without a documentPage param if the selectedPage is 1 or higher', () => {
    const mockCode = mockAccessCode;
    const mockPage = -1;
    component.code = mockCode;
    component.selectedDocument = mockDocument;
    component.selectedPage = mockPage;

    let expectedURL = window.location.origin;
    expectedURL += '?accessCode=' + mockCode.codeText;
    expectedURL += '&documentId=' + mockDocument.id;
    component.generateURL();
    expect(component.generatedURL).toEqual(expectedURL);
  });

  it('should copy a URL', () => {
    spyOn(navigator.clipboard, 'writeText').and.returnValue(Promise.resolve());
    component.copyURL('https://www.fakeurl.com');
    expect(navigator.clipboard.writeText).toHaveBeenCalledWith(
      'https://www.fakeurl.com'
    );
  });

  it('should handle close', () => {
    spyOn(component.dialogClosed, 'emit');
    component.handleClose();
    expect(component.dialogClosed.emit).toHaveBeenCalled();
  });

  // Set up mock data, providers and method spies
  function loadMockData(): void {
    mockAccessCode = {
      id: 101,
      codeText: 'AC101',
      notes: 'Access ipsum dolor sit amet 101',
      active: true,
      expiration: new Date(),
      allowAnonymousEntry: true,
      groupId: 1,
      accessCodeSecurities: [],
      group: {
        id: 1,
        title: 'Sample Group 1',
        description: 'Lorem ipsum dolor sit amet',
        coverImageUrl: '/stock/fundations-cover.png',
        documentGroups: [
          {
            documentId: 1,
            groupId: 1,
            ordinal: 0,
            document: null,
            group: null,
          },
        ],
        accessCodes: [],
        createdDate: new Date(),
        modifiedDate: new Date(),
        createdBy: 'User Name',
        modifiedBy: 'User Name',
      } as Group,
      createdDate: new Date(),
      modifiedDate: new Date(),
      createdBy: 'User Name',
      modifiedBy: 'User Name',
    };

    mockDocument = {
      id: 1,
      filePath: 'some-path',
    } as Document;
  }

  function loadMockServices(): void {
    mockAdminService = {
      getDocuments: jasmine.createSpy('getDocuments').and.returnValue(
        of([
          {
            id: 1,
            title: 'Test Document',
            description: 'Lorem ipsum',
            documentGroups: [{ groupId: 1 }],
          },
        ])
      ),
      getDocument: jasmine
        .createSpy('getDocument')
        .and.returnValue(of(mockDocument)),
    };
  }

  // Configure the test bed
  function setupTestBed(): void {
    TestBed.configureTestingModule({
      declarations: [AccessCodeGeneratorComponent],
      providers: [{ provide: AdminService, useValue: mockAdminService }],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }

  // Initialize the component var
  function setupComponent(): void {
    fixture = TestBed.createComponent(AccessCodeGeneratorComponent);
    component = fixture.componentInstance;

    component.code = mockAccessCode;
    component.ngOnChanges();
  }
});
