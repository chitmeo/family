import { TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { BehaviorSubject, of } from 'rxjs';
import { AttachmentsService } from 'src/app/services/attachments.service';
import { CommunityApiService } from 'src/app/services/community-api.service';
import { MockData } from './mockdata';
import { DocumentPageWithAttachment } from 'src/app/services/admin.service';

describe('AttachmentsService', () => {
  let service: AttachmentsService;
  let mockCommunityService: any;
  let fake: MockData;
  let subjectAttachments: BehaviorSubject<DocumentPageWithAttachment[]>;

  beforeEach(() => {
    loadMockData();
    loadMockServices();
    configureTestBed();
    service = TestBed.inject(AttachmentsService);
    subjectAttachments = service['_pagesWithAttachments'];
    subjectAttachments.next(fake.pagesWithAttachments);
  });

  it('should push a new video object onto the videos array for the correct page number when property is missing', () => {
    // page one in mock data has no videos property
    service.addAttachment(1, fake.videos[0]);
    const fakePageOne = subjectAttachments.value.find(
      (p) => p.pageNumber === 1
    );
    fakePageOne.videos = [fake.videos[0]];
    expect(subjectAttachments.value).toContain(fakePageOne);
  });

  it(`should push a new video object onto the videos array for the correct page number when a videos array for that page already exists`, () => {
    // setup page one with a video array
    const fakePageOne = subjectAttachments.value.find(
      (p) => p.pageNumber === 1
    );
    fakePageOne.videos = [fake.videos[0]];

    // add another video through the method we want to test
    service.addAttachment(1, fake.videos[1]);
    expect(fakePageOne.videos).toContain(fake.videos[1]);
  });

  it('should add a new page object to attachments with new video object when page does not yet exist', () => {
    service.addAttachment(5, fake.videos[0]);
    const addedPage = subjectAttachments.value.find((p) => p.pageNumber === 5);
    expect(addedPage.pageNumber).toEqual(5);
    expect(addedPage.videos).toContain(fake.videos[0]);
  });

  it('should call to reorder the resource IDs string to match the video array ids', () => {
    spyOn(service, 'setPagesWithAttachments');
    spyOn(service, 'stringifyVideoIds');
    service.reorderVideos(1, fake.pageWithVideoData.videos);
    expect(service.setPagesWithAttachments).toHaveBeenCalled();
    expect(service.stringifyVideoIds).toHaveBeenCalledWith(
      fake.pageWithVideoData.videos
    );
  });

  function configureTestBed(): void {
    TestBed.configureTestingModule({
      providers: [
        { provide: CommunityApiService, useValue: mockCommunityService },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    });
    spyOn(sessionStorage, 'setItem');
    spyOn(window.sessionStorage, 'removeItem');
  }

  function loadMockData(): void {
    fake = new MockData();
  }

  function loadMockServices(): void {
    mockCommunityService = {
      getVideos: jasmine
        .createSpy('getVideos')
        .and.returnValue(of(fake.videos)),
    };
  }
});
