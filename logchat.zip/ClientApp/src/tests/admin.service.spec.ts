import { TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { AdminService } from '../app/services/admin.service';
import { of, throwError } from 'rxjs';
import { ToastService } from 'src/app/services/toast.service';
import { ApiService } from '@wilson/wilsonng';
import { Wilson } from '../def/Wilson';
import Group = Wilson.Group;
import AccessCode = Wilson.AccessCode;
import Search = Wilson.Search;
import Document = Wilson.Document;

describe('AdminService', () => {
  let service: AdminService;
  let document1: Document;
  let document2: Document;
  let group: Group;
  let accessCode1: AccessCode;
  let search: Search;
  let mockApiService: any;
  let mockToastService: any;
  const ERROR_MSG =
    'AdminService: Test-generated Exception (This is not a failing test)';

  beforeEach(() => {
    loadMockData();
    loadMockServices();
    configureTestBed();
    service = TestBed.inject(AdminService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get a document', () => {
    service.getDocument(document1.id).subscribe(() => {
      expect(mockApiService.get).toHaveBeenCalledWith(
        `Admin/GetDocument/${document1.id}`
      );
    });
  });

  it('should pop a toast if error getting document', () => {
    mockApiService.get.and.returnValue(throwError(ERROR_MSG));
    service.getDocument(document1.id).subscribe(() => {
      expect(mockApiService.get).toHaveBeenCalledWith(
        `Admin/GetDocument/${document1.id}`
      );
      expect(mockToastService.crudNotFound).toHaveBeenCalledWith(
        'Document',
        document1.id,
        '/admin/documents'
      );
    });
  });

  it('should upsert a document', () => {
    const mockDocument = JSON.parse(JSON.stringify(document1));
    delete mockDocument.documentOptions;
    service
      .upsertDocument(mockDocument, [group], document1.documentOptions)
      .subscribe(() => {
        expect(mockApiService.post).toHaveBeenCalledWith(
          `Admin/UpsertDocument`,
          jasmine.any(FormData)
        );
      });
  });

  it('should upsert a document with files', () => {
    spyOn(FormData.prototype, 'append');
    const file = {
      name: 'Rull Cool File Name',
    } as File;
    const thumbnail = {
      name: 'Supa Cool Thumbnail Name',
    } as File;
    const mockDocument = JSON.parse(JSON.stringify(document1));
    delete mockDocument.documentOptions;
    service
      .upsertDocument(
        mockDocument,
        [group],
        document1.documentOptions,
        file,
        thumbnail
      )
      .subscribe(() => {
        expect(mockApiService.post).toHaveBeenCalledWith(
          `Admin/UpsertDocument`,
          jasmine.any(FormData)
        );
      });
  });

  it('should pop a toast if error upserting document', () => {
    mockApiService.post.and.returnValue(throwError(ERROR_MSG));
    const mockDocument = JSON.parse(JSON.stringify(document1));
    delete mockDocument.documentOptions;
    service
      .upsertDocument(mockDocument, [group], document1.documentOptions)
      .subscribe(() => {
        expect(mockApiService.post).toHaveBeenCalledWith(
          `Admin/UpsertDocument`,
          jasmine.any(FormData)
        );
        expect(mockToastService.crudFailure).toHaveBeenCalledWith(
          'Document',
          'save'
        );
      });
  });

  it('should delete a document', () => {
    service.deleteDocument(document1.id).subscribe(() => {
      expect(mockApiService.delete).toHaveBeenCalledWith(
        `Admin/DeleteDocument/${document1.id}`
      );
    });
  });

  it('should pop a toast if error deleting document', () => {
    mockApiService.delete.and.returnValue(throwError(ERROR_MSG));
    service.deleteDocument(document1.id).subscribe(() => {
      expect(mockApiService.delete).toHaveBeenCalledWith(
        `Admin/DeleteDocument/${document1.id}`
      );
      expect(mockToastService.crudFailure).toHaveBeenCalledWith(
        'Document',
        'delete'
      );
    });
  });

  it('should get documents', () => {
    service.getDocuments(search).subscribe(() => {
      expect(mockApiService.post).toHaveBeenCalledWith(
        `Admin/GetDocuments/0`,
        search
      );
    });
  });

  it('should get a group', () => {
    service.getGroup(group.id).subscribe(() => {
      expect(mockApiService.get).toHaveBeenCalledWith(
        `Admin/GetGroup/${group.id}`
      );
    });
  });

  it('should pop a toast if error getting group', () => {
    mockApiService.get.and.returnValue(throwError(ERROR_MSG));
    service.getGroup(group.id).subscribe(() => {
      expect(mockApiService.get).toHaveBeenCalledWith(
        `Admin/GetGroup/${group.id}`
      );
      expect(mockToastService.crudNotFound).toHaveBeenCalledWith(
        'Group',
        group.id,
        '/admin/groups'
      );
    });
  });

  it('should upsert a group', () => {
    service.upsertGroup(group).subscribe(() => {
      expect(mockApiService.post).toHaveBeenCalledWith(
        `Admin/UpsertGroup`,
        jasmine.any(FormData)
      );
    });
  });

  it('should upsert a group with files', () => {
    spyOn(FormData.prototype, 'append');
    const file = {
      name: 'Rull Cool File Name',
    } as File;
    service.upsertGroup(group, file).subscribe(() => {
      expect(mockApiService.post).toHaveBeenCalledWith(
        `Admin/UpsertGroup`,
        jasmine.any(FormData)
      );
    });
  });

  it('should pop a toast if error upserting group', () => {
    mockApiService.post.and.returnValue(throwError(ERROR_MSG));
    service.upsertGroup(group).subscribe(() => {
      expect(mockApiService.post).toHaveBeenCalledWith(
        `Admin/UpsertGroup`,
        jasmine.any(FormData)
      );
      expect(mockToastService.crudFailure).toHaveBeenCalledWith(
        'Group',
        'save'
      );
    });
  });

  it('should delete a group', () => {
    service.deleteGroup(group.id).subscribe(() => {
      expect(mockApiService.delete).toHaveBeenCalledWith(
        `Admin/DeleteGroup/${group.id}`
      );
    });
  });

  it('should pop a toast if error deleting group', () => {
    mockApiService.delete.and.returnValue(throwError(ERROR_MSG));
    service.deleteGroup(group.id).subscribe(() => {
      expect(mockApiService.delete).toHaveBeenCalledWith(
        `Admin/DeleteGroup/${group.id}`
      );
      expect(mockToastService.crudFailure).toHaveBeenCalledWith(
        'Group',
        'delete'
      );
    });
  });

  it('should sort documents in a group', () => {
    const documentIds = [document2.id, document1.id];
    service.sortDocumentsInGroup(group.id, documentIds).subscribe(() => {
      expect(mockApiService.post).toHaveBeenCalledWith(
        `Admin/SortDocumentsInGroup/${group.id}`,
        documentIds
      );
    });
  });

  it('should get groups', () => {
    service.getGroups(search).subscribe(() => {
      expect(mockApiService.post).toHaveBeenCalledWith(
        `Admin/GetGroups`,
        search
      );
    });
  });

  it('should get a document code', () => {
    service.getAccessCode(accessCode1.id).subscribe(() => {
      expect(mockApiService.get).toHaveBeenCalledWith(
        `Admin/GetAccessCode/${accessCode1.id}`
      );
    });
  });

  it('should pop a toast if error getting document code', () => {
    mockApiService.get.and.returnValue(throwError(ERROR_MSG));
    service.getAccessCode(accessCode1.id).subscribe(() => {
      expect(mockApiService.get).toHaveBeenCalledWith(
        `Admin/GetAccessCode/${accessCode1.id}`
      );
      expect(mockToastService.crudNotFound).toHaveBeenCalledWith(
        'Document Code',
        accessCode1.id,
        '/admin/access-codes'
      );
    });
  });

  it('should upsert a document code', () => {
    service.upsertAccessCode(accessCode1).subscribe(() => {
      expect(mockApiService.post).toHaveBeenCalledWith(
        `Admin/UpsertAccessCode`,
        accessCode1
      );
    });
  });

  it('should pop a toast if error upserting document code', () => {
    mockApiService.post.and.returnValue(throwError(ERROR_MSG));
    service.upsertAccessCode(accessCode1).subscribe(() => {
      expect(mockApiService.post).toHaveBeenCalledWith(
        `Admin/UpsertAccessCode`,
        accessCode1
      );
      expect(mockToastService.crudFailure).toHaveBeenCalledWith(
        'Document Code',
        'save'
      );
    });
  });

  it('should delete a document code', () => {
    service.deleteAccessCode(accessCode1.id).subscribe(() => {
      expect(mockApiService.delete).toHaveBeenCalledWith(
        `Admin/DeleteAccessCode/${accessCode1.id}`
      );
    });
  });

  it('should pop a toast if error deleting document code', () => {
    mockApiService.delete.and.returnValue(throwError(ERROR_MSG));
    service.deleteAccessCode(accessCode1.id).subscribe(() => {
      expect(mockApiService.delete).toHaveBeenCalledWith(
        `Admin/DeleteAccessCode/${accessCode1.id}`
      );
      expect(mockToastService.crudFailure).toHaveBeenCalledWith(
        'Document Code',
        'delete'
      );
    });
  });

  it('should get document codes', () => {
    service.getAccessCodes(search).subscribe(() => {
      expect(mockApiService.post).toHaveBeenCalledWith(
        `Admin/GetAccessCodes`,
        search
      );
    });
  });

  it('should get a document directory', () => {
    service.getDocumentDirectory(search).subscribe(() => {
      expect(mockApiService.post).toHaveBeenCalledWith(
        `Admin/GetDocumentDirectory`,
        search
      );
    });
  });

  it('should get a document code directory', () => {
    service.getAccessCodeDirectory(search).subscribe(() => {
      expect(mockApiService.post).toHaveBeenCalledWith(
        `Admin/GetAccessCodeDirectory`,
        search
      );
    });
  });

  it('should get a group directory', () => {
    service.getGroupDirectory(search).subscribe(() => {
      expect(mockApiService.post).toHaveBeenCalledWith(
        `Admin/GetGroupDirectory`,
        search
      );
    });
  });

  it('should get document code security type values', () => {
    service.getAccessCodeSecurityTypeValues(2, 'hello').subscribe(() => {
      expect(mockApiService.get).toHaveBeenCalledWith(
        `Admin/GetAccessCodeSecurityTypeValues/2/hello`
      );
    });
  });

  function configureTestBed(): void {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes([])],
      providers: [
        { provide: ApiService, useValue: mockApiService },
        { provide: ToastService, useValue: mockToastService },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    });
  }
  function loadMockData(): void {
    document1 = {
      id: 111,
    } as Document;
    document2 = {
      id: 222,
    } as Document;
    group = {
      id: 999,
    } as Group;
    search = {
      filters: [{ column: 'Name', value: 'TestVal', filterType: 4 }],
      dateRanges: [
        {
          column: 'Name',
          start: new Date(),
          end: new Date(),
        },
      ],
      skip: 2,
      take: 50,
      sort: null,
    };
    accessCode1 = {
      id: 123,
      codeText: 'am-access-code-hear-me-roar',
    } as AccessCode;
  }

  function loadMockServices(): void {
    mockApiService = {
      unAuthedGet: jasmine.createSpy('unAuthedGet').and.returnValue(of({})),
      post: jasmine.createSpy('post').and.returnValue(of({})),
      delete: jasmine.createSpy('delete').and.returnValue(of({})),
      get: jasmine.createSpy('get').and.returnValue(of({})),
    };

    mockToastService = {
      crudNotFound: jasmine.createSpy('crudNotFound'),
      crudFailure: jasmine.createSpy('crudFailure'),
    };
  }
});
