import { TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { SiteAvailabilityGuard } from '../app/guards/site-availability.guard';
import { InitialLoadService } from '../app/services/initial-load.service';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

describe('SiteAvailabilityGuard', () => {
  let guard: SiteAvailabilityGuard;
  let mockInitialLoadService: any;
  let route: ActivatedRouteSnapshot;
  let state: RouterStateSnapshot;

  beforeEach(() => {
    loadMockData();
    loadMockServices();
    configureTestBed();
    guard = TestBed.inject(SiteAvailabilityGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });

  it('can activate: backdoor key is set to true', () => {
    spyOn(localStorage, 'getItem').and.returnValue('true');
    expect(guard.canActivate(route, state)).toEqual(true);
  });

  it('can activate: isDownForMaintenance is set to true', () => {
    spyOn(localStorage, 'getItem').and.returnValue('false');
    (guard as any).initialLoadService.initialLoad.isDownForMaintenance = true;
    expect(guard.canActivate(route, state)).toBeTruthy();
  });

  it('can activate: isComingSoonDefaultPage is set to true', () => {
    spyOn(localStorage, 'getItem').and.returnValue('false');
    (guard as any).initialLoadService.initialLoad.isComingSoonDefaultPage =
      true;
    expect(guard.canActivate(route, state)).toBeTruthy();
  });

  it('can activate: no backdoor, but site is not down for maintenance or coming soon', () => {
    spyOn(localStorage, 'getItem').and.returnValue('false');
    expect(guard.canActivate(route, state)).toBeTruthy();
  });

  it('can activate: no backdoor, and no initial load', () => {
    mockInitialLoadService.initialLoad = undefined;
    spyOn(localStorage, 'getItem').and.returnValue('false');
    expect(guard.canActivate(route, state)).toBeTruthy();
  });

  it('can activate CHILD: backdoor key is set to true', () => {
    spyOn(localStorage, 'getItem').and.returnValue('true');
    expect(guard.canActivateChild(route, state)).toEqual(true);
  });

  it('can activate CHILD: isDownForMaintenance is set to true', () => {
    spyOn(localStorage, 'getItem').and.returnValue('false');
    (guard as any).initialLoadService.initialLoad.isDownForMaintenance = true;
    expect(guard.canActivateChild(route, state)).toBeTruthy();
  });

  it('can activate CHILD: isComingSoonDefaultPage is set to true', () => {
    spyOn(localStorage, 'getItem').and.returnValue('false');
    (guard as any).initialLoadService.initialLoad.isComingSoonDefaultPage =
      true;
    expect(guard.canActivateChild(route, state)).toBeTruthy();
  });

  it('can activate CHILD: no backdoor, but site is not down for maintenance or coming soon', () => {
    spyOn(localStorage, 'getItem').and.returnValue('false');
    expect(guard.canActivateChild(route, state)).toBeTruthy();
  });

  it('should setBackdoor as true if backdoor=true is in url', () => {
    spyOn(localStorage, 'setItem');
    state.url = 'https://some-url/backdoor=true';
    guard.canActivate(route, state);
    expect(localStorage.setItem).toHaveBeenCalledWith('backdoor', 'true');
  });

  it('should setBackdoor as false if backdoor=false is in url', () => {
    spyOn(localStorage, 'setItem');
    state.url = 'https://some-url/backdoor=false';
    guard.canActivate(route, state);
    expect(localStorage.setItem).toHaveBeenCalledWith('backdoor', 'false');
  });

  it('should not setBackdoor at all if the queryParam does not exist in the url', () => {
    spyOn(localStorage, 'setItem');
    state.url = 'https://some-url/backdoor=letMeInPls';
    guard.canActivate(route, state);
    expect(localStorage.setItem).not.toHaveBeenCalled();
  });

  function loadMockData(): void {
    route = {} as ActivatedRouteSnapshot;
    state = {
      url: 'https://some-site.com',
    } as RouterStateSnapshot;
  }

  function configureTestBed(): void {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes([])],
      providers: [
        { provide: InitialLoadService, useValue: mockInitialLoadService },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    });
  }

  function loadMockServices(): void {
    mockInitialLoadService = {
      initialLoad: {
        isDownForMaintenance: false,
        isComingSoonDefaultPage: false,
      },
    };
  }
});
