import { TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { PageVisibilityService } from '../app/services/page-visibility.service';

describe('PageVisibilityService', () => {
  let service: PageVisibilityService;

  beforeEach(() => {
    configureTestBed();
    service = TestBed.inject(PageVisibilityService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should set the page visibility to show', () => {
    service.show();
    service.pageVisible.subscribe((visible) => {
      expect(visible).toEqual(true);
    });
  });

  it('should set the page visibility to hide', () => {
    service.hide();
    service.pageVisible.subscribe((visible) => {
      expect(visible).toEqual(false);
    });
  });

  function configureTestBed() {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes([])],
      providers: [],
      schemas: [NO_ERRORS_SCHEMA],
    });
  }
});
