import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LoginComponent } from '../app/components/login/login.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { DocumentService } from '../app/services/document.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { of, throwError } from 'rxjs';
import { SessionService } from 'src/app/services/session.service';
import {
  AuthenticationService,
  RedirectService,
  TitleService,
} from '@wilson/wilsonng';
import { Wilson } from '../def/Wilson';
import ViewDocument = Wilson.ViewDocument;
import ViewGroup = Wilson.ViewGroup;

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let mockDocumentGroup: ViewGroup;
  let mockRouter: any;
  let mockRoute: any;
  let mockDocumentService: any;
  let mockSessionService: any;
  let mockAuthenticationService: any;
  let mockRedirectService: any;
  let nextSubmitBtn: any;
  let mockTitleService: any;

  beforeEach(async () => {
    loadMockServices();
    setupTestBed();
  });

  beforeEach(() => {
    setupComponent();
  });

  it('should create', () => {
    mockRoute.snapshot.queryParams = {
      iframe: 'true',
      accessCode: 'flclTEST',
      userName: 'test user',
      userEmail: 'test@test.com',
      userSchool: 'Schoolio',
    };
    component.ngOnInit();
    expect(component.isIframe).toBeTrue();
  });

  it('should handle iframe request ', () => {
    spyOn(component, 'handleSubmitAccessCode');
    component.ngOnInit();
    expect(component).toBeTruthy();
    // No "accessCode" queryParam present, so we shouldn't try to auto-login
    expect(component.handleSubmitAccessCode).not.toHaveBeenCalled();
  });

  it('should handle xsite request ', () => {
    spyOn(component, 'handleSubmitAccessCode');
    component.ngOnInit();
    expect(component).toBeTruthy();
    // No "accessCode" queryParam present, so we shouldn't try to auto-login
    expect(component.handleSubmitAccessCode).not.toHaveBeenCalled();
  });

  it('should correctly initialize form data', () => {
    component.ngOnInit();
    // document code form
    expect(component.accessCodeLoginForm.value.accessCode).toEqual('');
    // user info form
    expect(component.userInfoLoginForm.value.userName).toEqual('');
    expect(component.userInfoLoginForm.value.userEmail).toEqual('');
    expect(component.userInfoLoginForm.value.userSchool).toEqual('');
    expect(component.userInfoLoginForm.value.terms).toEqual(false);
  });

  it('should attempt to auto-login if there is an accessCode queryParam', () => {
    spyOn(component, 'handleSubmitAccessCode');
    mockRoute.snapshot.queryParams = {
      accessCode: 'flclTEST',
      userName: 'test user',
      userEmail: 'test@test.com',
      userSchool: 'Schoolio',
    };
    component.ngOnInit();
    // Should have attempted to auto-login since there is an accessCode queryParam
    expect(component.accessCodeLoginForm.value.accessCode).toEqual(
      mockRoute.snapshot.queryParams.accessCode
    );
    expect(component.handleSubmitAccessCode).toHaveBeenCalled();

    // Should have pre-filled the userInfoLoginForm with data from queryParams
    expect(component.userInfoLoginForm.value.userName).toEqual(
      mockRoute.snapshot.queryParams.userName
    );
    expect(component.userInfoLoginForm.value.userEmail).toEqual(
      mockRoute.snapshot.queryParams.userEmail
    );
    expect(component.userInfoLoginForm.value.userSchool).toEqual(
      mockRoute.snapshot.queryParams.userSchool
    );
  });

  it('should not enable next button if document code field is empty and invalid', () => {
    component.ngOnInit();
    expect(component.accessCodeLoginForm.valid).toBeFalsy();
    expect(
      nextSubmitBtn.nativeElement.querySelector('#accessCodeSubmitBtn').disabled
    ).toBeTruthy();
  });

  it('should throw an error if there was an error getting the document group', () => {
    mockDocumentService.getDocumentGroupSecurityMetaByShareCode.and.returnValue(
      throwError(
        'LoginComponent: Test-generated Exception (This is not a failing test)'
      )
    );
    component.ngOnInit();
    component.accessCodeLoginForm.controls['accessCode'].setValue('flcl1');
    component.handleSubmitAccessCode();
    expect(component.accessCodeErrorText).toContain('Sorry');
    expect(component.nextRequest).toEqual('none');
  });

  it('should redirect to forbidden page if there was an error getting the document group via iframe', () => {
    mockDocumentService.getDocumentGroupSecurityMetaByShareCode.and.returnValue(
      throwError(
        'LoginComponent: Test-generated Exception (This is not a failing test)'
      )
    );
    component.ngOnInit();
    component.accessCodeLoginForm.controls['accessCode'].setValue('flcl1');
    component.isIframe = true;
    component.handleSubmitAccessCode();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['forbidden']);
  });

  it('should skip user info form if document group allows anonymous access', () => {
    spyOn(component, 'registerUserWithGoogleAnalytics');
    mockDocumentService.getDocumentGroupByShareCode.and.returnValue(
      of({
        id: 101,
        title: 'Document Group Title',
        description: 'This is a test description.',
        allowAnonymousEntry: true,
        documents: [
          {
            id: 999,
            title: 'Document Title 1',
            description: 'This is the description for Document Title 1.',
            thumbnailUrl: 'https://google.com',
            url: 'https://wilsonacademy.com',
            ordinal: 1,
          },
        ],
      })
    );
    component.ngOnInit();
    component.accessCodeLoginForm.controls['accessCode'].setValue('flcl1');
    expect(component.accessCodeLoginForm.valid).toBeTruthy();
    component.handleSubmitAccessCode();
  });

  it('should require user info form if document group does NOT allow anonymous access', () => {
    spyOn(component, 'userInfoAlreadySaved').and.returnValue(false);
    component.ngOnInit();
    component.accessCodeLoginForm.controls['accessCode'].setValue('flcl1');
    expect(component.accessCodeLoginForm.valid).toBeTruthy();
    component.handleSubmitAccessCode();
    expect(component.accessCodeValidated).toBe(true);
    expect(component.requireUserInfo).toBe(true);
  });

  it('should auto-login the user if their info is already stored in the session', () => {
    spyOn(component, 'registerUserWithGoogleAnalytics');
    component.ngOnInit();
    component.accessCodeLoginForm.controls['accessCode'].setValue('flcl1');
    expect(component.accessCodeLoginForm.valid).toBeTruthy();
    component.handleSubmitAccessCode();
    expect(mockDocumentService.getDocumentGroupByShareCode).toHaveBeenCalled();
    expect(mockSessionService.getSessionInformation).toHaveBeenCalled();
    expect(component.registerUserWithGoogleAnalytics).toHaveBeenCalled();
  });

  it('should navigate the user directly to their document if the document group only contains one document', () => {
    spyOn(component, 'registerUserWithGoogleAnalytics');
    mockDocumentService.getDocumentGroupByShareCode.and.returnValue(
      of({
        id: 101,
        title: 'Document Group Title',
        description: 'This is a test description.',
        allowAnonymousEntry: false,
        documents: [
          {
            id: 999,
            title: 'Document Title 1',
            description: 'This is the description for Document Title 1.',
            thumbnailUrl: 'https://google.com',
            url: 'https://wilsonacademy.com',
            ordinal: 1,
          },
        ],
      })
    );
    component.ngOnInit();
    component.accessCodeLoginForm.controls['accessCode'].setValue('flcl1');
    expect(component.accessCodeLoginForm.valid).toBeTruthy();
    component.handleSubmitAccessCode();
    expect(mockDocumentService.getDocumentGroupByShareCode).toHaveBeenCalled();
    expect(mockSessionService.getSessionInformation).toHaveBeenCalled();
    expect(component.registerUserWithGoogleAnalytics).toHaveBeenCalled();
  });

  it('should register the user with Google Analytics and send a custom login event', () => {
    spyOn(component, 'registerUserWithGoogleAnalytics');
    component.ngOnInit();
    component.accessCodeLoginForm.controls['accessCode'].setValue('flcl1');
    expect(component.accessCodeLoginForm.valid).toBeTruthy();
    component.handleSubmitAccessCode();
    expect(mockDocumentService.getDocumentGroupByShareCode).toHaveBeenCalled();
    expect(mockSessionService.getSessionInformation).toHaveBeenCalled();
    expect(component.registerUserWithGoogleAnalytics).toHaveBeenCalled();
  });

  it('should return early in handleSubmitAccessCode if form is invalid', () => {
    component.ngOnInit();
    component.accessCodeLoginForm.controls['accessCode'].setValue('');
    component.handleSubmitAccessCode();
    expect(component.accessCodeErrorText).toEqual('This field is required.');
    expect(component.nextRequest).toEqual('none');
    expect(
      mockDocumentService.getDocumentGroupSecurityMetaByShareCode
    ).not.toHaveBeenCalled();
  });

  it('should log the user in if group requires universal login', () => {
    mockDocumentGroup.requiresUniversalLogin = true;
    const code = 'access-shmaccess-code';
    component.ngOnInit();
    component.accessCodeLoginForm.controls['accessCode'].setValue(code);
    mockAuthenticationService.isLoggedIn.and.returnValue(false);
    component.handleSubmitAccessCode();
    expect(mockRedirectService.setRedirectCookie).toHaveBeenCalled();
    expect(mockAuthenticationService.login).toHaveBeenCalled();
  });

  it('should go to directory if user is already authZeroAuthenticated', () => {
    mockDocumentGroup.requiresUniversalLogin = true;
    mockAuthenticationService.isLoggedIn.and.returnValue(true);
    spyOn(component, 'toDirectory').and.returnValue(of(null));
    const code = 'access-shmaccess-code';
    component.ngOnInit();
    component.accessCodeLoginForm.controls['accessCode'].setValue(code);
    mockAuthenticationService.isLoggedIn.and.returnValue = true;
    component.handleSubmitAccessCode();
    expect(mockAuthenticationService.login).not.toHaveBeenCalled();
    expect(component.toDirectory).toHaveBeenCalledWith(code);
  });

  it('should display an error and NOT log the user in if getDocumentGroupByShareCode comes back falsy', () => {
    mockDocumentService.getDocumentGroupByShareCode.and.returnValue(of(null));
    mockDocumentGroup.requiresUniversalLogin = true;
    spyOn(component, 'fillSessionInformation');
    spyOn(component, 'registerUserWithGoogleAnalytics');
    const code = 'access-shmaccess-code';

    component.ngOnInit();
    component.accessCodeLoginForm.controls['accessCode'].setValue(code);
    mockAuthenticationService.isLoggedIn.and.returnValue(true);
    component.handleSubmitAccessCode();

    expect(component.accessCodeErrorText).toEqual(
      'The user you are logged in as does not have access to use this code.'
    );
    expect(component.nextRequest).toEqual('none');
    expect(mockDocumentService.getDocumentGroupByShareCode).toHaveBeenCalled();
    expect(component.fillSessionInformation).not.toHaveBeenCalled();
    expect(component.registerUserWithGoogleAnalytics).not.toHaveBeenCalled();
    expect(mockRouter.navigate).not.toHaveBeenCalled();
  });

  it('should throw an error if the user info form is invalid', () => {
    component.ngOnInit();
    expect(component.userInfoLoginForm.valid).toBeFalsy();
    spyOn(component, 'toDirectory').and.callThrough();
    component.handleSubmitUserInfo();

    expect(component.toDirectory).not.toHaveBeenCalled();
  });

  it('should fail on userInfoLoginForm if Name field is blank', () => {
    component.ngOnInit();
    component.userInfoLoginForm.controls['userEmail'].setValue(
      'nmiller@pepperwoodchronicals.com'
    );
    component.userInfoLoginForm.controls['userSchool'].setValue(
      'Coolidge Middle School'
    );
    component.userInfoLoginForm.controls['terms'].setValue(true);
    spyOn(component, 'toDirectory').and.callThrough();
    component.handleSubmitUserInfo();
    expect(component.userInfoLoginForm.valid).toBeFalsy();
    expect(component.userNameErrorText).toEqual('This field is required.');
    expect(component.toDirectory).not.toHaveBeenCalled();
  });

  it('should fail on userInfoLoginForm if Email field is blank', () => {
    component.ngOnInit();
    component.userInfoLoginForm.controls['userName'].setValue('Nick Miller');
    component.userInfoLoginForm.controls['userSchool'].setValue(
      'Coolidge Middle School'
    );
    component.userInfoLoginForm.controls['terms'].setValue(true);
    spyOn(component, 'toDirectory').and.callThrough();
    component.handleSubmitUserInfo();
    expect(component.userInfoLoginForm.valid).toBeFalsy();
    expect(component.userEmailErrorText).toEqual(
      'Please enter a valid email address.'
    );

    expect(component.toDirectory).not.toHaveBeenCalled();
  });

  it('should fail on userInfoLoginForm if the email address entered is invalid', () => {
    component.ngOnInit();
    component.userInfoLoginForm.controls['userName'].setValue('Nick Miller');
    component.userInfoLoginForm.controls['userEmail'].setValue('nmiller');
    component.userInfoLoginForm.controls['userSchool'].setValue(
      'Coolidge Middle School'
    );
    component.userInfoLoginForm.controls['terms'].setValue(true);
    spyOn(component, 'toDirectory').and.callThrough();
    component.handleSubmitUserInfo();
    expect(component.userInfoLoginForm.valid).toBeFalsy();
    expect(component.userEmailErrorText).toEqual(
      'Please enter a valid email address.'
    );

    expect(component.toDirectory).not.toHaveBeenCalled();
  });

  it('should fail on userInfoLoginForm if School field is left blank', () => {
    component.ngOnInit();
    component.userInfoLoginForm.controls['userName'].setValue('Nick Miller');
    component.userInfoLoginForm.controls['userEmail'].setValue(
      'nmiller@pepperwoodchronicals.com'
    );
    component.userInfoLoginForm.controls['terms'].setValue(true);
    spyOn(component, 'toDirectory').and.callThrough();
    component.handleSubmitUserInfo();
    expect(component.userInfoLoginForm.valid).toBeFalsy();
    expect(component.userSchoolErrorText).toEqual('This field is required.');

    expect(component.toDirectory).not.toHaveBeenCalled();
  });

  it('should fail on userInfoLoginForm if terms are not accepted', () => {
    component.ngOnInit();
    component.userInfoLoginForm.controls['userName'].setValue('Nick Miller');
    component.userInfoLoginForm.controls['userEmail'].setValue(
      'nmiller@pepperwoodchronicals.com'
    );
    component.userInfoLoginForm.controls['userSchool'].setValue(
      'Coolidge Middle School'
    );
    spyOn(component, 'toDirectory').and.callThrough();
    component.handleSubmitUserInfo();
    expect(component.userInfoLoginForm.valid).toBeFalsy();
    expect(component.termsErrorText).toEqual(
      'You must accept the terms to continue.'
    );

    expect(component.toDirectory).not.toHaveBeenCalled();
  });

  it('should redirect to directory if all forms/fields are valid', () => {
    spyOn(component, 'registerUserWithGoogleAnalytics');
    spyOn(component, 'userInfoAlreadySaved').and.returnValue(false);
    component.ngOnInit();
    // submit a valid document code that does NOT allow anonymous
    component.accessCodeLoginForm.controls['accessCode'].setValue('flcl1');
    component.handleSubmitAccessCode();
    expect(component.accessCodeValidated).toBe(true);
    expect(component.requireUserInfo).toBe(true);
    expect(component.accessCodeLoginForm.valid).toBeTruthy();
    // submit a valid user info form
    component.userInfoLoginForm.controls['userName'].setValue('Nick Miller');
    component.userInfoLoginForm.controls['userEmail'].setValue(
      'nmiller@pepperwoodchronicals.com'
    );
    component.userInfoLoginForm.controls['userSchool'].setValue(
      'Coolidge Middle School'
    );
    component.userInfoLoginForm.controls['terms'].setValue(true);
    spyOn(component, 'toDirectory').and.callThrough();
    spyOn(component, 'fillSessionInformation').and.callThrough();
    component.handleSubmitUserInfo();
    expect(component.userInfoLoginForm.valid).toBeTruthy();

    expect(component.toDirectory).toHaveBeenCalled();
    expect(component.fillSessionInformation).toHaveBeenCalled();
    expect(component.registerUserWithGoogleAnalytics).toHaveBeenCalled();
  });

  it('should redirect to directory within xsite funnel', () => {
    spyOn(component, 'findFinalDestination').and.callThrough();
    mockRoute.snapshot.queryParams = {
      accessCode: 'flcl1',
      userName: 'test user',
      userEmail: 'test@test.com',
      userSchool: 'Schoolio',
      xSite: '1',
      return: 'https://community.wilsonacademy.com',
      programId: 'fundations-1',
      title: 'Fundations Level 1',
      subtitle: 'Learning Community',
      reg: '1',
    };
    component.ngOnInit();
    expect(component.findFinalDestination).toHaveBeenCalled();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/xsite'], {
      queryParams: {
        xSite: '1',
        return: 'https://community.wilsonacademy.com',
        programId: 'fundations-1',
        title: 'Fundations Level 1',
        subtitle: 'Learning Community',
        reg: '1',
      },
    });
  });

  /***************************/
  // REDIRECT TO DOCUMENT TESTS
  /***************************/

  function redirectToDocumentSetup(): void {
    spyOn(component, 'registerUserWithGoogleAnalytics');
    spyOn(component, 'userInfoAlreadySaved').and.returnValue(false);
    spyOn(component, 'toDirectory').and.callThrough();
    spyOn(component, 'fillSessionInformation').and.callThrough();

    component.ngOnInit();
    component.accessCodeLoginForm.controls['accessCode'].setValue('flcl1');
    component.handleSubmitAccessCode();

    component.userInfoLoginForm.controls['userName'].setValue('Nick Miller');
    component.userInfoLoginForm.controls['userEmail'].setValue(
      'nmiller@pepperwoodchronicals.com'
    );
    component.userInfoLoginForm.controls['userSchool'].setValue(
      'Coolidge Middle School'
    );
    component.userInfoLoginForm.controls['terms'].setValue(true);
    component.handleSubmitUserInfo();
  }

  it('should redirect to document specified by documentId queryParam WITHOUT a page number specified', () => {
    mockRoute.snapshot.queryParams = {
      documentId: '5',
    };
    redirectToDocumentSetup();

    expect(component.toDirectory).toHaveBeenCalled();
    expect(component.registerUserWithGoogleAnalytics).toHaveBeenCalled();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/viewer/document/5'], {
      queryParams: {},
    });
  });

  it('should redirect to document specified by documentId queryParam WITH a page number specified', () => {
    mockRoute.snapshot.queryParams = {
      documentId: '5',
      documentPage: '25',
    };
    redirectToDocumentSetup();
    expect(component.toDirectory).toHaveBeenCalled();
    expect(component.registerUserWithGoogleAnalytics).toHaveBeenCalled();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/viewer/document/5'], {
      queryParams: { page: '25' },
    });
  });

  it('should NOT redirect to document specified by documentId queryParam if group has no documents', () => {
    mockRoute.snapshot.queryParams = {
      documentId: '5',
    };
    mockDocumentGroup.documents = null;
    spyOn(component, 'registerUserWithGoogleAnalytics');
    spyOn(component, 'userInfoAlreadySaved').and.returnValue(false);
    spyOn(component, 'toDirectory').and.callThrough();
    spyOn(component, 'fillSessionInformation').and.callThrough();

    component.ngOnInit();
    component.accessCodeLoginForm.controls['accessCode'].setValue('flcl1');
    component.handleSubmitAccessCode();

    component.userInfoLoginForm.controls['userName'].setValue('Nick Miller');
    component.userInfoLoginForm.controls['userEmail'].setValue(
      'nmiller@pepperwoodchronicals.com'
    );
    component.userInfoLoginForm.controls['userSchool'].setValue(
      'Coolidge Middle School'
    );
    component.userInfoLoginForm.controls['terms'].setValue(true);
    component.handleSubmitUserInfo();

    expect(component.toDirectory).toHaveBeenCalled();
    expect(component.registerUserWithGoogleAnalytics).toHaveBeenCalled();
    expect(mockRouter.navigate).not.toHaveBeenCalledWith([
      '/viewer/document/5',
    ]);
  });

  it('should fill session information with form data if no user data exists in current session', () => {
    mockSessionService.getSessionInformation.and.returnValue(null);
    component.ngOnInit();
    component.userInfoLoginForm.controls['userName'].setValue('Nicks Name');
    component.userInfoLoginForm.controls['userEmail'].setValue('Nicks Email');
    component.userInfoLoginForm.controls['userSchool'].setValue('Nicks School');
    component.accessCode = 'access-123';
    component.fillSessionInformation();

    expect(mockSessionService.setSessionInformation).toHaveBeenCalledWith({
      accessCode: component.accessCode,
      user: {
        id: 'test-id',
        name: 'Nicks Name',
        email: 'Nicks Email',
        school: 'Nicks School',
      },
    });
  });

  it('should return false when checking if userInfoAlreadySaved when session info doesnt exist', () => {
    mockSessionService.getSessionInformation.and.returnValue(null);
    component.ngOnInit();
    expect(component.userInfoAlreadySaved()).toEqual(false);
  });

  it('should auto-login and go toDirectory if there is an accessCode and authed queryParams', () => {
    spyOn(component, 'toDirectory').and.returnValue(of(null));
    const code = 'flcl1';
    mockRoute.snapshot.queryParams = {
      accessCode: code,
    };
    component.ngOnInit();
    expect(component.toDirectory).toHaveBeenCalledWith(code);
  });

  function loadMockServices(): void {
    mockRouter = {
      navigate: jasmine.createSpy('navigate'),
    };
    mockRoute = {
      snapshot: {
        queryParams: {},
      },
    };
    mockRedirectService = {
      setRedirectCookie: jasmine.createSpy('setRedirectCookie'),
    };
    mockAuthenticationService = {
      getUser: jasmine.createSpy('getUser'),
      isLoggedIn: jasmine.createSpy('isLoggedIn'),
      login: jasmine.createSpy('login'),
      currentUser: {
        wilsonId: 'test-id',
      },
    };
    mockDocumentGroup = {
      id: 101,
      title: 'Document Group Title',
      description: 'This is a test description.',
      allowAnonymousEntry: false,
      requiresUniversalLogin: false,
      coverImageUrl: 'https://picsum.photos/1920/1080',
      documents: [
        {
          id: 999,
          title: 'Document Title 1',
          description: 'This is the description for Document Title 1',
          thumbnailUrl: 'https://google.com',
          filePath: 'https://wilsonacademy.com',
          ordinal: 1,
          allowAdminDelete: false,
          allowPrint: false,
          allowSave: false,
          attachments: [],
          pageOffset: 1,
          watermark: true,
          selectable: false,
        } as ViewDocument,
        {
          id: 5,
          title: 'Document Title 2',
          description: 'This is the description for Document Title 2',
          thumbnailUrl: 'https://google.com',
          filePath: 'https://wilsonacademy.com',
          ordinal: 2,
          allowAdminDelete: false,
          allowPrint: false,
          allowSave: false,
          attachments: [],
          pageOffset: 1,
          watermark: false,
          selectable: false,
        } as ViewDocument,
      ],
      codeText: 'text123',
    } as ViewGroup;
    mockDocumentService = {
      getDocumentGroupByShareCode: jasmine
        .createSpy('getDocumentGroupByShareCode')
        .and.returnValue(of(mockDocumentGroup)),
      getDocumentGroupSecurityMetaByShareCode: jasmine
        .createSpy('getDocumentGroupSecurityMetaByShareCode')
        .and.returnValue(of(mockDocumentGroup)),
    };
    mockSessionService = {
      getSessionInformation: jasmine
        .createSpy('getSessionInformation')
        .and.returnValue({
          user: {
            name: 'A Good Name',
            email: 'A Fantastic Email',
            school: 'An INCREDIBLE School',
          },
        }),
      setSessionInformation: jasmine.createSpy('setSessionInformation'),
      key: 'dv::si',
    };

    mockTitleService = {
      setPageName: jasmine.createSpy('setPageName'),
    };
  }

  function setupTestBed(): void {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule],
      declarations: [LoginComponent],
      providers: [
        { provide: DocumentService, useValue: mockDocumentService },
        { provide: Router, useValue: mockRouter },
        { provide: ActivatedRoute, useValue: mockRoute },
        { provide: SessionService, useValue: mockSessionService },
        { provide: AuthenticationService, useValue: mockAuthenticationService },
        { provide: RedirectService, useValue: mockRedirectService },
        {
          provide: TitleService,
          useValue: mockTitleService,
        },
        {
          provide: 'productName',
          useValue: 'Document Viewer',
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }

  function setupComponent(): void {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    nextSubmitBtn = fixture.debugElement;
  }
});
