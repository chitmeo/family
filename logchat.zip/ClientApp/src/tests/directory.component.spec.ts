import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DirectoryComponent } from '../app/components/directory/directory.component';
import { DocumentService } from 'src/app/services/document.service';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { PaginatorState } from 'primeng/paginator';
import { SessionService } from 'src/app/services/session.service';
import { MatchHighlightService, TitleService } from '@wilson/wilsonng';
import { Wilson } from '../def/Wilson';
import ViewGroup = Wilson.ViewGroup;

describe('DirectoryComponent', () => {
  let component: DirectoryComponent;
  let fixture: ComponentFixture<DirectoryComponent>;
  let mockViewOptions: any;
  let mockFilters: any;
  let mockDocumentService: any;
  let mockSessionService: any;
  let mockDocumentGroup: ViewGroup;
  let mockMatchHighlightService: any;
  let mockRoute: any = null;
  let mockRouter: any;
  let mockTitleService: any;

  beforeEach(async () => {
    loadMockData();
    loadMockServices();
    setupTestBed();
    setupComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize correctly', () => {
    spyOn(component, 'initUI').and.callThrough();
    component.ngOnInit();
    expect(component.initUI).toHaveBeenCalled();
    expect(mockDocumentService.getCurrentDocumentGroup).toHaveBeenCalled();
  });

  it('should set up the UI correctly', () => {
    component.currentView = null;
    component.initUI();

    expect(mockSessionService.getFilters).toHaveBeenCalled();
    expect(component.currentView).toEqual(mockViewOptions[0].value);
    expect(component.filterBy).toEqual('');
  });

  it('should pre-fill filters if filter info already exists in session', () => {
    mockSessionService.getFilters.and.returnValue(JSON.stringify(mockFilters));
    component.currentView = null;
    component.initUI();

    expect(mockSessionService.getFilters).toHaveBeenCalled();
    expect(component.currentView).toEqual(mockFilters.currentView);
    expect(component.filterBy).toEqual(mockFilters.filterBy);
  });

  it('should parse an image', () => {
    expect(component.parseImage()).toEqual('');

    expect(component.parseImage('/stock/something.png')).toEqual(
      '../../../assets/img/something.png'
    );
  });

  it('should save filters in session storage', () => {
    component.currentView = mockFilters.currentView;
    component.filterBy = mockFilters.filterBy;

    component.saveFilters();

    expect(mockSessionService.saveFilters).toHaveBeenCalledWith(
      JSON.stringify(mockFilters)
    );
  });

  it('should clear the filters', () => {
    spyOn(component, 'saveFilters');
    component.filterBy = mockFilters.filterBy;

    component.clearFilter();
    expect(component.filterBy).toEqual('');
    expect(component.saveFilters).toHaveBeenCalledWith();
  });

  it('should load the document group correctly', () => {
    component.documentGroup = null;
    component.getGroupDocuments();

    expect(mockDocumentService.getCurrentDocumentGroup).toHaveBeenCalled();
    expect(component.documentGroup).toEqual(mockDocumentGroup);
  });

  it('should filter documents correctly', () => {
    component.documentGroup = mockDocumentGroup;

    const searchPhrase = 'test';
    const expectedDocuments = mockDocumentGroup.documents.filter(
      ({ title, description }) => {
        return (
          title.toLowerCase().includes(searchPhrase) ||
          description.toLowerCase().includes(searchPhrase)
        );
      }
    );

    component.filterBy = searchPhrase;
    component.getFilteredDocuments();
    expect(component.filteredDocumentsTable).toEqual(expectedDocuments);
  });

  it('should paginate', () => {
    const event = {
      page: 10,
      first: 5,
    };
    component.paginate(event as PaginatorState);
    expect(component.currentPage).toEqual(event.page);
    expect(component.firstRecord).toEqual(200);
  });

  it('should navigate user toDocument', () => {
    mockRoute.snapshot.queryParams = {
      xSite: '1',
      return: 'https://community.wilsonacademy.com',
      programId: 'fundations-1',
      title: 'Fundations Level 1',
      subtitle: 'Learning Community',
      reg: '1',
    };
    component.toDocument(2);
    expect(mockRouter.navigate).toHaveBeenCalledWith(['../', 'document', 2], {
      relativeTo: {
        snapshot: {
          queryParams: {
            xSite: '1',
            return: 'https://community.wilsonacademy.com',
            programId: 'fundations-1',
            title: 'Fundations Level 1',
            subtitle: 'Learning Community',
            reg: '1',
          },
        },
      },
      queryParams: {},
    });
  });

  it('should init xsite properly', () => {
    mockRoute.snapshot.queryParams = {
      xSite: '1',
      return: 'https://community.wilsonacademy.com',
      programId: 'fundations-1',
      title: 'Fundations Level 1',
      subtitle: 'Learning Community',
      reg: '1',
    };
    component.determineXSite();
    expect(component.queryParams['programId']).toEqual('fundations-1');
  });

  function loadMockData(): void {
    mockDocumentGroup = {
      id: 5318008,
      title: 'A group of documents',
      description: 'UwU a description',
      coverImageUrl: '/stock/fundations-cover.png',
      allowAnonymousEntry: true,
      requiresUniversalLogin: false,
      documents: [
        {
          id: 1,
          title: 'A document',
          description: 'Sick description, bro',
          thumbnailUrl: 'https://picsum.photos/3000/1920/1080',
          filePath: 'https://google.com',
          introductoryVideoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
          ordinal: 0,
          allowAdminDelete: false,
          allowPrint: false,
          allowSave: false,
          attachments: [],
          pageOffset: 1,
          watermark: false,
          selectable: false,
        },
        {
          id: 2,
          title: 'Test Document 2',
          description: 'Just a description',
          thumbnailUrl: 'https://picsum.photos/2000/1920/1080',
          filePath: 'https://google.com',
          introductoryVideoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
          ordinal: 1,
          allowAdminDelete: false,
          allowPrint: false,
          allowSave: false,
          attachments: [],
          pageOffset: 1,
          watermark: false,
          selectable: false,
        },
        {
          id: 3,
          title: 'Document 3',
          description: 'Just a test description',
          thumbnailUrl: 'https://picsum.photos/1000/1920/1080',
          filePath: 'https://google.com',
          introductoryVideoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
          ordinal: 2,
          allowAdminDelete: false,
          allowPrint: false,
          allowSave: false,
          attachments: [],
          pageOffset: 3,
          watermark: true,
          selectable: false,
        },
      ],
      codeText: 'text123',
    } as ViewGroup;

    mockFilters = {
      filterBy: 'lol',
      currentView: 'list',
    };
  }

  function loadMockServices(): void {
    mockRouter = {
      navigate: jasmine.createSpy('navigate'),
    };

    mockRoute = {
      snapshot: {
        queryParams: {},
      },
    };

    mockDocumentService = {
      getCurrentDocumentGroup: jasmine
        .createSpy('getCurrentDocumentGroup')
        .and.returnValue(mockDocumentGroup),
    };

    mockMatchHighlightService = {
      markContentMatches: jasmine
        .createSpy('markContentMatches')
        .and.callFake((data) => data),
    };

    mockViewOptions = [
      { label: 'Test', value: 'test' },
      { label: 'List', value: 'list' },
      { label: 'Grid', value: 'grid' },
    ];

    mockSessionService = {
      saveFilters: jasmine.createSpy('saveFilters'),
      getFilters: jasmine.createSpy('getFilters'),
    };

    mockTitleService = {
      setPageName: jasmine.createSpy('setPageName'),
    };
  }

  // Configure the test bed
  function setupTestBed(): void {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes([])],
      declarations: [DirectoryComponent],
      providers: [
        { provide: DocumentService, useValue: mockDocumentService },
        { provide: Router, useValue: mockRouter },
        { provide: ActivatedRoute, useValue: mockRoute },
        { provide: SessionService, useValue: mockSessionService },
        { provide: MatchHighlightService, useValue: mockMatchHighlightService },
        {
          provide: TitleService,
          useValue: mockTitleService,
        },
        {
          provide: 'productName',
          useValue: 'Document Viewer',
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }

  // Initialize the component var
  function setupComponent(): void {
    fixture = TestBed.createComponent(DirectoryComponent);
    component = fixture.componentInstance;
    component.viewOptions = mockViewOptions;
    component.ngOnInit();
  }
});
