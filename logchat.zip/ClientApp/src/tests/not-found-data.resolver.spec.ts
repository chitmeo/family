import { NO_ERRORS_SCHEMA } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import {
  NotFoundData,
  RouterNavigationService,
  TitleService,
} from '@wilson/wilsonng';
import { NotFoundDataResolver } from 'src/app/resolvers/not-found-data.resolver';

describe('NotFoundDataResolver', () => {
  let service: NotFoundDataResolver;
  let mockTitleService: any;
  let mockRouterNavigationService: any;

  beforeEach(() => {
    loadMockServices();
    configureTestBed();
    service = TestBed.inject(NotFoundDataResolver);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return a NotFoundData object', () => {
    const data = service.resolve(null, null) as NotFoundData;
    expect(data).toEqual({
      iconUrl: '../../assets/svg/floating-icons-full.svg',
      title: 'Page Not Found',
      message: '',
      goBackFn: jasmine.any(Function),
    });
    expect(mockTitleService.generatePageTitleWithNewName).toHaveBeenCalledWith(
      'Page Not Found'
    );
    // eslint-disable-next-line @typescript-eslint/ban-types
    (data.goBackFn as Function)();
    expect(mockRouterNavigationService.goToPreviousUrl).toHaveBeenCalledWith(
      '/login'
    );
  });

  function configureTestBed(): void {
    TestBed.configureTestingModule({
      providers: [
        { provide: TitleService, useValue: mockTitleService },
        {
          provide: RouterNavigationService,
          useValue: mockRouterNavigationService,
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    });
  }

  function loadMockServices(): void {
    mockTitleService = {
      generatePageTitleWithNewName: jasmine
        .createSpy('generatePageTitleWithNewName')
        .and.returnValue('Page Not Found'),
    };

    mockRouterNavigationService = {
      goToPreviousUrl: jasmine.createSpy('goToPreviousUrl'),
    };
  }
});
