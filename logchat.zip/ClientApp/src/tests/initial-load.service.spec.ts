import { TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { InitialLoadService } from '../app/services/initial-load.service';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { GoogleAnalyticsService } from '@wilson/wilsonng';
import { LogService } from 'src/app/services/log.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

describe('InitialLoadService', () => {
  let service: InitialLoadService;
  let mockHttpClient: any;
  let mockLogService: any;
  let mockGoogleAnalyticsService: any;
  let mockRouter: any;
  let initialLoadData: any;

  beforeEach(() => {
    loadMockData();
    loadMockServices();
    configureTestBed();
    service = TestBed.inject(InitialLoadService);
    (service as any).httpClient = mockHttpClient;
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should resolve an initialLoad', () => {
    mockHttpClient.post.and.returnValue(of({ ...initialLoadData }));
    expect(service.initialLoad).toBeUndefined();
    const iLoad = service.getInitialLoad();
    expect(mockRouter.initialNavigation).toHaveBeenCalled();
    expect(service.initialLoad).toBeTruthy();
    expect(iLoad instanceof Promise).toEqual(true);
  });

  it('should store initial load values if return from api not null', () => {
    mockHttpClient.post.and.returnValue(of({ ...initialLoadData }));
    service.getInitialLoad();
    expect(mockLogService.setupDatadogMonitoring).toHaveBeenCalled();
    expect(mockGoogleAnalyticsService.setKey).toHaveBeenCalled();
    expect(mockGoogleAnalyticsService.initialize).toHaveBeenCalled();
  });

  it('should NOT store initial load values if return from api is null', () => {
    mockHttpClient.post.and.returnValue(of(null));
    service.getInitialLoad();
    expect(mockLogService.setupDatadogMonitoring).not.toHaveBeenCalled();
    expect(mockGoogleAnalyticsService.setKey).not.toHaveBeenCalled();
    expect(mockGoogleAnalyticsService.initialize).not.toHaveBeenCalled();
  });

  it('should set appropriate values if production is true', () => {
    mockHttpClient.post.and.returnValue(of({ ...initialLoadData }));
    service.getInitialLoad();

    // PROD key
    expect(mockGoogleAnalyticsService.setKey).toHaveBeenCalledWith(
      'G-Z2R78WLQ1V'
    );
  });

  it('should set appropriate values if production is false', () => {
    const data = { ...initialLoadData };
    data.isProduction = false;
    mockHttpClient.post.and.returnValue(of(data));
    service.getInitialLoad();

    // DEV key
    expect(mockGoogleAnalyticsService.setKey).toHaveBeenCalledWith(
      'G-5H2HM5NX05'
    );
  });

  function configureTestBed(): void {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes([]), HttpClientTestingModule],
      providers: [
        { provide: HttpClient, useValue: mockHttpClient },
        { provide: LogService, useValue: mockLogService },
        { provide: Router, useValue: mockRouter },
        {
          provide: GoogleAnalyticsService,
          useValue: mockGoogleAnalyticsService,
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    });
  }

  function loadMockData(): void {
    initialLoadData = {
      isProduction: true,
      isDownForMaintenance: false,
      isComingSoon: false,
      tokens: {
        DATADOG_MONITORING_ENVIRONMENT: 'some_env',
        DATADOG_SAMPLE_RATE: '65',
      },
      currentBuildNumber: '999999',
    };
  }

  function loadMockServices(): void {
    mockRouter = {
      initialNavigation: jasmine.createSpy('initialNavigation'),
    };
    mockHttpClient = {
      post: jasmine.createSpy('post'),
    };
    mockGoogleAnalyticsService = {
      initialize: jasmine.createSpy('initialize'),
      setKey: jasmine.createSpy('setKey'),
    };
    mockLogService = {
      setupDatadogMonitoring: jasmine.createSpy('setupDatadogMonitoring'),
    };
  }
});
