import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdminGroupsCrudComponent } from '../app/components/admin-groups-crud/admin-groups-crud.component';
import { AdminService } from '../app/services/admin.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FileSelectEvent } from 'primeng/fileupload';
import { AutoCompleteCompleteEvent } from 'primeng/autocomplete';
import { of } from 'rxjs';
import { ToastService } from '../app/services/toast.service';
import {
  RouterNavigationService,
  AuthenticationService,
  TitleService,
} from '@wilson/wilsonng';
import { Wilson } from '../def/Wilson';
import Group = Wilson.Group;
import DocumentGroup = Wilson.DocumentGroup;
import Document = Wilson.Document;

describe('AdminGroupsCrudComponent', () => {
  let component: AdminGroupsCrudComponent;
  let fixture: ComponentFixture<AdminGroupsCrudComponent>;
  let mockGroup: Group;
  let mockDocuments: Document[];
  let mockDocumentGroup: DocumentGroup;
  let mockAdminService: any;
  let mockToastService: any;
  let mockRouter: any;
  let mockRoute: any;
  let mockDocumentPanel: any;
  let mockRouterNavigationService: any;
  let mockAuthService: any;
  let mockTitleService: any;

  beforeEach(() => {
    loadMockData();
    loadMockServices();
    setupTestBed();
  });

  beforeEach(() => {
    setupComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should init in the correct mode (create/edit)', () => {
    mockRoute.snapshot.params.id = 'create';
    expect(component.reorderMode).toBe(false);
    expect(component.selectedDocumentIndex).toEqual(-1);
    component.ngOnInit();
    expect(component.createMode).toEqual(true);

    // when given an actual id
    mockRoute.snapshot.params.id = '1';
    component.ngOnInit();
    expect(component.createMode).toEqual(false);
  });

  it('should init empty form in create mode', () => {
    expect(component.getValue('id')).toEqual(0);
    expect(component.getValue('title')).toEqual('');
    expect(component.getValue('description')).toEqual('');
  });

  it('should load group values in edit mode', () => {
    component.id = mockGroup.id;
    component.getGroup().subscribe();

    expect(mockAdminService.getGroup).toHaveBeenCalled();
    expect(component.getValue('id')).toEqual(mockGroup.id);
    expect(component.getValue('title')).toEqual(mockGroup.title);
  });

  it('should show a crudNotFound toast message if getGroup fails', () => {
    component.id = mockGroup.id;
    mockAdminService.getGroup.and.returnValue(of(null));
    component.getGroup().subscribe();

    expect(mockAdminService.getGroup).toHaveBeenCalled();
    expect(mockToastService.crudNotFound).toHaveBeenCalledWith(
      'Group',
      component.id,
      '/admin/groups'
    );
  });

  it('should return whether or not the form is pristine on canDeactivate', () => {
    component.groupForm.markAsPristine();
    expect(component.canDeactivate()).toEqual(true);

    component.groupForm.markAsDirty();
    expect(component.canDeactivate()).toEqual(false);
  });

  it('should clear errors', () => {
    component.errors.description = 'Description has a test error.';
    component.clearError('description');
    expect(component.errors.description).toEqual('');
  });

  it('should update form control values', () => {
    component.groupForm.controls['id'].setValue(0);
    component.setValue('id', 999);
    expect(component.groupForm.controls['id'].value).toEqual(999);
  });

  it('should retrieve form control values', () => {
    component.groupForm.controls['title'].setValue('Test');
    expect(component.getValue('title')).toEqual('Test');
  });

  it('should dirtify the form', () => {
    component.dirtify();
    expect(component.groupForm.pristine).toEqual(false);
  });

  it('should go back', () => {
    component.goBack();
    expect(mockRouterNavigationService.goToPreviousUrl).toHaveBeenCalledWith(
      '/admin/groups'
    );
  });

  const requiredFields = ['title', 'description'];
  for (const field of requiredFields) {
    it(`should invalidate when '${field}' is blank`, () => {
      component.submitGroup();
      expect(component.errors[field]).toBeTruthy();
      expect(mockAdminService.upsertGroup).not.toHaveBeenCalled();
    });
  }

  it('should add a document to the group', () => {
    component.documentGroups = [];
    component.onDocumentSelect({
      value: mockDocuments[0],
      originalEvent: null,
    });
    expect(component.documentGroups).toContain(mockDocumentGroup);
    expect(mockDocumentPanel.hide).toHaveBeenCalled(); // gets called after a document is selected
  });

  it('should show an error when a duplicate document is selected', () => {
    component.documentGroups.push(mockDocumentGroup);
    component.onDocumentSelect({
      value: mockDocuments[0],
      originalEvent: null,
    });
    expect(component.documentGroups).toEqual([mockDocumentGroup]);
    expect(mockToastService.crudDuplication).toHaveBeenCalled();
    expect(mockDocumentPanel.hide).toHaveBeenCalled(); // gets called after a document is selected
  });

  it('should remove a document from the group', () => {
    component.documentGroups = [
      { documentId: 1 } as DocumentGroup,
      { documentId: 2 } as DocumentGroup,
    ];
    component.removeDocument(1);
    expect(component.documentGroups).not.toContain({
      documentId: 1,
    } as DocumentGroup);
  });

  it('should toggle reorderMode', () => {
    component.selectedDocumentIndex = 5;
    expect(component.reorderMode).toBe(false);

    component.toggleReorderMode();
    expect(component.reorderMode).toBe(true);
    expect(component.selectedDocumentIndex).toEqual(-1);

    component.toggleReorderMode();
    expect(component.reorderMode).toBe(false);
    expect(component.selectedDocumentIndex).toEqual(-1);
  });

  it('should select a document for reorder', () => {
    component.toggleReorderMode();
    spyOn(component, 'dirtify');
    component.documentGroups = [
      { documentId: 1 } as DocumentGroup,
      { documentId: 2 } as DocumentGroup,
    ];

    component.selectOrReorderDocument(1);
    expect(component.selectedDocumentIndex).toEqual(1);
    expect(component.reorderMode).toBe(true);
    expect(component.dirtify).not.toHaveBeenCalled();
  });

  it('should reorder a document in a group', () => {
    component.toggleReorderMode();
    spyOn(component, 'dirtify');
    component.documentGroups = [
      { documentId: 1 } as DocumentGroup,
      { documentId: 2 } as DocumentGroup,
      { documentId: 3 } as DocumentGroup,
    ];

    component.selectOrReorderDocument(0);
    component.selectOrReorderDocument(2);
    expect(component.selectedDocumentIndex).toEqual(-1);
    expect(component.dirtify).toHaveBeenCalledTimes(1);
    expect(component.documentGroups.map((dg) => dg.documentId)).toEqual([
      2, 1, 3,
    ]);

    component.selectOrReorderDocument(2);
    component.selectOrReorderDocument(0);
    expect(component.documentGroups.map((dg) => dg.documentId)).toEqual([
      3, 2, 1,
    ]);

    // Order should stay the same since the same document was selected twice in a row
    component.selectOrReorderDocument(2);
    component.selectOrReorderDocument(2);
    expect(component.documentGroups.map((dg) => dg.documentId)).toEqual([
      3, 2, 1,
    ]);
  });

  it('should say whether a row is currently selected for reorder', () => {
    component.documentGroups = [
      { documentId: 1 } as DocumentGroup,
      { documentId: 2 } as DocumentGroup,
    ];
    component.selectedDocumentIndex = 0;
    expect(component.rowIsSelected(1)).toBe(false);
    expect(component.rowIsSelected(0)).toBe(true);

    component.selectedDocumentIndex = 1;
    expect(component.rowIsSelected(1)).toBe(true);
    expect(component.rowIsSelected(0)).toBe(false);

    component.selectedDocumentIndex = -1;
    expect(component.rowIsSelected(1)).toBe(false);
  });

  it('should delete the group', () => {
    component.deleteGroup().subscribe(() => {
      expect(mockAdminService.deleteGroup).toHaveBeenCalled();
      expect(mockRouter.navigate).toHaveBeenCalled();
    });
  });

  it('should insert the group when all fields are valid in create mode', () => {
    const testCover = new File([], 'test-cover.png');
    component.coverPicker = {
      clear: jasmine.createSpy('clear'),
    } as any;

    component.documentGroups = [];
    component.initTime = new Date('12/12/2012');
    component.coverMode = 'custom';
    component.setValue('title', mockGroup.title);
    component.setValue('description', mockGroup.description);
    component.setCover({ files: [testCover] } as FileSelectEvent);

    component.submitGroup();
    expect(mockAdminService.upsertGroup).toHaveBeenCalledWith(
      {
        id: 0,
        title: mockGroup.title,
        description: mockGroup.description,
        documentGroups: [],
        accessCodes: [],
        createdDate: component.initTime,
        createdBy: mockGroup.createdBy,
        modifiedBy: mockGroup.modifiedBy,
      },
      testCover
    );
    expect(mockToastService.crudSuccess).toHaveBeenCalled();
    expect(mockRouterNavigationService.goToPreviousUrl).toHaveBeenCalledWith(
      '/admin/groups'
    );
  });

  it('should update the group when all fields are valid in edit mode', () => {
    component.createMode = false;
    component.id = 1;
    mockGroup.title = 'New Test Group';

    const simpleMockGroup = { ...mockGroup };
    delete simpleMockGroup.createdBy;
    simpleMockGroup.documentGroups = simpleMockGroup.documentGroups.map(
      (dg) =>
        ({
          documentId: dg.documentId,
          ordinal: dg.ordinal,
        } as DocumentGroup)
    );

    component.getGroup().subscribe();
    component.submitGroup();
    expect(mockAdminService.upsertGroup).toHaveBeenCalledWith(
      simpleMockGroup,
      null
    );
    expect(mockToastService.crudSuccess).toHaveBeenCalled();
    expect(mockRouterNavigationService.goToPreviousUrl).toHaveBeenCalledWith(
      '/admin/groups'
    );
  });

  it('should show a crudFailure toast message when upsertGroup fails', () => {
    mockAdminService.upsertGroup.and.returnValue(of(-1));
    component.createMode = false;
    component.id = 1;
    mockGroup.title = 'New Test Group';

    const simpleMockGroup = { ...mockGroup };
    delete simpleMockGroup.createdBy;
    simpleMockGroup.documentGroups = simpleMockGroup.documentGroups.map(
      (dg) =>
        ({
          documentId: dg.documentId,
          ordinal: dg.ordinal,
        } as DocumentGroup)
    );

    component.getGroup().subscribe();
    component.submitGroup();
    expect(mockAdminService.upsertGroup).toHaveBeenCalledWith(
      simpleMockGroup,
      null
    );
    expect(mockToastService.crudFailure).toHaveBeenCalledWith(
      'Group',
      'update'
    );
    expect(mockRouterNavigationService.goToPreviousUrl).not.toHaveBeenCalled();
  });

  it('should ask for confirmation before deleting a document code, then go delete it', () => {
    spyOn(window, 'confirm').and.returnValue(true);
    const id = 1;
    component.confirmAccessCodeDeletion(id);
    expect(mockAdminService.deleteAccessCode).toHaveBeenCalledWith(id);
  });

  it('should ask for confirmation before deleting a document code, and do nothing if the prompt comes back false', () => {
    spyOn(window, 'confirm').and.returnValue(false);
    const id = 1;
    component.confirmAccessCodeDeletion(id);
    expect(mockAdminService.deleteAccessCode).not.toHaveBeenCalled();
  });

  it('should ask for confirmation before deleting a group, then go delete it', () => {
    spyOn(window, 'confirm').and.returnValue(true);
    component.id = 1;
    component.createMode = false;
    component.confirmDeletion();
    expect(mockAdminService.deleteGroup).toHaveBeenCalledWith(component.id);
  });

  it('should ask for confirmation before deleting a group, and do nothing if the prompt comes back false', () => {
    spyOn(window, 'confirm').and.returnValue(false);
    component.id = 1;
    component.createMode = false;
    component.confirmDeletion();
    expect(mockAdminService.deleteGroup).not.toHaveBeenCalled();
  });

  it('should not prompt for group deletion if there is no group id or if the component is in createMode', () => {
    spyOn(window, 'confirm');
    component.id = 1;
    component.createMode = true;
    component.confirmDeletion();
    expect(window.confirm).not.toHaveBeenCalled();
    expect(mockAdminService.deleteGroup).not.toHaveBeenCalled();

    component.id = null;
    component.confirmDeletion();
    expect(window.confirm).not.toHaveBeenCalled();
    expect(mockAdminService.deleteGroup).not.toHaveBeenCalled();
  });

  it('should fill document suggestions', () => {
    const event = {
      query: 'doc',
    };
    component.documentGroups = [mockDocumentGroup];
    expect(component.documentGroups.length).toBe(1);
    component.documentFillSuggestions(event as AutoCompleteCompleteEvent);
    expect(mockAdminService.getDocuments).toHaveBeenCalled();
    // Should have started with 3 returned documents,
    // then filtered out the one that already exists in component's documentGroup
    expect(component.documentSuggestions.length).toBe(2);
  });

  // Set up mock data, providers and method spies
  function loadMockData(): void {
    mockGroup = {
      id: 1,
      title: 'Sample Group 1',
      description: 'Lorem ipsum dolor sit amet',
      coverImageUrl: '/stock/fundations-cover.png',
      documentGroups: [
        {
          documentId: 1,
          groupId: 1,
          ordinal: 0,
          group: null,
          document: null,
        },
      ],
      accessCodes: [],
      createdDate: new Date(),
      createdBy: 'User Name',
      modifiedBy: 'User Name',
    } as Group;

    mockDocuments = [
      {
        id: 999,
        title: 'Test',
        description: 'Lorem ipsum',
      } as Document,
      {
        id: 888,
        title: 'Test 2',
        description: 'Lorem ipsum',
      } as Document,
      {
        id: 777,
        title: 'Test 3',
        description: 'Lorem ipsum',
      } as Document,
    ];

    mockDocumentGroup = {
      documentId: mockDocuments[0].id,
      ordinal: 0,
      document: {
        title: mockDocuments[0].title,
        description: mockDocuments[0].description,
      },
    } as DocumentGroup;

    mockRoute = {
      snapshot: {
        params: {
          id: 'create',
        },
      },
    };
  }

  function loadMockServices(): void {
    mockRouter = {
      navigate: jasmine.createSpy('navigate'),
    };

    mockDocumentPanel = {
      hide: jasmine.createSpy('hide'),
    };

    mockToastService = {
      crudSuccess: jasmine.createSpy('crudSuccess'),
      crudDuplication: jasmine.createSpy('crudDuplication'),
      crudNotFound: jasmine.createSpy('crudNotFound'),
      crudFailure: jasmine.createSpy('crudFailure'),
    };

    mockRouterNavigationService = {
      goToPreviousUrl: jasmine.createSpy('goToPreviousUrl'),
    };

    mockAdminService = {
      getGroup: jasmine.createSpy('getGroup').and.returnValue(of(mockGroup)),
      upsertGroup: jasmine.createSpy('upsertGroup').and.returnValue(of(1)),
      deleteGroup: jasmine.createSpy('deleteGroup').and.returnValue(of(1)),
      getDocuments: jasmine
        .createSpy('getDocuments')
        .and.returnValue(of(mockDocuments)),
      deleteAccessCode: jasmine
        .createSpy('deleteAccessCode')
        .and.returnValue(of({})),
    };

    mockAuthService = {
      getUser: jasmine
        .createSpy('getUser')
        .and.returnValue(of({ name: 'User Name' })),
    };

    mockTitleService = {
      setPageName: jasmine.createSpy('setPageName'),
    };
  }

  // Configure the test bed
  function setupTestBed(): void {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule],
      declarations: [AdminGroupsCrudComponent],
      providers: [
        { provide: ToastService, useValue: mockToastService },
        { provide: AdminService, useValue: mockAdminService },
        { provide: AuthenticationService, useValue: mockAuthService },
        { provide: Router, useValue: mockRouter },
        { provide: ActivatedRoute, useValue: mockRoute },
        {
          provide: RouterNavigationService,
          useValue: mockRouterNavigationService,
        },
        {
          provide: TitleService,
          useValue: mockTitleService,
        },
        {
          provide: 'productName',
          useValue: 'Document Viewer',
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }

  // Initialize the component var
  function setupComponent(): void {
    fixture = TestBed.createComponent(AdminGroupsCrudComponent);
    component = fixture.componentInstance;
    component.documentPanel = mockDocumentPanel;

    component.ngOnInit();
  }
});
