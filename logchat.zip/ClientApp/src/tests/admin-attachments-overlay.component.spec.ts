import { TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { of } from 'rxjs';
import { CommunityApiService } from 'src/app/services/community-api.service';
import { MockData } from './mockdata';
import { AdminAttachmentsOverlayComponent } from 'src/app/components/admin-attachments-overlay/admin-attachments-overlay.component';
import { MessageService } from 'primeng/api';
import { AttachmentsService } from 'src/app/services/attachments.service';

describe('AdminAttachmentsOverlayComponent', () => {
  let component: AdminAttachmentsOverlayComponent;
  let mockCommunityService: any;
  let mockMessageService: any;
  let mockAttachmentService: any;
  let fake: MockData;

  beforeEach(() => {
    loadMockData();
    loadMockServices();
    configureTestBed();
    setupComponent();
  });

  it(`should show message error if either argument is missing from addAttachment method`, () => {
    const video = fake.videos[0];
    const pageNumber = 1;

    // if called without page number
    component.addAttachment(null, video);
    expect(mockMessageService.add).toHaveBeenCalled();

    // if called without video object
    component.addAttachment(pageNumber, null);
    expect(mockMessageService.add).toHaveBeenCalled();
  });

  it('should fetch video data to suggest to user for autocomplete', () => {
    component.suggestVideos({ originalEvent: null, query: 'test string' }, 'K');
    expect(mockCommunityService.searchVideos).toHaveBeenCalledWith(
      'test string',
      'K'
    );
  });

  function configureTestBed(): void {
    TestBed.configureTestingModule({
      providers: [
        { provide: CommunityApiService, useValue: mockCommunityService },
        { provide: MessageService, useValue: mockMessageService },
        { provide: AttachmentsService, useValue: mockAttachmentService },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    });
    spyOn(sessionStorage, 'setItem');
    spyOn(window.sessionStorage, 'removeItem');
  }

  function loadMockData(): void {
    fake = new MockData();
  }

  function loadMockServices(): void {
    mockCommunityService = {
      searchVideos: jasmine
        .createSpy('searchVideos')
        .and.returnValue(of(fake.videos)),
    };
    mockMessageService = {
      add: jasmine.createSpy('add'),
    };
    mockAttachmentService = {
      addAttachment: jasmine.createSpy('addAttachment'),
    };
  }

  function setupComponent(): void {
    component = TestBed.createComponent(
      AdminAttachmentsOverlayComponent
    ).componentInstance;
  }
});
