import { TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ToastService } from 'src/app/services/toast.service';
import { MessageService } from 'primeng/api';
import { Router } from '@angular/router';

describe('ToastService', () => {
  let service: ToastService;
  let mockMessageService: any;
  let mockRouter: any;

  beforeEach(() => {
    loadMockServices();
    configureTestBed();
    service = TestBed.inject(ToastService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should show a toast on crud success', () => {
    const type = 'Success Test';
    const method = 'save';
    const detail = 'toast-service-test';
    service.crudSuccess(type, method, detail);
    expect(mockMessageService.add).toHaveBeenCalledWith({
      severity: 'success',
      summary: `${type} ${method}d`,
      detail: `'${detail}' was ${method}d successfully.`,
    });
  });

  it('should show a toast on crud success, using default message if no detail string was provided', () => {
    const type = 'Success Test';
    const method = 'save';
    service.crudSuccess(type, method);
    expect(mockMessageService.add).toHaveBeenCalledWith({
      severity: 'success',
      summary: `${type} ${method}d`,
      detail: `${type} was saved successfully.`,
    });
  });

  it('should show a toast on crud failure', () => {
    const type = 'Failure Test';
    const method = 'delete';
    service.crudFailure(type, method);
    expect(mockMessageService.add).toHaveBeenCalledWith({
      severity: 'error',
      summary: `Something went wrong`,
      detail: `${type} was not ${method}d.`,
    });
  });

  it('should show a toast on entity not found', () => {
    const type = 'Entity Test';
    const id = 999;
    const redirect = '/test';
    service.crudNotFound(type, id, redirect);
    expect(mockMessageService.add).toHaveBeenCalledWith({
      severity: 'error',
      summary: `${type} Not Found`,
      detail: `Found no matching ${type.toLowerCase()} with id '${id}'.`,
    });
    expect(mockRouter.navigate).toHaveBeenCalledWith([redirect]);
  });

  it('should show a toast on crud element duplication', () => {
    const type = 'Duplication Test';
    const detail = 'test';
    service.crudDuplication(type, detail);
    expect(mockMessageService.add).toHaveBeenCalledWith({
      severity: 'error',
      summary: `${type} not added`,
      detail: `${detail} has already been selected.`,
    });
  });

  function configureTestBed(): void {
    TestBed.configureTestingModule({
      providers: [
        { provide: MessageService, useValue: mockMessageService },
        { provide: Router, useValue: mockRouter },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    });
  }

  function loadMockServices(): void {
    mockMessageService = {
      add: jasmine.createSpy('add'),
    };

    mockRouter = {
      navigate: jasmine.createSpy('navigate'),
    };
  }
});
