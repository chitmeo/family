import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
  FloatingIconsComponent,
  fullHeightImage,
  halfImage,
} from '../app/components/floating-icons/floating-icons.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('FloatingIconsComponent', () => {
  let component: FloatingIconsComponent;
  let fixture: ComponentFixture<FloatingIconsComponent>;

  beforeEach(async () => {
    setupTestBed();
  });

  beforeEach(() => {
    setupComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show the correct UI based on parameters', () => {
    // when half
    component.fullHeight = false;
    expect(component.iconImage()).toEqual(halfImage);

    // when full
    component.fullHeight = true;
    expect(component.iconImage()).toEqual(fullHeightImage);
  });

  // Configure the test bed
  function setupTestBed(): void {
    TestBed.configureTestingModule({
      declarations: [FloatingIconsComponent],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }

  // Initialize the component var
  function setupComponent(): void {
    fixture = TestBed.createComponent(FloatingIconsComponent);
    component = fixture.componentInstance;
  }
});
