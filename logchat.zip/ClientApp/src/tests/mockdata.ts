import { DocumentPageWithAttachment } from 'src/app/services/admin.service';
import { Video } from '../app/services/community-api.service';
import { Wilson } from '../def/Wilson';
import ViewGroup = Wilson.ViewGroup;

export class MockData {
  videos: Video[];
  pagesWithAttachments: DocumentPageWithAttachment[];
  pageWithVideoData: DocumentPageWithAttachment;
  pageWithoutVideoData: DocumentPageWithAttachment;
  documentGroup: ViewGroup;
  resourceIds: string;

  constructor() {
    this.videos = this.getVideos();
    this.pagesWithAttachments = this.getPagesWithAttachments();
    this.pageWithoutVideoData = this.getPagesWithAttachments()[0];
    this.pageWithVideoData = this.getPageWithVideoData(
      this.pageWithoutVideoData
    );
    this.documentGroup = this.getDocumentGroup();
    this.resourceIds = this.getResourceIds();
  }

  getDocumentGroup(): ViewGroup {
    return {
      id: 5318008,
      title: 'A group of documents',
      description: 'UwU a description',
      coverImageUrl: '/stock/fundations-cover.png',
      allowAnonymousEntry: true,
      requiresUniversalLogin: false,
      documents: [
        {
          id: 1,
          title: 'A document',
          description: 'Sick description, bro',
          thumbnailUrl: 'https://picsum.photos/3000/1920/1080',
          filePath: 'https://google.com',
          introductoryVideoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
          ordinal: 0,
          allowAdminDelete: false,
          allowPrint: false,
          allowSave: false,
          attachments: [],
          pageOffset: 1,
          watermark: true,
          selectable: false,
        },
        {
          id: 2,
          title: 'Test Document 2',
          description: 'Just a description',
          thumbnailUrl: 'https://picsum.photos/2000/1920/1080',
          introductoryVideoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
          filePath: 'https://google.com',
          ordinal: 1,
          allowAdminDelete: false,
          allowPrint: true,
          allowSave: true,
          attachments: [],
          pageOffset: 1,
          watermark: false,
          selectable: false,
        },
        {
          id: 3,
          title: 'Document 3',
          description: 'Just a test description',
          thumbnailUrl: 'https://picsum.photos/1000/1920/1080',
          introductoryVideoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
          filePath: 'https://google.com',
          ordinal: 2,
          allowAdminDelete: false,
          allowPrint: false,
          allowSave: false,
          attachments: [],
          pageOffset: 3,
          watermark: false,
          selectable: false,
        },
      ],
      codeText: 'text123',
    } as ViewGroup;
  }
  getPagesWithAttachments(): DocumentPageWithAttachment[] {
    return [
      {
        pageNumber: 1,
        resourceIds:
          '61b0d79c9639585901265725,61b0d79c9639585901265727,61b0d79c963958590126572a,61b0d79c9639585901265732,61b0d79c9639585901265733',
      },
      {
        pageNumber: 2,
        resourceIds:
          '61b0d79c9639585901265725,61b0d79c9639585901265727,61b0d79c963958590126572a,61b0d79c9639585901265732,61b0d79c9639585901265733',
      },
      {
        pageNumber: 3,
        resourceIds:
          '61b0d79c9639585901265725,61b0d79c9639585901265727,61b0d79c963958590126572a,61b0d79c9639585901265732,61b0d79c9639585901265733',
      },
    ];
  }

  getPageWithVideoData(
    pageWithoutVideoData: DocumentPageWithAttachment
  ): DocumentPageWithAttachment {
    return {
      ...pageWithoutVideoData,
      videos: this.videos,
    };
  }

  getVideos(): Video[] {
    return [
      {
        id: '61b0d79c9639585901265725',
        name: 'voluptatem voluptas facilis',
        description: 'Harum nemo aut vel eaque et non.',
        url: 'https://videos.sproutvideo.com/embed/119dd9b31b19e7cd98/b26905e624b48b1e?playerTheme=dark&amp;playerColor=2f3437',
        backupUrl: null,
        imageUrl: 'https://picsum.photos/480/270/?image=94',
      },
      {
        id: '61b0d79c9639585901265727',
        name: 'et reprehenderit qui',
        description:
          'Necessitatibus dicta omnis et suscipit repudiandae et voluptatem.',
        url: 'https://videos.sproutvideo.com/embed/119dd9b31b19e7cd98/b26905e624b48b1e?playerTheme=dark&amp;playerColor=2f3437',
        backupUrl: null,
        imageUrl: 'https://picsum.photos/480/270/?image=740',
      },
      {
        id: '61b0d79c963958590126572a',
        name: 'quibusdam modi voluptates',
        description:
          'Blanditiis a quaerat aut natus optio non quasi recusandae.',
        url: 'https://videos.sproutvideo.com/embed/119dd9b31b19e7cd98/b26905e624b48b1e?playerTheme=dark&amp;playerColor=2f3437',
        backupUrl: null,
        imageUrl: 'https://picsum.photos/480/270/?image=519',
      },
      {
        id: '61b0d79c9639585901265732',
        name: 'modi vero impedit',
        description: 'Maiores qui fugit amet facere perspiciatis.',
        url: 'https://videos.sproutvideo.com/embed/119dd9b31b19e7cd98/b26905e624b48b1e?playerTheme=dark&amp;playerColor=2f3437',
        backupUrl: null,
        imageUrl: 'https://picsum.photos/480/270/?image=668',
      },
      {
        id: '61b0d79c9639585901265733',
        name: 'sapiente nostrum explicabo',
        description: 'Ad dolor minima dolores sapiente omnis consectetur.',
        url: 'https://videos.sproutvideo.com/embed/119dd9b31b19e7cd98/b26905e624b48b1e?playerTheme=dark&amp;playerColor=2f3437',
        backupUrl: null,
        imageUrl: 'https://picsum.photos/480/270/?image=769',
      },
    ];
  }

  getResourceIds(): string {
    return `61b0d79c9639585901265725,61b0d79c9639585901265727,61b0d79c963958590126572a,61b0d79c9639585901265732,61b0d79c9639585901265733`;
  }
}
