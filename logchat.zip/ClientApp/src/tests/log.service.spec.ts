import { TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { LogService } from '../app/services/log.service';
import { datadogRum } from '@datadog/browser-rum';

describe('LogService', () => {
  let service: LogService;

  beforeEach(() => {
    configureTestBed();
    service = TestBed.inject(LogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should set up datadog monitoring', () => {
    spyOn(datadogRum, 'init');
    service.setupDatadogMonitoring(
      'randomEnviron',
      'somesamplerate',
      'samplereplayrate'
    );
    expect(datadogRum.init).toHaveBeenCalled();
  });

  it('should not set up datadog monitoring if there is no monitoring environment token', () => {
    spyOn(datadogRum, 'init');
    service.setupDatadogMonitoring(null, 'somesamplerate', 'samplereplayrate');
    expect(datadogRum.init).not.toHaveBeenCalled();
  });

  function configureTestBed(): void {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes([])],
      schemas: [NO_ERRORS_SCHEMA],
    });
  }
});
