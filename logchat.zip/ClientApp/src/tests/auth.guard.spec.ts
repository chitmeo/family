import { TestBed } from '@angular/core/testing';
import { AuthGuard } from 'src/app/guards/auth.guard';
import { NO_ERRORS_SCHEMA } from '@angular/core';

import { AuthenticationService, RedirectService } from '@wilson/wilsonng';

describe('AuthGuard', () => {
  let guard: AuthGuard;
  let mockAuthenticationService: any;
  let mockRedirectService: any;

  beforeEach(() => {
    initMocks();
    configureTestBed();
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });

  it('should allow access for logged in users', () => {
    mockAuthenticationService.isLoggedIn.and.returnValue(true);

    expect(guard.canActivate()).toBeTrue();
    expect(mockRedirectService.setRedirectCookie).not.toHaveBeenCalled();
    expect(mockAuthenticationService.login).not.toHaveBeenCalled();
  });

  it('should make the user login if not logged in', () => {
    mockAuthenticationService.isLoggedIn.and.returnValue(false);

    expect(guard.canActivate()).toBeFalse();
    expect(mockRedirectService.setRedirectCookie).toHaveBeenCalled();
    expect(mockAuthenticationService.login).toHaveBeenCalled();
  });

  function initMocks() {
    mockRedirectService = {
      setRedirectCookie: jasmine.createSpy('setRedirectCookie'),
    };
    mockAuthenticationService = {
      isLoggedIn: jasmine.createSpy('isLoggedIn'),
      login: jasmine.createSpy('login'),
    };
  }

  function configureTestBed() {
    TestBed.configureTestingModule({
      providers: [
        { provide: RedirectService, useValue: mockRedirectService },
        { provide: AuthenticationService, useValue: mockAuthenticationService },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    });
    guard = TestBed.inject(AuthGuard);
  }
});
