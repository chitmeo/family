import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { ChatBotComponent } from '../app/components/chat-bot/chat-bot.component';
import { ApiService, AuthenticationService } from '@wilson/wilsonng';
import { of, throwError } from 'rxjs';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import mixpanel from 'mixpanel-browser';

class MockApiService {
  post(url: string, body: any) {
    return of({
      role: 'assistant',
      content: 'This is a test answer.',
      createdAt: new Date().toISOString(),
    });
  }
}
class MockAuthenticationService {
  currentUser = {
    wilsonId: 'user-001'
  }
}

describe('ChatBotComponent', () => {
  let component: ChatBotComponent;
  let fixture: ComponentFixture<ChatBotComponent>;
  let apiService: ApiService;
  let authenticationService: AuthenticationService;
  let mixpanelSpy: jasmine.Spy;

  const mockDocument = {
    id: 'doc1',
    sampleQuestions: 'Question 1|Question 2',
  } as any;

  const mockDocumentGroup = {
    codeText: 'test-code',
  } as any;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChatBotComponent],
      providers: [
        { provide: ApiService, useClass: MockApiService },
        { provide: AuthenticationService, useClass: MockAuthenticationService }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(ChatBotComponent);
    component = fixture.componentInstance;
    apiService = TestBed.inject(ApiService);
    authenticationService = TestBed.inject(AuthenticationService);

    component.document = mockDocument;
    component.documentGroup = mockDocumentGroup;

    let store: { [key: string]: string } = {};
    const mockLocalStorage = {
      getItem: (key: string): string | null => {
        return key in store ? store[key] : null;
      },
      setItem: (key: string, value: string) => {
        store[key] = value;
      },
      removeItem: (key: string) => {
        delete store[key];
      },
      clear: () => {
        store = {};
      }
    };
    Object.defineProperty(window, 'localStorage', { value: mockLocalStorage });

    window.HTMLElement.prototype.scrollIntoView = jasmine.createSpy();

    mixpanelSpy = spyOn(mixpanel, 'track');

    fixture.detectChanges();

    component.gotoChatHome();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit', () => {
    it('should initialize suggestedQuestions from document input', () => {
      expect(component.suggestedQuestions()).toEqual(['Question 1', 'Question 2']);
    });

    it('should handle document with no sample questions', () => {
        component.document = { id: 'doc2' } as any;
        component.ngOnInit();
        expect(component.suggestedQuestions()).toEqual([]);
    });
  });

  describe('Sidebar', () => {
    it('should open sidebar', () => {
      component.openSidebar();
      expect(component.sidebarVisible).toBe(true);
    });

    it('should close sidebar', () => {
      component.sidebarVisible = true;
      component.closeSidebar();
      expect(component.sidebarVisible).toBe(false);
    });

    it('should track mixpanel event on sidebar open', () => {
      component.onVisibleChange(true);
      expect(mixpanel.track).toHaveBeenCalledWith('Chatbot Opened', { 'Document Id': mockDocument.id });
    });

    it('should not track mixpanel event on sidebar close', () => {
      component.onVisibleChange(false);
      expect(mixpanelSpy).not.toHaveBeenCalled();
    });
  });

  describe('Navigation', () => {
    it('should navigate to history view', () => {
      const getHistorySpy = spyOn(component, 'getChatHistory');
      component.gotoChatHistory();
      expect(component.viewMode).toBe(component.VIEW_HISTORY);
      expect(getHistorySpy).toHaveBeenCalled();
    });

    it('should navigate to home view', () => {
      component.viewMode = 'history';
      component.gotoChatHome();
      expect(component.viewMode).toBe(component.VIEW_CHAT);
    });

    it('should navigate to chat view without QA', () => {
      component.gotoChatView();
      expect(component.viewMode).toBe(component.VIEW_CHAT);
    });

    it('should navigate to chat view with QA', () => {
      const qa = { q: 'test q', a: 'test a', t: new Date() };
      component.gotoChatView(qa);

      const answer = component.messages.at(-1);

      expect(component.viewMode).toBe(component.VIEW_CHAT);
      expect(component.question).toBe('');
      expect(answer.content).toContain('<p>test a</p>');
      expect((component.messages.at(-1) as any).helpful).toBeUndefined();
      expect(component.waitingAnswer).toBe(false);
    });
  });

  describe('Question Handling', () => {
    it('should select a suggested question and ask', () => {
      const askSpy = spyOn(component, 'ask');
      const question = 'Suggested Question';
      component.selectSuggestQuestion(question);
      expect(component.question).toBe(question);
      expect(mixpanel.track).toHaveBeenCalledWith('Chatbot Select Suggested Question', { 'Document Id': mockDocument.id });
      expect(askSpy).toHaveBeenCalled();
    });

    it('should validate question on change', () => {
      const validateSpy = spyOn(component, 'validateQuestion');
      component.onQuestionChange('new question');
      expect(validateSpy).toHaveBeenCalled();
    });

    it('should set invalidQuestion for long questions', () => {
      component.question = 'a'.repeat(5001);
      component.validateQuestion();
      expect(component.invalidQuestion).toBe(true);
    });

    it('should set invalidQuestion for script-like questions', () => {
      component.question = '<script>alert("xss")</script>';
      component.validateQuestion();
      expect(component.invalidQuestion).toBe(true);
    });

    it('should not set invalidQuestion for valid questions', () => {
      component.question = 'This is a valid question.';
      component.validateQuestion();
      expect(component.invalidQuestion).toBe(false);
    });
  });

  describe('ask', () => {
    it('should not proceed if question is empty', () => {
      const apiSpy = spyOn(apiService, 'post');
      component.question = '';
      component.ask();
      expect(apiSpy).not.toHaveBeenCalled();
    });

    it('should not proceed if question is invalid', () => {
      const apiSpy = spyOn(apiService, 'post');
      component.question = 'valid question';
      component.invalidQuestion = true;
      component.ask();
      expect(apiSpy).not.toHaveBeenCalled();
    });

    it('should call apiService.post and handle success', fakeAsync(() => {
      const apiSpy = spyOn(apiService, 'post').and.returnValue(of({ role: 'assistant', content: 'Success', createdAt: new Date().toISOString() }));
      const saveHistorySpy = spyOn(component, 'saveHistory');

      component.question = 'A good question';
      component.invalidQuestion = false;
      component.ask();

      tick(200);

      const answer = component.messages.at(-1);

      expect(component.waitingAnswer).toBe(false);
      expect(answer.content).toContain('<p>Success</p>');
      expect(saveHistorySpy).toHaveBeenCalled();
      expect(mixpanel.track).toHaveBeenCalledWith('Chatbot Conversation', { 'Document Id': mockDocument.id });
      expect(apiSpy).toHaveBeenCalledWith(
        `${component.controller}/question`,
        {
          threadId: '',
          accessCode: mockDocumentGroup.codeText,
          documentId: mockDocument.id,
          question: 'A good question'
        }
      );
    }));

    it('should handle API error', fakeAsync(() => {
        const errorResponse = { error: { message: 'API Error' } };
        const apiSpy = spyOn(apiService, 'post').and.returnValue(throwError(() => errorResponse));

        component.question = 'Another question';
        component.invalidQuestion = false;
        component.ask();

        tick(200);

        expect(component.waitingAnswer).toBe(false);
      expect((component.messages.at(-1) as any).errorMsg).toEqual([{ severity: 'error', detail: 'API Error' }]);
    }));
    it('should handle API error without messaeg', fakeAsync(() => {
        const errorResponse = { error: {} };
        const apiSpy = spyOn(apiService, 'post').and.returnValue(throwError(() => errorResponse));

        component.question = 'Another question';
        component.invalidQuestion = false;
        component.ask();

        tick(200);

        expect(component.waitingAnswer).toBe(false);
      expect((component.messages.at(-1) as any).errorMsg).toEqual([{ severity: 'error', detail: 'There was an error generating a response. Please try again later.' }]);
    }));

    it('should trim question before ask', fakeAsync(() => {
      const errorResponse = { error: {} };
      const apiSpy = spyOn(apiService, 'post').and.returnValue(
        throwError(() => errorResponse)
      );

      component.question = '         Another question has white spaces    ';
      component.invalidQuestion = false;
      component.ask();

      tick(200);
      expect(component.waitingAnswer).toBe(false);
      expect(apiSpy).toHaveBeenCalledWith(`${component.controller}/question`, {
        threadId: '',
        accessCode: mockDocumentGroup.codeText,
        documentId: mockDocument.id,
        question: 'Another question has white spaces',
      });

    }));
  });

  describe('feedback', () => {
    it('should set helpful and track mixpanel event', () => {
        (component as any)._addMsg("Test question", "Test answer");

        const answer = component.messages.at(-1);

        component.feedback(answer.id, true);
        expect((answer as any).helpful).toBe(true);
        expect(mixpanel.track).toHaveBeenCalledWith('Chatbot Conversation Helpful', { 'Document Id': mockDocument.id });

        component.feedback(answer.id, false);
        expect((answer as any).helpful).toBe(false);
        expect(mixpanel.track).toHaveBeenCalledWith('Chatbot Conversation Not Helpful', { 'Document Id': mockDocument.id });
    });
  });

  describe('History', () => {
    const today = new Date();
    const thirtyDaysAgoDate = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 30, 0, 0, 0);
    const olderDate = new Date(thirtyDaysAgoDate.getTime() - 1).toISOString();
    const newerDate = new Date().toISOString();
    const mockQA = { q: 'q1', a: 'a1', t: new Date()};

    const mockHistory = [
        { q: 'q1', a: 'a1', t: newerDate },
        { q: 'q2', a: 'a2', t: olderDate },
    ];

    beforeEach(() => {
        spyOn(localStorage, 'setItem').and.callThrough();
        spyOn(localStorage, 'getItem').and.callThrough();
        localStorage.clear();
    });

    it('should save history to localStorage', () => {
        component.saveHistory(mockQA);
        expect(localStorage.setItem).toHaveBeenCalledWith(component.storageKey(), JSON.stringify([mockQA]));
    });

    it('should add to existing history in localStorage', () => {
        const initialHistory = [{ q: 'old_q', a: 'old_a', t: new Date().toISOString() }];
        localStorage.setItem(component.storageKey(), JSON.stringify(initialHistory));
        const newQA = { q: 'new_q', a: 'new_a', t: new Date() };
        component.saveHistory(newQA);
        const finalHistory = [...initialHistory, newQA];
        expect(localStorage.setItem).toHaveBeenCalledWith(component.storageKey(), JSON.stringify(finalHistory));
    });

    it('should get history, filter old items, and group by day', () => {
        localStorage.setItem(component.storageKey(), JSON.stringify(mockHistory));
        component.getChatHistory();
        const todayStr = new Date(newerDate).toLocaleDateString('en-US', {year: 'numeric',month: '2-digit',day: '2-digit'});
        expect(component.days).toEqual([todayStr]);
        expect(component.groupQAByDay[todayStr]).toBeDefined();
        expect(component.groupQAByDay[todayStr].length).toBe(1);
    });

    it('should handle no history in localStorage', () => {
        localStorage.removeItem(component.storageKey());
        component.getChatHistory();
        expect(component.days).toEqual([]);
        expect(component.groupQAByDay).toEqual({});
    });

    it('should handle parsing error in getHistory', () => {
        const consoleErrorSpy = spyOn(console, 'error');
        localStorage.setItem(component.storageKey(), 'invalid json');
        component.getChatHistory();
        expect(consoleErrorSpy).toHaveBeenCalled();
    });
  });

  describe('handleSubmitQuestion()', () => {
    it('should prevent default event and call ask()', () => {
      const event = new KeyboardEvent('keydown', { key: 'Enter' });
      spyOn(event, 'preventDefault');
      spyOn(component, 'ask');

      component.handleSubmitQuestion(event);

      expect(event.preventDefault).toHaveBeenCalled();
      expect(component.ask).toHaveBeenCalled();
    });
  });
  
  describe('handleAddNewLineInQuestion()', () => {
      it('should insert newline at cursor position', fakeAsync(() => {
        component.question = 'HelloWorld';

        const textareaMock = {
          selectionStart: 5,
          selectionEnd: 5,
        } as unknown as HTMLTextAreaElement;

        const event = {
          preventDefault: jasmine.createSpy('preventDefault'),
          target: textareaMock,
        } as unknown as KeyboardEvent;

        component.handleAddNewLineInQuestion(event);

        tick(200);
        
        expect(event.preventDefault).toHaveBeenCalled();
        expect(component.question).toBe('Hello\nWorld');
        expect(textareaMock.selectionStart).toBe(6);
        expect(textareaMock.selectionEnd).toBe(6);
      }));
  });

  describe('_scrollToQuestion', () => {
    it('should scroll to question by id', fakeAsync(() => {
      const div = document.createElement('div');
      div.classList.add('chat-ask-container');
      div.dataset.questionId = '123';
      spyOn(document, 'querySelectorAll').and.returnValue([div] as any);

      expect(() => {
        (component as any)._scrollToQuestion('123');
        tick(200);
      }).not.toThrow();
    }));

    it('should return when msgId is falsy', fakeAsync(() => {
      expect(() => {
        (component as any)._scrollToQuestion('');
        tick(200);
      }).not.toThrow();
    }));
  });

  describe('_scrollToLastQuestion', () => {
    it('should scroll to last question', fakeAsync(() => {
      const div = document.createElement('div');
      div.classList.add('chat-ask-container');
      div.dataset.questionId = '123';
      spyOn(document, 'querySelectorAll').and.returnValue([div] as any);

      expect(() => {
        (component as any)._scrollToLastQuestion();
        tick(200);
      }).not.toThrow();
    }));
  });

  describe('_addMsgByHistoryItem', () => {
    it('should add message by history item', () => {
      const mockThreadMsgList = [
          {
            documentId: 'doc1',
            threadId: 'thread-1',
            messages: [{
                id:'q-1',
                type:'Question',
                content:'What is question ?'
            }],
          },
        ];
      (component as any)._threadMsgList = mockThreadMsgList;
      
      const qa = { qId: 'q-1', q: 'test q', a: 'test a', t: new Date() };

      expect(() => {
        (component as any)._addMsgByHistoryItem(qa);
      }).not.toThrow();
    });
  });

});
