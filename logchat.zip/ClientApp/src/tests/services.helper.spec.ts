import mixpanel from 'mixpanel-browser';

beforeAll(function () {
  // dev key
  mixpanel.init('d4ad2e94d03d69386a4072dda5221e1d');
  // do not track unit test user interactions
  mixpanel.opt_out_tracking();
});
