import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdminAccessCodesCrudComponent } from '../app/components/admin-access-codes-crud/admin-access-codes-crud.component';
import { AutoCompleteCompleteEvent } from 'primeng/autocomplete';
import { AdminService } from '../app/services/admin.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { ToastService } from 'src/app/services/toast.service';
import {
  RouterNavigationService,
  AuthenticationService,
  TitleService,
} from '@wilson/wilsonng';
import { Wilson } from '../def/Wilson';
import AccessCode = Wilson.AccessCode;
import Group = Wilson.Group;

describe('AdminAccessCodesCrudComponent', () => {
  let component: AdminAccessCodesCrudComponent;
  let fixture: ComponentFixture<AdminAccessCodesCrudComponent>;
  let mockAccessCode: AccessCode;
  let mockSecTypeValues: any;
  let mockGroup: Group;
  let mockAdminService: any;
  let mockToastService: any;
  let mockRouter: any;
  let mockRoute: any;
  let mockRouterNavigationService: any;
  let mockAuthService: any;
  let mockTitleService: any;

  beforeEach(() => {
    loadMockData();
    loadMockServices();
    setupTestBed();
  });

  beforeEach(() => {
    setupComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should toggle the dialog', () => {
    component.showDialog();
    expect(component.dialogVisible).toEqual(true);
    component.hideDialog();
    expect(component.dialogVisible).toEqual(false);
  });

  it('should init in the correct mode (create/edit)', () => {
    mockRoute.snapshot.params.id = 'create';
    component.ngOnInit();
    expect(component.createMode).toEqual(true);

    // when given an actual id
    mockRoute.snapshot.params.id = '1';
    component.ngOnInit();
    expect(component.createMode).toEqual(false);
  });

  it('should init empty form in create mode', () => {
    expect(component.getValue('id')).toEqual(0);
    expect(component.getValue('codeText')).toEqual('');
    expect(component.getValue('notes')).toEqual('');
    expect(component.getValue('groupId')).toEqual('');
    expect(component.getValue('allowAnonymousEntry')).toEqual(true);
    expect(component.getValue('Community')).toEqual(null);
    expect(component.getValue('Training')).toEqual(null);
    expect(component.getValue('Training Template')).toEqual(null);
    expect(component.group).toEqual(null);
  });

  it('should init form with pre-filled group if provided in create mode', () => {
    mockRoute.snapshot.queryParams.groupId = mockGroup.id;
    component.initForm();
    expect(mockAdminService.getGroup).toHaveBeenCalled();
    expect(component.getValue('groupId')).toEqual(mockGroup.id);
  });

  it('should load document code values in edit mode', () => {
    component.id = mockAccessCode.id;
    component.getAccessCode().subscribe();

    expect(mockAdminService.getAccessCode).toHaveBeenCalled();
    expect(component.getValue('id')).toEqual(mockAccessCode.id);
    expect(component.getValue('codeText')).toEqual(mockAccessCode.codeText);
    expect(component.getValue('groupId')).toEqual(mockAccessCode.groupId);
    expect(component.getValue('allowAnonymousEntry')).toEqual(
      mockAccessCode.allowAnonymousEntry
    );
  });

  it('should show a crudNotFound toast message if no document code is returned from the admin service', () => {
    mockAdminService.getAccessCode.and.returnValue(of(null));
    component.id = mockAccessCode.id;
    component.getAccessCode().subscribe();

    expect(mockAdminService.getAccessCode).toHaveBeenCalled();
    expect(mockToastService.crudNotFound).toHaveBeenCalledWith(
      'Document Code',
      component.id,
      '/admin/access-codes'
    );
  });

  it('should clear errors', () => {
    component.errors.codeText = 'Code text has a test error.';
    component.clearError('codeText');
    expect(component.errors.codeText).toEqual('');
  });

  it('should update form control values', () => {
    const field = 'codeText';
    const value = 'blablabla';
    component.accessCodeForm.controls[field].setValue('');
    component.errors[field] = 'Test error.';
    component.setValue(field, value);
    expect(component.accessCodeForm.controls[field].value).toEqual(value);
    expect(component.errors[field]).toEqual(null);
  });

  it('should retrieve form control values', () => {
    component.accessCodeForm.controls['codeText'].setValue('test');
    expect(component.getValue('codeText')).toEqual('test');
  });

  it('should set anonymous entry', () => {
    component.setAnonymous({ checked: true, originalEvent: null });
    expect(component.securities.filter((s) => s.selected).length).toEqual(0);

    // when unchecked
    component.securities[0].selected = true;
    component.setAnonymous({ checked: false, originalEvent: null });
    expect(component.securities.filter((s) => s.selected).length).toEqual(1);
  });

  it('should set security options', () => {
    component.setSecurity({ checked: true, originalEvent: null });
    expect(component.getValue('allowAnonymousEntry')).toEqual(false);

    // when unchecked
    component.setValue('allowAnonymousEntry', true);
    component.setSecurity({ checked: false, originalEvent: null });
    expect(component.getValue('allowAnonymousEntry')).toEqual(true);
  });

  it('should fill group suggestions', () => {
    const event = {
      query: 'group',
    };
    component.groupFillSuggestions(event as AutoCompleteCompleteEvent);
    expect(mockAdminService.getGroups).toHaveBeenCalled();
    expect(component.groupSuggestions.length).toBe(1);
  });

  it('should dirtify the form', () => {
    component.dirtify();
    expect(component.accessCodeForm.pristine).toEqual(false);
  });

  it('should go back', () => {
    component.goBack();
    expect(mockRouterNavigationService.goToPreviousUrl).toHaveBeenCalledWith(
      '/admin/access-codes'
    );
  });

  const requiredFields = ['codeText', 'groupId'];
  for (const field of requiredFields) {
    it(`should invalidate when '${field}' is blank`, () => {
      component.submitAccessCode();
      expect(component.errors[field]).toBeTruthy();
      expect(mockAdminService.upsertAccessCode).not.toHaveBeenCalled();
    });
  }

  it('should assign a group to the document code', () => {
    component.setValue('groupId', null);
    component.onGroupSelect({ value: mockGroup, originalEvent: null });
    expect(component.getValue('groupId')).toEqual(mockGroup.id);
  });

  it('should delete on confirmed deletion', () => {
    spyOn(window, 'confirm').and.returnValue(true);
    spyOn(component, 'deleteAccessCode').and.returnValue(of(null));
    component.createMode = true;
    component.confirmDeletion();
    expect(window.confirm).not.toHaveBeenCalled();

    component.createMode = false;
    component.id = 1;
    component.confirmDeletion();
    expect(window.confirm).toHaveBeenCalled();
    expect(component.deleteAccessCode).toHaveBeenCalled();
  });

  it('should cancel deletion on cancel', () => {
    spyOn(window, 'confirm').and.returnValue(false);
    spyOn(component, 'deleteAccessCode').and.returnValue(of(null));
    component.createMode = false;
    component.id = 1;
    component.confirmDeletion();
    expect(component.deleteAccessCode).not.toHaveBeenCalled();
  });

  it('should delete the document code', () => {
    component
      .deleteAccessCode()
      .pipe(
        tap(() => {
          expect(mockAdminService.deleteAccessCode).toHaveBeenCalled();
          expect(mockRouter.navigate).toHaveBeenCalled();
        })
      )
      .subscribe();
  });

  it('should insert the document code when all fields are valid in create mode', () => {
    component.initTime = new Date('12/12/2012');
    component.setValue('id', 0);
    component.setValue('codeText', mockAccessCode.codeText);
    component.setValue('expiration', mockAccessCode.expiration);
    component.setValue('groupId', mockGroup.id);
    component.setValue('notes', mockAccessCode.notes);
    component.setValue(
      'allowAnonymousEntry',
      mockAccessCode.allowAnonymousEntry
    );
    component.setValue('Community', {
      label: 'a community label',
      value: 'some-guid-123',
    });
    component.securities[0].selected = true;
    component.group = mockGroup;
    component.active = true;

    component.submitAccessCode();
    expect(mockAdminService.upsertAccessCode).toHaveBeenCalledWith({
      id: 0,
      codeText: mockAccessCode.codeText,
      expiration: mockAccessCode.expiration,
      groupId: mockGroup.id,
      notes: mockAccessCode.notes,
      active: component.active,
      allowAnonymousEntry: mockAccessCode.allowAnonymousEntry,
      accessCodeSecurities: [
        { accessCodeSecurityTypeId: 1, value: 'some-guid-123' },
      ],
      createdDate: component.initTime,
      createdBy: mockAccessCode.createdBy,
      modifiedBy: mockAccessCode.modifiedBy,
    });
    expect(mockToastService.crudSuccess).toHaveBeenCalled();
    expect(mockRouterNavigationService.goToPreviousUrl).toHaveBeenCalledWith(
      '/admin/access-codes'
    );
  });

  it('should update the document when all fields are valid in edit mode', () => {
    component.createMode = false;
    component.id = 1;
    mockAccessCode.codeText = 'testcode2';
    mockAccessCode.active = false;
    mockAdminService.upsertAccessCode.and.returnValue(of(-1));

    const simpleMockAccessCode = { ...mockAccessCode };
    delete simpleMockAccessCode.group;
    delete simpleMockAccessCode.createdBy;
    delete simpleMockAccessCode.modifiedDate;

    component
      .getAccessCode()
      .pipe(
        tap(() => {
          component.submitAccessCode();
          expect(mockAdminService.upsertAccessCode).toHaveBeenCalledWith(
            simpleMockAccessCode
          );
          expect(mockToastService.crudFailure).toHaveBeenCalled();
        })
      )
      .subscribe();
  });

  it('should fill security suggestions', () => {
    const secType = 1;
    const emptyEvent = {
      query: '',
      originalEvent: null,
    };
    const event = {
      query: 'yoyo',
      originalEvent: null,
    };
    // when query is empty
    component.securityFillSuggestions(secType, emptyEvent);
    expect(
      mockAdminService.getAccessCodeSecurityTypeValues
    ).not.toHaveBeenCalled();

    // otherwise
    component.securityFillSuggestions(secType, event);
    expect(
      mockAdminService.getAccessCodeSecurityTypeValues
    ).toHaveBeenCalledWith(secType, event.query);
    expect(component.securitySuggestions.length).toEqual(2);
  });

  it('should return whether it is able to be deactivated', () => {
    component.accessCodeForm.markAsDirty();
    expect(component.canDeactivate()).toEqual(false);
  });

  // Set up mock data, providers and method spies
  function loadMockData(): void {
    mockAccessCode = {
      id: 1,
      codeText: 'testcode',
      notes: 'Lorem ipsum dolor sit amet',
      expiration: new Date(),
      active: true,
      allowAnonymousEntry: true,
      accessCodeSecurities: [],
      groupId: 1,
      group: null,
      createdDate: new Date(),
      createdBy: 'User Name',
      modifiedDate: new Date(),
      modifiedBy: 'User Name',
    };

    mockRoute = {
      snapshot: {
        params: {
          id: 'create',
        },
        queryParams: {},
      },
    };

    mockGroup = {
      id: 999,
      title: 'Test Group 999',
      description: 'A test group',
      coverImageUrl: '/stock/fundations-cover.png',
      createdDate: new Date(),
      createdBy: 'User Name',
      modifiedDate: new Date(),
      modifiedBy: 'User Name',
      accessCodes: null,
      documentGroups: null,
    } as Group;

    mockSecTypeValues = {
      'cool-guid-1': 'cool name',
      'cool-guid-2': 'cooler name',
    };
  }

  function loadMockServices(): void {
    mockRouter = {
      navigate: jasmine.createSpy('navigate'),
    };

    mockToastService = {
      crudSuccess: jasmine.createSpy('crudSuccess'),
      crudFailure: jasmine.createSpy('crudFailure'),
      crudNotFound: jasmine.createSpy('crudNotFound'),
    };

    mockRouterNavigationService = {
      goToPreviousUrl: jasmine.createSpy('goToPreviousUrl'),
    };

    mockAdminService = {
      getAccessCode: jasmine
        .createSpy('getAccessCode')
        .and.returnValue(of(mockAccessCode)),
      getGroups: jasmine
        .createSpy('getGroups')
        .and.returnValue(of([mockGroup])),
      getGroup: jasmine.createSpy('getGroup').and.returnValue(of(mockGroup)),
      upsertAccessCode: jasmine
        .createSpy('upsertAccessCode')
        .and.returnValue(of(1)),
      deleteAccessCode: jasmine
        .createSpy('deleteAccessCode')
        .and.returnValue(of(1)),
      getAccessCodeSecurityTypeValues: jasmine
        .createSpy('getAccessCodeSecurityTypeValues')
        .and.returnValue(of(mockSecTypeValues)),
    };

    mockAuthService = {
      getUser: jasmine
        .createSpy('getUser')
        .and.returnValue(of({ name: 'User Name' })),
    };

    mockTitleService = {
      setPageName: jasmine.createSpy('setPageName'),
    };
  }

  // Configure the test bed
  function setupTestBed(): void {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule],
      declarations: [AdminAccessCodesCrudComponent],
      providers: [
        { provide: ToastService, useValue: mockToastService },
        { provide: AdminService, useValue: mockAdminService },
        { provide: AuthenticationService, useValue: mockAuthService },
        { provide: Router, useValue: mockRouter },
        { provide: ActivatedRoute, useValue: mockRoute },
        {
          provide: RouterNavigationService,
          useValue: mockRouterNavigationService,
        },
        {
          provide: TitleService,
          useValue: mockTitleService,
        },
        {
          provide: 'productName',
          useValue: 'Document Viewer',
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }

  // Initialize the component var
  function setupComponent(): void {
    fixture = TestBed.createComponent(AdminAccessCodesCrudComponent);
    component = fixture.componentInstance;

    component.ngOnInit();
  }
});
