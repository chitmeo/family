import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { AdminAccessCodesComponent } from '../app/components/admin-access-codes/admin-access-codes.component';
import { AdminService } from '../app/services/admin.service';
import { tap } from 'rxjs/operators';
import { LazyLoadEvent } from 'primeng/api';
import { Calendar } from 'primeng/calendar';
import { TitleService } from '@wilson/wilsonng';
import { Wilson } from '../def/Wilson';
import AccessCode = Wilson.AccessCode;
import Group = Wilson.Group;

describe('AdminAccessCodesComponent', () => {
  let component: AdminAccessCodesComponent;
  let fixture: ComponentFixture<AdminAccessCodesComponent>;
  let mockAccessCodes: AccessCode[];
  let mockAdminService: any;
  let mockTitleService: any;

  beforeEach(async () => {
    loadMockData();
    loadMockServices();
    setupTestBed();
  });

  beforeEach(() => {
    setupComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize correctly', () => {
    spyOn(component, 'setupBreadcrumbs').and.returnValue(null);
    spyOn(component, 'setupSearch').and.returnValue(null);
    spyOn(component, 'setupSearchHandler').and.returnValue(of(null));
    component.initialize();

    // setupBreadCrumbs()
    expect(component.setupBreadcrumbs).toHaveBeenCalled();
    expect(component.path.length).toEqual(2);

    // setupSearch()
    expect(component.setupSearch).toHaveBeenCalled();
    expect(component.search.filters).toEqual([]);
    expect(component.search.dateRanges).toEqual([]);
    expect(component.search.skip).toEqual(0);
    expect(component.search.take).toEqual(component.pagesize);
    expect(component.search.sort).toEqual(null);

    // setupSearchHandler()
    expect(component.setupSearchHandler).toHaveBeenCalled();
  });

  it('should load the accessCodes correctly', () => {
    component.accessCodes = null;
    component
      .getAccessCodes()
      .pipe(
        tap(() => {
          expect(mockAdminService.getAccessCodeDirectory).toHaveBeenCalled();
          expect(component.accessCodes).toEqual(mockAccessCodes);
          expect(component.totalRecords).toEqual(100);
        })
      )
      .subscribe();
  });

  it('should not add any new searches if dateRangeFilterColumn value is empty', () => {
    expect(component.search.dateRanges.length).toEqual(0);
    component.dateRangeFilterColumn('createdDate', {} as Calendar);
    expect(component.search.dateRanges.length).toEqual(0);
  });

  it('should lazy load accessCodes', () => {
    const evt = {
      first: 0,
      rows: 25,
      sortOrder: 1,
      sortField: 'createdDate',
    } as LazyLoadEvent;
    spyOn(component, 'getAccessCodes').and.callThrough();
    component.lazyLoadAccessCodes(evt);
    expect(component.search.skip).toEqual(evt.first);
    expect(component.search.take).toEqual(evt.rows);
    expect(component.search.sort).toEqual({
      column: evt.sortField,
      direction: evt.sortOrder,
    });
    expect(component.getAccessCodes).toHaveBeenCalled();
  });

  it('should show the dialog', () => {
    component.showDialog(1);
    expect(mockAdminService.getAccessCode).toHaveBeenCalled();
    expect(component.dialogVisible).toEqual(true);
  });

  // Set up mock data, providers and method spies
  function loadMockData(): void {
    mockAccessCodes = [
      {
        id: 101,
        codeText: 'AC101',
        notes: 'Access ipsum dolor sit amet 101',
        active: true,
        expiration: new Date(),
        allowAnonymousEntry: true,
        groupId: 1,
        accessCodeSecurities: [],
        group: {
          id: 1,
          title: 'Sample Group 1',
          description: 'Lorem ipsum dolor sit amet',
          coverImageUrl: '/stock/fundations-cover.png',
          documentGroups: [
            {
              documentId: 1,
              groupId: 1,
              ordinal: 0,
              document: null,
              group: null,
            },
          ],
          accessCodes: [],
          createdDate: new Date(),
          createdBy: 'User Name',
          modifiedDate: new Date(),
          modifiedBy: 'User Name',
        } as Group,
        createdDate: new Date(),
        createdBy: 'User Name',
        modifiedDate: new Date(),
        modifiedBy: 'User Name',
      },
      {
        id: 102,
        codeText: 'AC102',
        notes: 'Access ipsum dolor sit amet 102',
        active: true,
        expiration: new Date(),
        allowAnonymousEntry: true,
        groupId: 2,
        accessCodeSecurities: [],
        group: null,
        createdDate: new Date(),
        createdBy: 'User Name',
        modifiedDate: new Date(),
        modifiedBy: 'User Name',
      },
      {
        id: 103,
        codeText: 'AC103',
        notes: 'Access ipsum dolor sit amet 103',
        active: true,
        expiration: new Date(),
        allowAnonymousEntry: true,
        groupId: 3,
        accessCodeSecurities: [],
        group: null,
        createdDate: new Date(),
        createdBy: 'User Name',
        modifiedDate: new Date(),
        modifiedBy: 'User Name',
      },
      {
        id: 104,
        codeText: 'AC104',
        notes: 'Access ipsum dolor sit amet 104',
        active: false,
        expiration: new Date(),
        allowAnonymousEntry: true,
        groupId: 4,
        accessCodeSecurities: [],
        group: null,
        createdDate: new Date(),
        createdBy: 'User Name',
        modifiedDate: new Date(),
        modifiedBy: 'User Name',
      },
      {
        id: 105,
        codeText: 'AC105',
        notes: 'Access ipsum dolor sit amet 105',
        active: false,
        expiration: new Date(),
        allowAnonymousEntry: true,
        groupId: 5,
        accessCodeSecurities: [],
        group: null,
        createdDate: new Date(),
        createdBy: 'User Name',
        modifiedDate: new Date(),
        modifiedBy: 'User Name',
      },
    ];
  }

  function loadMockServices(): void {
    mockAdminService = {
      getAccessCodeDirectory: jasmine
        .createSpy('getAccessCodeDirectory')
        .and.returnValue(
          of({
            data: mockAccessCodes,
            total: 100,
          })
        ),
      getAccessCode: jasmine
        .createSpy('getAccessCode')
        .and.returnValue(of(mockAccessCodes[0])),
    };

    mockTitleService = {
      setPageName: jasmine.createSpy('setPageName'),
    };
  }

  // Configure the test bed
  function setupTestBed(): void {
    TestBed.configureTestingModule({
      declarations: [AdminAccessCodesComponent],
      providers: [
        { provide: AdminService, useValue: mockAdminService },
        {
          provide: TitleService,
          useValue: mockTitleService,
        },
        {
          provide: 'productName',
          useValue: 'Document Viewer',
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }

  // Initialize the component var
  function setupComponent(): void {
    fixture = TestBed.createComponent(AdminAccessCodesComponent);
    component = fixture.componentInstance;

    component.ngOnInit();
  }
});
