import { TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { AdminOverviewService } from '../app/services/admin-overview.service';
import { of } from 'rxjs';
import { ApiService, TitleService } from '@wilson/wilsonng';
import { Wilson } from '../def/Wilson';
import OverviewStatistics = Wilson.OverviewStatistics;
import OverviewDocument = Wilson.OverviewDocument;

describe('AdminOverviewService', () => {
  let service: AdminOverviewService;
  let mockApiService: any;
  let mockOverviewPageLoadResponse: OverviewStatistics;
  let mockTitleService: any;

  beforeEach(() => {
    loadMockData();
    loadMockServices();
    configureTestBed();
    service = TestBed.inject(AdminOverviewService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get overview statistics', () => {
    service.getOverviewStatistics().subscribe(() => {
      expect(mockApiService.get).toHaveBeenCalledWith(
        `Admin/getOverviewStatistics`,
        [{ key: 'refreshCache', value: 'false' }]
      );
    });
  });

  function configureTestBed(): void {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes([])],
      providers: [
        { provide: ApiService, useValue: mockApiService },
        {
          provide: TitleService,
          useValue: mockTitleService,
        },
        {
          provide: 'productName',
          useValue: 'Document Viewer',
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    });
  }
  function loadMockData(): void {
    mockOverviewPageLoadResponse = {
      documentStatistics: {
        total: 5,
        totalUnassigned: 12,
        recent: [
          {
            id: 101,
            title: 'Sample Document 101',
            description: 'Lorem ipsum dolor sit amet',
            isInGroup: true,
            createdDate: new Date(),
          } as OverviewDocument,
          {
            id: 102,
            title: 'Sample Document 102',
            description: 'Lorem ipsum dolor sit amet',
            isInGroup: false,
            createdDate: new Date(),
          } as OverviewDocument,
          {
            id: 103,
            title: 'Sample Document 103',
            description: 'Lorem ipsum dolor sit amet',
            isInGroup: true,
            createdDate: new Date(),
          } as OverviewDocument,
          {
            id: 104,
            title: 'Sample Document 104',
            description: 'Lorem ipsum dolor sit amet',
            isInGroup: false,
            createdDate: new Date(),
          } as OverviewDocument,
          {
            id: 105,
            title: 'Sample Document 105',
            description: 'Lorem ipsum dolor sit amet',
            isInGroup: false,
            createdDate: new Date(),
          } as OverviewDocument,
        ],
      },
      groupStatistics: {
        total: 0,
        totalWithoutDocuments: 0,
        totalWithoutAccessCodes: 0,
      },
      accessCodeStatistics: {
        total: 0,
        totalSecure: 0,
        totalUnsecure: 0,
      },
      overviewLastCalculated: new Date(),
    };
  }

  function loadMockServices(): void {
    mockApiService = {
      get: jasmine
        .createSpy('get')
        .and.returnValue(of(mockOverviewPageLoadResponse)),
    };

    mockTitleService = {
      setPageName: jasmine.createSpy('setPageName'),
    };
  }
});
