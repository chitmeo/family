import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TitleService } from '@wilson/wilsonng';
import { of } from 'rxjs';
import { AdminOverviewService } from 'src/app/services/admin-overview.service';
import { AdminOverviewComponent } from '../app/components/admin-overview/admin-overview.component';
import { Wilson } from '../def/Wilson';
import OverviewStatistics = Wilson.OverviewStatistics;
import OverviewDocument = Wilson.OverviewDocument;

describe('AdminOverviewComponent', () => {
  let component: AdminOverviewComponent;
  let fixture: ComponentFixture<AdminOverviewComponent>;
  let mockAdminOverviewService: any;
  let mockTitleService: any;
  let mockOverviewPageLoadResponse: OverviewStatistics;

  beforeEach(() => {
    loadMockData();
    loadMockServices();
    setupTestBed();
    setupComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get overview data on init', () => {
    component.ngOnInit();
    expect(mockTitleService.setPageName).toHaveBeenCalledWith('Overview');

    expect(mockAdminOverviewService.getOverviewStatistics).toHaveBeenCalled();
    expect(component.statistics.documentStatistics).toEqual(
      mockOverviewPageLoadResponse.documentStatistics
    );
    expect(component.statistics.groupStatistics).toEqual(
      mockOverviewPageLoadResponse.groupStatistics
    );
    expect(component.statistics.accessCodeStatistics).toEqual(
      mockOverviewPageLoadResponse.accessCodeStatistics
    );
    expect(component.statistics.overviewLastCalculated).toEqual(
      mockOverviewPageLoadResponse.overviewLastCalculated
    );
  });

  it('should recalculate overview data when refresh button is clicked', () => {
    component.refreshData();
    expect(mockAdminOverviewService.getOverviewStatistics).toHaveBeenCalledWith(
      true
    );
  });

  // Set up mock data
  function loadMockData(): void {
    mockOverviewPageLoadResponse = {
      documentStatistics: {
        total: 5,
        totalUnassigned: 11,
        recent: [
          {
            id: 101,
            title: 'Sample Document 101',
            description: 'Lorem ipsum dolor sit amet',
            isInGroup: true,
            createdDate: new Date(),
          } as OverviewDocument,
          {
            id: 102,
            title: 'Sample Document 102',
            description: 'Lorem ipsum dolor sit amet',
            isInGroup: false,
            createdDate: new Date(),
          } as OverviewDocument,
          {
            id: 103,
            title: 'Sample Document 103',
            description: 'Lorem ipsum dolor sit amet',
            isInGroup: true,
            createdDate: new Date(),
          } as OverviewDocument,
          {
            id: 104,
            title: 'Sample Document 104',
            description: 'Lorem ipsum dolor sit amet',
            isInGroup: false,
            createdDate: new Date(),
          } as OverviewDocument,
          {
            id: 105,
            title: 'Sample Document 105',
            description: 'Lorem ipsum dolor sit amet',
            isInGroup: false,
            createdDate: new Date(),
          } as OverviewDocument,
        ],
      },
      groupStatistics: {
        total: 0,
        totalWithoutDocuments: 0,
        totalWithoutAccessCodes: 0,
      },
      accessCodeStatistics: {
        total: 0,
        totalSecure: 0,
        totalUnsecure: 0,
      },
      overviewLastCalculated: new Date(),
    };
  }

  // Set up providers and method spies
  function loadMockServices(): void {
    mockAdminOverviewService = {
      getOverviewStatistics: jasmine
        .createSpy('getOverviewStatistics')
        .and.returnValue(of(mockOverviewPageLoadResponse)),
    };
    mockTitleService = {
      setPageName: jasmine.createSpy('setPageName'),
    };
  }

  function setupTestBed(): void {
    TestBed.configureTestingModule({
      declarations: [AdminOverviewComponent],
      providers: [
        { provide: AdminOverviewService, useValue: mockAdminOverviewService },
        { provide: TitleService, useValue: mockTitleService },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }

  // Initialize the component var
  function setupComponent(): void {
    fixture = TestBed.createComponent(AdminOverviewComponent);
    component = fixture.componentInstance;
  }
});
