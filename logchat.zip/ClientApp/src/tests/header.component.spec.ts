import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HeaderComponent } from '../app/components/header/header.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { DocumentService } from 'src/app/services/document.service';
import { Router } from '@angular/router';
import { SessionService, User } from 'src/app/services/session.service';
import { InitialLoadService } from 'src/app/services/initial-load.service';
import { AuthenticationService, UtilityService } from '@wilson/wilsonng';
import { of } from 'rxjs';
import { Guid } from 'guid-typescript';
import { Wilson } from '../def/Wilson';
import Group = Wilson.Group;
import Document = Wilson.Document;

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;
  let mockSessionService: any;
  let mockDocumentService: any;
  let mockInitialLoadService: any;
  let mockAuthenticationService: any;
  let mockUtilityService: any;
  let mockRouter: any;
  let user: User;
  let accessCode: string;
  let docGroup: Group;

  beforeEach(async () => {
    loadMockData();
    loadMockServices();
    setupTestBed();
  });

  beforeEach(() => {
    setupComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show client options when in client mode', () => {
    component.isAdmin = false;
    component.initMenuOptions();
    expect(component.menuOptions).toEqual(component.clientOptions);
  });

  it('should show admin options when in admin mode', () => {
    component.isAdmin = true;
    component.initMenuOptions();
    expect(component.menuOptions).toEqual(component.adminOptions);
  });

  it('should retrieve and assign the build number on initialize', () => {
    spyOn(component, 'getBuildData').and.callThrough();
    expect(component.currentBuildNumber).toEqual('supermegacoolbuildnumber111');
    mockInitialLoadService.initialLoad.currentBuildNumber = '456';
    component.getBuildData();
    expect(component.getBuildData).toHaveBeenCalled();
    expect(component.currentBuildNumber).toEqual('456');
  });

  it('should set canClickTitle to false if user is NOT an admin, and there is no document group', () => {
    mockDocumentService.getCurrentDocumentGroup.and.returnValue(null);
    component.isAdmin = false;
    component.setTitleClickable();
    expect(component.canClickTitle).toEqual(false);
  });

  it('should open the support link', () => {
    spyOn(window, 'open');
    component.support();
    expect(window.open).toHaveBeenCalledWith(
      'https://www.wilsonlanguage.com/contact-us/',
      '_blank',
      'noopener'
    );
  });

  it('should send the user to the feedback link', () => {
    spyOn(window, 'open');

    component.feedback();
    expect(mockSessionService.getSessionInformation).toHaveBeenCalled();
    expect(window.open).toHaveBeenCalled();
  });

  it('should set user email and school to "anonymous" in feedback link if there is no email/school info in the session', () => {
    spyOn(window, 'open');
    mockSessionService.getSessionInformation.and.returnValue(null);

    component.feedback();
    expect(mockSessionService.getSessionInformation).toHaveBeenCalled();
    expect(window.open).toHaveBeenCalledTimes(1);
  });

  it('should correctly close a document', () => {
    component.closeDocument();

    expect(mockSessionService.clearFilters).toHaveBeenCalled();
    expect(mockSessionService.getSessionInformation).toHaveBeenCalled();
    expect(mockSessionService.setSessionInformation).toHaveBeenCalledWith({
      user,
      accessCode: null,
    });
    expect(mockDocumentService.resetCurrentDocumentGroup).toHaveBeenCalled();
  });

  it('should redirect to login', () => {
    component.redirectToLogin();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/login']);
  });

  it('should not modify/set session information if no session exists when trying to close a document', () => {
    mockSessionService.getSessionInformation.and.returnValue(null);
    component.closeDocument();

    expect(mockSessionService.clearFilters).toHaveBeenCalled();
    expect(mockSessionService.getSessionInformation).toHaveBeenCalled();
    expect(mockSessionService.setSessionInformation).not.toHaveBeenCalled();
    expect(mockDocumentService.resetCurrentDocumentGroup).toHaveBeenCalled();
  });

  it('should navigate to /admin when title is clicked in admin mode', () => {
    mockDocumentService.getCurrentDocumentGroup.calls.reset();
    component.isAdmin = true;
    component.clickTitle();
    expect(mockDocumentService.getCurrentDocumentGroup).not.toHaveBeenCalled();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/admin']);
  });

  it('should navigate to the document directory when title is clicked and documentGroup has > 1 documents', () => {
    component.clickTitle();
    expect(mockDocumentService.getCurrentDocumentGroup).toHaveBeenCalled();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/viewer/directory']);
  });

  it('should NOT navigate the user to the document directory when title is clicked and there are no documents in documentGroup', () => {
    mockDocumentService.getCurrentDocumentGroup.and.returnValue(null);
    component.clickTitle();
    expect(mockDocumentService.getCurrentDocumentGroup).toHaveBeenCalled();
    expect(mockRouter.navigate).not.toHaveBeenCalled();
  });

  it('should not navigate anywhere when title is clicked and documentGroup has < 2 documents', () => {
    mockDocumentService.getCurrentDocumentGroup.and.returnValue({
      id: 1,
      documents: [{ id: 1 } as Document],
    });
    component.clickTitle();
    expect(mockDocumentService.getCurrentDocumentGroup).toHaveBeenCalled();
    expect(mockRouter.navigate).not.toHaveBeenCalled();
  });

  it('should perform the correct command when a menu item is clicked', () => {
    spyOn(component, 'closeDocument');
    spyOn(component, 'redirectToLogin');
    spyOn(component, 'support');
    spyOn(component, 'feedback');

    component.initMenuOptions();

    // Open Document
    component.clientOptions[0].command(null);
    expect(component.closeDocument).toHaveBeenCalledTimes(1);
    expect(component.redirectToLogin).toHaveBeenCalledTimes(1);

    // Support
    component.clientOptions[1].command(null);
    expect(component.support).toHaveBeenCalled();

    // Feedback
    component.clientOptions[2].command(null);
    expect(component.feedback).toHaveBeenCalled();

    // Log Out - user is authed
    mockAuthenticationService.isLoggedIn.and.returnValue(false);
    component.clientOptions[4].command(null);
    expect(component.closeDocument).toHaveBeenCalledTimes(2);
    expect(component.redirectToLogin).toHaveBeenCalledTimes(2);
    expect(mockAuthenticationService.logout).not.toHaveBeenCalled();

    // Sign Out (admin)
    component.adminOptions[0].command(null);
    expect(mockAuthenticationService.logout).toHaveBeenCalled();
  });

  it('should redirect to login and NOT do an auth0 logout if user is not signed in to auth0', () => {
    spyOn(component, 'closeDocument');
    spyOn(component, 'redirectToLogin');
    mockAuthenticationService.isLoggedIn.and.returnValue(false);
    component.initMenuOptions();

    component.clientOptions[4].command(null);
    expect(component.closeDocument).toHaveBeenCalled();
    expect(component.redirectToLogin).toHaveBeenCalled();
    expect(mockAuthenticationService.logout).not.toHaveBeenCalled();
  });

  it('should run a command with keyboard navigation', () => {
    const evt = { key: 'Enter' } as KeyboardEvent;
    const toggle = { id: '1' } as HTMLElement;
    component.runCommand(evt, toggle);
    expect(mockUtilityService.menuKeyboardEvent).toHaveBeenCalledWith(
      evt,
      toggle
    );
  });

  // Initialize the component var
  function loadMockData(): void {
    user = {
      id: Guid.EMPTY,
      email: 'someemail@test.com',
      name: 'John',
      school: 'A Good School',
    };
    accessCode = '123';
    docGroup = {
      id: 1,
      documents: [{ id: 1 } as Document, { id: 2 } as Document],
    } as unknown as Group;
  }

  function loadMockServices(): void {
    mockSessionService = {
      getSessionInformation: jasmine
        .createSpy('getSessionInformation')
        .and.returnValue({ user, accessCode }),
      setSessionInformation: jasmine.createSpy('setSessionInformation'),
      clearFilters: jasmine.createSpy('clearFilters'),
    };
    mockDocumentService = {
      resetCurrentDocumentGroup: jasmine.createSpy('resetCurrentDocumentGroup'),
      getCurrentDocumentGroup: jasmine
        .createSpy('getCurrentDocumentGroup')
        .and.returnValue(docGroup),
    };
    mockInitialLoadService = {
      initialLoad: {
        currentBuildNumber: 'supermegacoolbuildnumber111',
      },
    };
    mockRouter = {
      navigate: jasmine.createSpy('navigate'),
      url: 'test',
      events: of(null),
    };
    mockAuthenticationService = {
      logout: jasmine.createSpy('logout'),
      isLoggedIn: jasmine.createSpy('isLoggedIn'),
    };
    mockUtilityService = {
      menuKeyboardEvent: jasmine.createSpy('menuKeyboardEvent'),
    };
  }

  // Configure the test bed
  function setupTestBed(): void {
    TestBed.configureTestingModule({
      declarations: [HeaderComponent],
      providers: [
        { provide: SessionService, useValue: mockSessionService },
        { provide: DocumentService, useValue: mockDocumentService },
        { provide: InitialLoadService, useValue: mockInitialLoadService },
        { provide: Router, useValue: mockRouter },
        { provide: AuthenticationService, useValue: mockAuthenticationService },
        { provide: UtilityService, useValue: mockUtilityService },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }

  function setupComponent(): void {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    component.isAdmin = false;

    component.ngOnInit();
  }
});
