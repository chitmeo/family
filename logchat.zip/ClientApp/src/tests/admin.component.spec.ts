import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RedirectService, TitleService } from '@wilson/wilsonng';

import { AdminComponent } from '../app/funnels/admin/admin.component';

describe('AdminComponent', () => {
  let component: AdminComponent;
  let fixture: ComponentFixture<AdminComponent>;
  let mockRedirectService: any;
  let mockTitleService: any;

  beforeEach(async () => {
    loadMockServices();
    await TestBed.configureTestingModule({
      declarations: [AdminComponent],
      providers: [
        { provide: RedirectService, useValue: mockRedirectService },
        {
          provide: TitleService,
          useValue: mockTitleService,
        },
        {
          provide: 'productName',
          useValue: 'Document Viewer',
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should scroll to the top of the page on activation', () => {
    spyOn(window, 'scroll');
    component.onActivate();
    expect(window.scroll).toHaveBeenCalledWith(0, 0);
    expect(mockRedirectService.clearRedirectCookie).toHaveBeenCalled();
  });

  function loadMockServices(): void {
    mockRedirectService = {
      clearRedirectCookie: jasmine.createSpy('clearRedirectCookie'),
    };

    mockTitleService = {
      setQualifier: jasmine.createSpy('setQualifier'),
    };
  }
});
