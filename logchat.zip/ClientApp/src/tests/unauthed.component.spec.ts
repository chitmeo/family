import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TitleService } from '@wilson/wilsonng';

import { UnauthedComponent } from '../app/funnels/unauthed/unauthed.component';

describe('UnauthedComponent', () => {
  let component: UnauthedComponent;
  let fixture: ComponentFixture<UnauthedComponent>;
  let mockTitleService: any;

  beforeEach(async () => {
    loadMockServices();
    await TestBed.configureTestingModule({
      providers: [
        {
          provide: TitleService,
          useValue: mockTitleService,
        },
        {
          provide: 'productName',
          useValue: 'Document Viewer',
        },
      ],
      declarations: [UnauthedComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UnauthedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  function loadMockServices(): void {
    mockTitleService = {
      setQualifier: jasmine.createSpy('setQualifier'),
    };
  }
});
