import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { AdminGroupsComponent } from '../app/components/admin-groups/admin-groups.component';
import { AdminService } from '../app/services/admin.service';
import { tap } from 'rxjs/operators';
import { LazyLoadEvent } from 'primeng/api';
import { Calendar } from 'primeng/calendar';
import { TitleService } from '@wilson/wilsonng';
import { Wilson } from '../def/Wilson';
import Group = Wilson.Group;

describe('AdminGroupsComponent', () => {
  let component: AdminGroupsComponent;
  let fixture: ComponentFixture<AdminGroupsComponent>;
  let mockAdminService: any;
  let mockGroups: Group[];
  let mockTitleService: any;

  beforeEach(async () => {
    loadMockData();
    loadMockServices();
    setupTestBed();
  });

  beforeEach(() => {
    setupComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize correctly', () => {
    spyOn(component, 'setupBreadcrumbs').and.returnValue(null);
    spyOn(component, 'setupSearch').and.returnValue(null);
    spyOn(component, 'setupSearchHandler').and.returnValue(of(null));
    component.initialize();

    // setupBreadCrumbs()
    expect(component.setupBreadcrumbs).toHaveBeenCalled();
    expect(component.path.length).toEqual(2);

    // setupSearch()
    expect(component.setupSearch).toHaveBeenCalled();
    expect(component.search.filters).toEqual([]);
    expect(component.search.dateRanges).toEqual([]);
    expect(component.search.skip).toEqual(0);
    expect(component.search.take).toEqual(component.pageSize);
    expect(component.search.sort).toEqual(null);

    // setupSearchHandler()
    expect(component.setupSearchHandler).toHaveBeenCalled();
  });

  it('should load the groups correctly', () => {
    component.groups = null;
    component
      .getGroups()
      .pipe(
        tap(() => {
          expect(mockAdminService.getGroupDirectory).toHaveBeenCalled();
          expect(component.groups).toEqual(mockGroups);
          expect(component.totalRecords).toEqual(100);
        })
      )
      .subscribe();
  });

  it('should filter by column search', () => {
    expect(component.search.filters.length).toEqual(0);
    component.wildcardFilterColumn('title', '102');
    expect(component.search.filters.length).toEqual(1);
    expect(component.search.filters[0]).toEqual({
      column: 'title',
      value: '102',
      filterType: 4,
    });
  });

  it('should not add any new searches if filterColumn value is empty', () => {
    expect(component.search.filters.length).toEqual(0);
    component.wildcardFilterColumn('title', '');
    expect(component.search.filters.length).toEqual(0);
  });

  it('should filter by date range', () => {
    const today = new Date();
    expect(component.search.dateRanges.length).toEqual(0);
    component.dateRangeFilterColumn('createdDate', {
      value: [today, null],
    } as Calendar);
    expect(component.search.dateRanges.length).toEqual(1);
    expect(component.search.dateRanges[0]).toEqual({
      column: 'createdDate',
      start: today,
      end: null,
    });
  });

  it('should not add any new searches if dateRangeFilterColumn value is empty', () => {
    expect(component.search.dateRanges.length).toEqual(0);
    component.dateRangeFilterColumn('createdDate', {} as Calendar);
    expect(component.search.dateRanges.length).toEqual(0);
  });

  it('should lazy load groups', () => {
    const evt = {
      first: 0,
      rows: 25,
      sortOrder: 1,
      sortField: 'createdDate',
    } as LazyLoadEvent;
    spyOn(component, 'getGroups').and.callThrough();
    component.lazyLoadGroups(evt);
    expect(component.search.skip).toEqual(evt.first);
    expect(component.search.take).toEqual(evt.rows);
    expect(component.search.sort).toEqual({
      column: evt.sortField,
      direction: evt.sortOrder,
    });
    expect(component.getGroups).toHaveBeenCalled();
  });

  // Set up mock data, providers and method spies
  function loadMockData(): void {
    mockGroups = [
      {
        id: 101,
        title: 'Sample Group 101',
        description: 'Lorem ipsum dolor sit amet',
        coverImageUrl: '/stock/fundations-cover.png',
        documentGroups: [],
        accessCodes: [],
        createdDate: new Date(),
        createdBy: 'User Name',
        modifiedDate: new Date(),
        modifiedBy: 'User Name',
      } as Group,
      {
        id: 102,
        title: 'Sample Group 102',
        description: 'Lorem ipsum dolor sit amet',
        coverImageUrl: '/stock/fundations-cover.png',
        documentGroups: [
          {
            documentId: 1,
            groupId: 1,
            ordinal: 0,
            document: null,
            group: null,
          },
        ],
        accessCodes: [],
        createdDate: new Date(),
        createdBy: 'User Name',
        modifiedDate: new Date(),
        modifiedBy: 'User Name',
      } as Group,
      {
        id: 103,
        title: 'Sample Group 103',
        description: 'Lorem ipsum dolor sit amet',
        coverImageUrl: '/stock/fundations-cover.png',
        documentGroups: [
          {
            documentId: 1,
            groupId: 1,
            ordinal: 0,
            document: null,
            group: null,
          },
        ],
        accessCodes: [],
        createdDate: new Date(),
        createdBy: 'User Name',
        modifiedDate: new Date(),
        modifiedBy: 'User Name',
      } as Group,
      {
        id: 104,
        title: 'Sample Group 104',
        description: 'Lorem ipsum dolor sit amet',
        coverImageUrl: '/stock/fundations-cover.png',
        documentGroups: [
          {
            documentId: 1,
            groupId: 1,
            ordinal: 0,
            document: null,
            group: null,
          },
        ],
        accessCodes: [],
        createdDate: new Date(),
        createdBy: 'User Name',
        modifiedDate: new Date(),
        modifiedBy: 'User Name',
      } as Group,
      {
        id: 105,
        title: 'Sample Group 105',
        description: 'Lorem ipsum dolor sit amet',
        coverImageUrl: '/stock/fundations-cover.png',
        documentGroups: [
          {
            documentId: 1,
            groupId: 1,
            ordinal: 0,
            document: null,
            group: null,
          },
        ],
        accessCodes: [],
        createdDate: new Date(),
        createdBy: 'User Name',
        modifiedDate: new Date(),
        modifiedBy: 'User Name',
      } as Group,
    ];
  }

  function loadMockServices(): void {
    mockAdminService = {
      getGroupDirectory: jasmine.createSpy('getGroupDirectory').and.returnValue(
        of({
          data: mockGroups,
          total: 100,
        })
      ),
    };

    mockTitleService = {
      setPageName: jasmine.createSpy('setPageName'),
    };
  }

  // Configure the test bed
  function setupTestBed(): void {
    TestBed.configureTestingModule({
      declarations: [AdminGroupsComponent],
      providers: [
        { provide: AdminService, useValue: mockAdminService },
        {
          provide: TitleService,
          useValue: mockTitleService,
        },
        {
          provide: 'productName',
          useValue: 'Document Viewer',
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }

  // Initialize the component var
  function setupComponent(): void {
    fixture = TestBed.createComponent(AdminGroupsComponent);
    component = fixture.componentInstance;

    component.ngOnInit();
  }
});
