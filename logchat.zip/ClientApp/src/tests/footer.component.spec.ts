import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FooterComponent } from '../app/components/footer/footer.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('FooterComponent', () => {
  let component: FooterComponent;
  let fixture: ComponentFixture<FooterComponent>;

  beforeEach(async () => {
    setupTestBed();
  });

  beforeEach(() => {
    setupComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should properly register copyright years', () => {
    component.ngOnInit();
    expect(component.copyrightYears).toBeTruthy();
  });

  // Configure the test bed
  function setupTestBed(): void {
    TestBed.configureTestingModule({
      declarations: [FooterComponent],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }

  // Initialize the component var
  function setupComponent(): void {
    fixture = TestBed.createComponent(FooterComponent);
    component = fixture.componentInstance;
  }
});
