import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TitleService } from '@wilson/wilsonng';

import { ClientComponent } from '../app/funnels/client/client.component';

describe('ClientComponent', () => {
  let component: ClientComponent;
  let fixture: ComponentFixture<ClientComponent>;
  let mockTitleService: any;

  beforeEach(async () => {
    loadMockServices();
    await TestBed.configureTestingModule({
      providers: [
        {
          provide: TitleService,
          useValue: mockTitleService,
        },
        {
          provide: 'productName',
          useValue: 'Document Viewer',
        },
      ],
      declarations: [ClientComponent],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  function loadMockServices() {
    mockTitleService = {
      setPageName: jasmine.createSpy('setPageName'),
      setQualifier: jasmine.createSpy('setQualifier'),
    };
  }
});
