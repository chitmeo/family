import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';

import { XSiteComponent } from '../app/funnels/xsite/xsite.component';
import { HttpClientModule } from '@angular/common/http';
import { TitleService } from '@wilson/wilsonng';

describe('XSiteComponent', () => {
  let component: XSiteComponent;
  let fixture: ComponentFixture<XSiteComponent>;
  let mockRoute: any;
  let mockTitleService: any;

  beforeEach(async () => {
    loadMockServices();
    setupTestBed();
  });

  beforeEach(() => {
    setupComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should init properly', () => {
    mockRoute.snapshot.queryParams = {
      xSite: '1',
      return: 'https://community.wilsonacademy.com',
      programId: 'fundations-1',
      title: 'Fundations Level 1',
      subtitle: 'Learning Community',
      hasReg: '0',
    };
    component.ngOnInit();
    expect(component.returnUrl).toEqual('https://community.wilsonacademy.com');
    expect(component.theme).toEqual('fundations-1');
    expect(component.title).toEqual('Fundations Level 1');
    expect(component.subtitle).toEqual('Learning Community');
    expect(component.hasReg).toBeFalse();
  });

  function loadMockServices(): void {
    mockRoute = {
      snapshot: {
        queryParams: {},
      },
    };

    mockTitleService = {
      setPageName: jasmine.createSpy('setPageName'),
    };
  }

  function setupTestBed(): void {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      declarations: [XSiteComponent],
      providers: [
        { provide: ActivatedRoute, useValue: mockRoute },
        {
          provide: TitleService,
          useValue: mockTitleService,
        },
        {
          provide: 'productName',
          useValue: 'Document Viewer',
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }

  function setupComponent(): void {
    fixture = TestBed.createComponent(XSiteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }
});
