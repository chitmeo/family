import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Confirmation, ConfirmationService, MessageService } from 'primeng/api';
import { AdminAttachmentsComponent } from 'src/app/components/admin-attachments/admin-attachments.component';
import { AttachmentsService } from 'src/app/services/attachments.service';
import { MockData } from './mockdata';

describe('AdminAttachmentsComponent', () => {
  let component: AdminAttachmentsComponent;
  let fixture: ComponentFixture<AdminAttachmentsComponent>;
  let mockAttachmentsService: any;
  let mockMessageService: any;
  let mockConfirmationService: any;
  let mockForm: any;
  let fake: MockData;

  beforeEach(async () => {
    loadMockServices();
    setupTestBed();
    setupComponent();
    loadMockData();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have input mockPagesWithAttachments', () => {
    expect(component.pagesWithAttachments).toBeTruthy();
  });

  it('should call the confirm delete service before deleting page', () => {
    component.form = mockForm;
    const event = new MouseEvent('click');
    component.pagesWithAttachments[0] = fake.pageWithVideoData;
    component.deletePage(event, fake.pageWithVideoData);
    expect(mockConfirmationService.confirm).toHaveBeenCalled();
    expect(mockAttachmentsService.deletePage).toHaveBeenCalledWith(
      fake.pageWithVideoData.pageNumber
    );
    expect(component.form.markAsDirty).toHaveBeenCalled();
  });

  it('should delete video from a selected pages video array', () => {
    component.form = mockForm;
    component.pagesWithAttachments[0].videos = [fake.videos[0]];
    const event = new MouseEvent('click');
    component.deleteVideo(
      event,
      component.pagesWithAttachments[0],
      fake.videos[0]
    );
    expect(mockConfirmationService.confirm).toHaveBeenCalled();
    expect(mockAttachmentsService.deleteAttachment).toHaveBeenCalledWith(
      component.pagesWithAttachments[0].pageNumber,
      fake.videos[0].id
    );
    expect(component.form.markAsDirty).toHaveBeenCalled();
  });

  /**
   * Setup mock attachment data
   */
  function loadMockData(): void {
    fake = new MockData();
    component.pagesWithAttachments = fake.pagesWithAttachments;
    mockForm = {
      markAsDirty: jasmine.createSpy('markAsDirty'),
    };
  }

  /**
   * Setup mock services
   */
  function loadMockServices(): void {
    mockConfirmationService = {
      confirm: jasmine
        .createSpy('confirm')
        .and.callFake((confirmation: Confirmation) => confirmation.accept()),
    };
    mockMessageService = {
      add: jasmine.createSpy('add'),
    };
    mockAttachmentsService = {
      pagesWithAttachments: jasmine.createSpy('pagesWithAttachments'),
      getAttachmentDetails: jasmine.createSpy('getAttachmentDetails'),
      deletePage: jasmine.createSpy('deletePage'),
      deleteAttachment: jasmine.createSpy('deleteAttachment'),
    };
  }

  /**
   * Configure test bed
   */
  function setupTestBed(): void {
    TestBed.configureTestingModule({
      declarations: [AdminAttachmentsComponent],
      providers: [
        { provide: AttachmentsService, useValue: mockAttachmentsService },
        { provide: ConfirmationService, useValue: mockConfirmationService },
        { provide: MessageService, useValue: mockMessageService },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }

  // Initialize the component var
  function setupComponent(): void {
    fixture = TestBed.createComponent(AdminAttachmentsComponent);
    component = fixture.componentInstance;
  }
});
