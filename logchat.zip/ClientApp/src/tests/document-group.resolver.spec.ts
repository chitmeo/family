import { NO_ERRORS_SCHEMA } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { DocumentService } from 'src/app/services/document.service';
import { SessionService } from 'src/app/services/session.service';

import { DocumentGroupResolver } from '../app/resolvers/document-group.resolver';

describe('DirectoryResolver', () => {
  let service: DocumentGroupResolver;
  let mockDocumentService: any;
  let mockSessionService: any;

  beforeEach(() => {
    loadMockServices();
    configureTestBed();
    service = TestBed.inject(DocumentGroupResolver);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get current document group if there is one', () => {
    // Just passing in null since we don't actually use either of these args in the method body
    service.resolve(null, null);
    expect(mockDocumentService.getCurrentDocumentGroup).toHaveBeenCalledTimes(
      2
    );
    expect(mockSessionService.getSessionInformation).not.toHaveBeenCalled();
  });

  it('should get document code from session if there is no current document group', () => {
    mockDocumentService.getCurrentDocumentGroup.and.returnValue(null);
    service.resolve(null, null);
    expect(mockDocumentService.getCurrentDocumentGroup).toHaveBeenCalledTimes(
      1
    );
    expect(mockSessionService.getSessionInformation).toHaveBeenCalledTimes(1);
  });

  function configureTestBed(): void {
    TestBed.configureTestingModule({
      providers: [
        { provide: DocumentService, useValue: mockDocumentService },
        { provide: SessionService, useValue: mockSessionService },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    });
  }

  function loadMockServices(): void {
    mockSessionService = {
      getSessionInformation: jasmine
        .createSpy('getSessionInformation')
        .and.returnValue({
          user: {
            id: 'some-id',
          },
          accessCode: '123',
        }),
    };

    mockDocumentService = {
      getCurrentDocumentGroup: jasmine
        .createSpy('getCurrentDocumentGroup')
        .and.returnValue(of(null)),
      getDocumentGroupByShareCode: jasmine
        .createSpy('getDocumentGroupByShareCode')
        .and.returnValue(of(null)),
    };
  }
});
