import { TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { DocumentService } from '../app/services/document.service';
import { of } from 'rxjs';
import { Guid } from 'guid-typescript';
import { ApiService } from '@wilson/wilsonng';
import { Wilson } from '../def/Wilson';
import ViewDocument = Wilson.ViewDocument;
import ViewGroup = Wilson.ViewGroup;

describe('DocumentService', () => {
  let service: DocumentService;
  let documentGroup: ViewGroup;
  let codeText: string;
  let mockApiService: any;

  beforeEach(() => {
    loadMockData();
    loadMockServices();
    configureTestBed();
    service = TestBed.inject(DocumentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
    expect(service.getCurrentDocumentGroup).toBeDefined();
  });

  it('should return and cache a documentGroup when getDocumentGroupByShareCode()', () => {
    service.getDocumentGroupByShareCode(codeText).subscribe((response) => {
      expect(mockApiService.unAuthedGet).toHaveBeenCalledWith(
        `document/GetDocumentGroupByShareCode/${codeText}/${Guid.EMPTY}`
      );
      expect(response).toEqual(documentGroup);
      expect(service.getCurrentDocumentGroup()).toEqual(documentGroup);
    });
  });

  it('should get a document group security meta by share code', () => {
    service.getDocumentGroupSecurityMetaByShareCode(codeText).subscribe(() => {
      expect(mockApiService.unAuthedGet).toHaveBeenCalledWith(
        `document/GetDocumentGroupSecurityMetaByShareCode/${codeText}`
      );
    });
  });

  it('should reset the current document group', () => {
    service.getDocumentGroupByShareCode(codeText).subscribe(() => {
      expect(service.getCurrentDocumentGroup()).toEqual(documentGroup);
      service.resetCurrentDocumentGroup();
      expect(service.getCurrentDocumentGroup()).toBeNull();
    });
  });

  function configureTestBed(): void {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes([])],
      providers: [{ provide: ApiService, useValue: mockApiService }],
      schemas: [NO_ERRORS_SCHEMA],
    });
  }

  function loadMockData(): void {
    codeText = 'some-code-text';
    documentGroup = {
      id: 333,
      title: 'A Test Title',
      description: 'A really cool description',
      coverImageUrl: '/stock/fundations-cover.png',
      allowAnonymousEntry: false,
      requiresUniversalLogin: false,
      documents: [
        {
          id: 111,
          title: 'Document 1 Title',
          description: 'This is the description for Document 1',
          thumbnailUrl:
            'https://en.wikipedia.org/wiki/Owl#/media/File:Eastern_Barn_Owl_(Tyto_javanica_stertens),_Raigad,_Maharashtra.jpg',
          filePath:
            'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
          ordinal: 0,
          allowAdminDelete: false,
          allowPrint: false,
          allowSave: false,
          attachments: [],
          pageOffset: 1,
          watermark: true,
          selectable: false,
        } as ViewDocument,
        {
          id: 222,
          title: 'Document 2 Title',
          description: 'This is the description for Document 2',
          thumbnailUrl:
            'https://en.wikipedia.org/wiki/Owl#/media/File:Athene_cuniculariaa.jpg',
          filePath:
            'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
          ordinal: 1,
          allowAdminDelete: false,
          allowPrint: false,
          allowSave: false,
          attachments: [],
          pageOffset: 1,
          watermark: false,
          selectable: false,
        } as ViewDocument,
      ],
      codeText: 'text123',
    } as ViewGroup;
  }

  function loadMockServices(): void {
    mockApiService = {
      unAuthedGet: jasmine
        .createSpy('unAuthedGet')
        .and.returnValue(of(documentGroup)),
    };
  }
});
