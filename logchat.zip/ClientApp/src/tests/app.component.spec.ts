import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import {
  GoogleAnalyticsService,
  RedirectService,
  RouterNavigationService,
} from '@wilson/wilsonng';
import { AppComponent } from '../app/app.component';
import { PageVisibilityService } from 'src/app/services/page-visibility.service';
import { Router } from '@angular/router';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let mockGoogleAnalyticsService: any;
  let mockRouterNavigationService: any;
  let mockPageVisibilityService: any;
  let mockRouter: any;
  let mockRedirectService: any;

  beforeEach(async () => {
    loadMockServices();
    setupTestBed();
  });

  beforeEach(() => {
    setupComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize correctly', () => {
    component.ngOnInit();
    expect(
      mockRouterNavigationService.startTrackingPreviousUrl
    ).toHaveBeenCalled();
    expect(component.pageVisible).toEqual(true);
  });

  it('should redirect the user and clear the cookie if this is a NON-admin route', () => {
    const path = '/directory';
    mockRedirectService.getRedirectCookie.and.returnValue(path);
    component.ngOnInit();
    expect(mockRouter.navigateByUrl).toHaveBeenCalledWith(path);
    expect(mockRedirectService.clearRedirectCookie).toHaveBeenCalled();
  });

  it('should redirect the user but NOT clear the cookie if this is an ADMIN route', () => {
    const path = '/admin/something';
    mockRedirectService.getRedirectCookie.and.returnValue(path);
    component.ngOnInit();
    expect(mockRouter.navigateByUrl).toHaveBeenCalledWith(path);
    expect(mockRedirectService.clearRedirectCookie).not.toHaveBeenCalled();
  });

  // Set up mock data, providers and method spies
  function loadMockServices(): void {
    mockGoogleAnalyticsService = {
      initializeGoogleAnalyticsPageHit: jasmine.createSpy(
        'initializeGoogleAnalyticsPageHit'
      ),
    };
    mockRouterNavigationService = {
      startTrackingPreviousUrl: jasmine.createSpy('startTrackingPreviousUrl'),
      router: {
        events: {
          pipe: jasmine.createSpy('pipe').and.returnValue(of(null)),
        },
      },
    };
    mockPageVisibilityService = {
      pageVisible: of(true),
    };
    mockRouter = {
      navigateByUrl: jasmine.createSpy('navigateByUrl'),
    };
    mockRedirectService = {
      getRedirectCookie: jasmine.createSpy('getRedirectCookie'),
      clearRedirectCookie: jasmine.createSpy('clearRedirectCookie'),
    };
  }

  // Configure the test bed
  function setupTestBed(): void {
    TestBed.configureTestingModule({
      declarations: [AppComponent],
      providers: [
        {
          provide: GoogleAnalyticsService,
          useValue: mockGoogleAnalyticsService,
        },
        {
          provide: RouterNavigationService,
          useValue: mockRouterNavigationService,
        },
        {
          provide: PageVisibilityService,
          useValue: mockPageVisibilityService,
        },
        {
          provide: Router,
          useValue: mockRouter,
        },
        {
          provide: RedirectService,
          useValue: mockRedirectService,
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }

  // Initialize the component var
  function setupComponent(): void {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
  }
});
