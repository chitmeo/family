import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { HttpErrorInterceptor } from 'src/app/interceptors/http-error.interceptor';
import { Router } from '@angular/router';

describe('HTTPErrorInterceptor', () => {
  let interceptor: HttpErrorInterceptor;
  let mockRouter: any;
  let httpClient: HttpClient;
  let httpMock: HttpTestingController;
  let testUrl: string;

  beforeEach(() => {
    loadMockData();
    loadMockServices();
    loadTestBed();
  });

  it('should be created', () => {
    expect(interceptor).toBeTruthy();
  });

  it('should log out of auth0 when error status is a 401', () => {
    // Make an HTTP GET request
    httpClient.get<Data>(testUrl).subscribe({
      error: (error) => {
        expect(error.status).toEqual(401);
      },
    });

    const req = httpMock.expectOne(testUrl);

    // Respond with mock error
    req.flush(
      {
        errorMessage: 'Uh oh!',
        errors: {
          1: 'you are not authorized',
        },
      },
      {
        status: 401,
        statusText: 'Unauthorized',
      }
    );

    expect(mockRouter.navigate).toHaveBeenCalledWith(['forbidden']);
  });

  it('should log out of auth0 when error status is a 403', () => {
    // Make an HTTP GET request
    httpClient.get<Data>(testUrl).subscribe({
      error: (error) => {
        expect(error.status).toEqual(403);
      },
    });

    const req = httpMock.expectOne(testUrl);

    // Respond with mock error
    req.flush(
      {
        errorMessage: 'Uh oh!',
        errors: {
          1: 'you are FORBIDDEN',
        },
      },
      {
        status: 403,
        statusText: 'Forbidden',
      }
    );

    expect(mockRouter.navigate).toHaveBeenCalledWith(['forbidden']);
  });

  it('should NOT log out of auth0 when error status is something other than 401 or 403', () => {
    // Make an HTTP GET request
    httpClient.get<Data>(testUrl).subscribe({
      error: (error) => {
        expect(error.status).toEqual(418);
      },
    });

    const req = httpMock.expectOne(testUrl);

    // Respond with mock error
    req.flush(
      {
        errorMessage: 'Im a teapot, baby!',
        errors: {
          1: 'tea time',
        },
      },
      {
        status: 418,
        statusText: 'Am teapot',
      }
    );

    expect(mockRouter.navigate).not.toHaveBeenCalled();
  });

  function loadMockData() {
    testUrl = 'https://some-dummy-url.com';
  }

  function loadMockServices() {
    mockRouter = {
      navigate: jasmine.createSpy('navigate'),
    };
  }

  function loadTestBed() {
    TestBed.configureTestingModule({
      providers: [
        HttpErrorInterceptor,
        { provide: Router, useValue: mockRouter },
        {
          provide: HTTP_INTERCEPTORS,
          useClass: HttpErrorInterceptor,
          multi: true,
        },
      ],
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes([])],
    });

    httpClient = TestBed.inject(HttpClient);
    httpMock = TestBed.inject(HttpTestingController);
    interceptor = TestBed.inject(HttpErrorInterceptor);
  }

  interface Data {
    name: string;
  }
});
