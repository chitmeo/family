import { APP_INITIALIZER, NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule, Title } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { UIModule } from 'src/app/ui.module';
import { MessageService } from 'primeng/api';
import {
  ApiService,
  AuthenticationService,
  TitleService,
} from '@wilson/wilsonng';
import { InitialLoadService } from './services/initial-load.service';
import { HttpErrorInterceptor } from './interceptors/http-error.interceptor';

@NgModule({
  imports: [
    // core
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RoutingModule,
    UIModule,
  ],
  providers: [
    InitialLoadService,
    MessageService,
    Title,
    ApiService,
    TitleService,
    {
      provide: 'productName',
      useValue: 'Document Viewer',
    },
    {
      provide: 'baseApiUrl',
      useValue: document.getElementsByTagName('base')[0].href,
    },
    { provide: HTTP_INTERCEPTORS, useClass: HttpErrorInterceptor, multi: true },
    {
      provide: APP_INITIALIZER,
      useFactory: (ils: InitialLoadService) => () => ils.getInitialLoad(),
      deps: [InitialLoadService],
      multi: true,
    },
    {
      provide: APP_INITIALIZER,
      useFactory: (as: AuthenticationService) => () => as.getUser(),
      deps: [AuthenticationService],
      multi: true,
    },
  ],
  declarations: [
    // Components
    AppComponent,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
