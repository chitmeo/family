import { AfterViewInit, Directive, ElementRef, HostListener, Input, Optional } from '@angular/core';
import { NgModel } from '@angular/forms';

@Directive({
  selector: 'textarea[autoResizeTextarea]'
})
export class AutoResizeTextareaDirective implements AfterViewInit {
  @Input() minRows = 1;
  @Input() maxRows = 5;

  private readonly _textarea: HTMLTextAreaElement;

  constructor(
    private readonly el: ElementRef<HTMLTextAreaElement>,
    @Optional() private readonly ngModel: NgModel
  ) {
    this._textarea = this.el.nativeElement;
  }

  ngAfterViewInit(): void {
    this.adjust();

    if (this.ngModel) {
      // resize even when clearing by code
      this.ngModel.valueChanges?.subscribe(() => {
        this.adjust();
      });
    }
  }

  @HostListener('input')
  onInput(): void {
    this.adjust();
  }

  private adjust(): void {
    const ta = this._textarea;

    // Reset to original row number for accurate calculation
    ta.rows = this.minRows;

    const style = getComputedStyle(ta);
    const defaultPaddingTop = parseFloat(style.paddingTop) || 0;
    const defaultPaddingBottom = parseFloat(style.paddingBottom) || 0;
    let lineHeight: number;

    if (style.lineHeight === 'normal') {
      const fontSize = parseFloat(style.fontSize) || 16;
      lineHeight = fontSize * 1.2;
    } else {
      lineHeight = parseFloat(style.lineHeight) || 25;
    }

    const contentHeight = ta.scrollHeight - defaultPaddingTop - defaultPaddingBottom;
    const needed = Math.min(this.maxRows, Math.max(this.minRows, Math.ceil(contentHeight / lineHeight)));

    if (ta.rows != needed) {
      ta.rows = needed;
    }
  }
}
