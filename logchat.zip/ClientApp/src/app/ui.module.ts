import { NgModule } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { InputNumberModule } from 'primeng/inputnumber';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { CheckboxModule } from 'primeng/checkbox';
import { RadioButtonModule } from 'primeng/radiobutton';
import { DropdownModule } from 'primeng/dropdown';
import { TableModule } from 'primeng/table';
import { TooltipModule } from 'primeng/tooltip';
import { MenuModule } from 'primeng/menu';
import { CalendarModule } from 'primeng/calendar';
import { MultiSelectModule } from 'primeng/multiselect';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { FileUploadModule } from 'primeng/fileupload';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { ToastModule } from 'primeng/toast';
import { DialogModule } from 'primeng/dialog';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { PaginatorModule } from 'primeng/paginator';
import { SidebarModule } from 'primeng/sidebar';
import { TileModule, SpinnerModule, VideoPlayerModule } from '@wilson/wilsonng';
import { SkeletonModule } from 'primeng/skeleton';
import { DragDropModule } from 'primeng/dragdrop';
import { ConfirmPopupModule } from 'primeng/confirmpopup';
import { ConfirmationService } from 'primeng/api';
import { PanelModule } from 'primeng/panel';
import { FocusTrapModule } from 'primeng/focustrap';
import { SweetAlert2Module } from '@sweetalert2/ngx-sweetalert2';

@NgModule({
  providers: [ConfirmationService],
  imports: [
    // UI
    ButtonModule,
    InputTextModule,
    InputNumberModule,
    InputTextareaModule,
    DropdownModule,
    TableModule,
    TooltipModule,
    CheckboxModule,
    RadioButtonModule,
    MenuModule,
    CalendarModule,
    MultiSelectModule,
    BreadcrumbModule,
    FileUploadModule,
    OverlayPanelModule,
    AutoCompleteModule,
    ToastModule,
    DialogModule,
    ProgressSpinnerModule,
    PaginatorModule,
    SidebarModule,
    SpinnerModule,
    TileModule,
    SkeletonModule,
    DragDropModule,
    ConfirmPopupModule,
    VideoPlayerModule,
    PanelModule,
    FocusTrapModule,
    SweetAlert2Module,
  ],
  exports: [
    ButtonModule,
    InputTextModule,
    InputNumberModule,
    InputTextareaModule,
    DropdownModule,
    TableModule,
    TooltipModule,
    CheckboxModule,
    RadioButtonModule,
    MenuModule,
    CalendarModule,
    MultiSelectModule,
    BreadcrumbModule,
    FileUploadModule,
    OverlayPanelModule,
    AutoCompleteModule,
    ToastModule,
    DialogModule,
    ProgressSpinnerModule,
    PaginatorModule,
    SidebarModule,
    SpinnerModule,
    TileModule,
    SkeletonModule,
    DragDropModule,
    ConfirmPopupModule,
    VideoPlayerModule,
    PanelModule,
    FocusTrapModule,
    SweetAlert2Module,
  ],
})
export class UIModule {}
