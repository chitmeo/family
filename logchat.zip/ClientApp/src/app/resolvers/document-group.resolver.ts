import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  ResolveFn,
  RouterStateSnapshot,
} from '@angular/router';
import { of } from 'rxjs';
import { DocumentService } from '../services/document.service';
import { SessionService } from '../services/session.service';
import { Wilson } from '../../def/Wilson';
import ViewGroup = Wilson.ViewGroup;

@Injectable({
  providedIn: 'root',
})
export class DocumentGroupResolver {
  constructor(
    private documentService: DocumentService,
    private sessionService: SessionService
  ) {}

  resolve: ResolveFn<ViewGroup> = (
    _route: ActivatedRouteSnapshot,
    _snapshot: RouterStateSnapshot
  ) => {
    if (this.documentService.getCurrentDocumentGroup()) {
      return of(this.documentService.getCurrentDocumentGroup());
    } else {
      const session = this.sessionService.getSessionInformation();
      return this.documentService.getDocumentGroupByShareCode(
        session.accessCode,
        session?.user?.id
      );
    }
  };
}
