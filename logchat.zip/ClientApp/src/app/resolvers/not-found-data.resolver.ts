import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  ResolveFn,
  RouterStateSnapshot,
} from '@angular/router';
import {
  NotFoundData,
  RouterNavigationService,
  TitleService,
} from '@wilson/wilsonng';

@Injectable({
  providedIn: 'root',
})
export class NotFoundDataResolver {
  constructor(
    private titleService: TitleService,
    private routerNavigationService: RouterNavigationService
  ) {}

  resolve: ResolveFn<NotFoundData> = (
    _route: ActivatedRouteSnapshot,
    _snapshot: RouterStateSnapshot
  ) => {
    return {
      iconUrl: '../../assets/svg/floating-icons-full.svg',
      title: this.titleService.generatePageTitleWithNewName('Page Not Found'),
      message: '',
      goBackFn: () => {
        this.routerNavigationService.goToPreviousUrl('/login');
      },
    };
  };
}
