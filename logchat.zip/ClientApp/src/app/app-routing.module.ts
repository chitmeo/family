import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SiteAvailabilityGuard } from './guards/site-availability.guard';

const routes: Routes = [
  {
    path: 'viewer',
    canActivate: [SiteAvailabilityGuard],
    canActivateChild: [SiteAvailabilityGuard],
    loadChildren: () =>
      import('./funnels/client/client.module').then((m) => m.ClientModule),
  },
  {
    path: 'admin',
    canActivate: [SiteAvailabilityGuard],
    canActivateChild: [SiteAvailabilityGuard],
    loadChildren: () =>
      import('./funnels/admin/admin.module').then((m) => m.AdminModule),
  },
  {
    path: 'iframe',
    canActivate: [SiteAvailabilityGuard],
    canActivateChild: [SiteAvailabilityGuard],
    loadChildren: () =>
      import('./funnels/iframe/iframe.module').then((m) => m.IframeModule),
  },
  {
    path: 'xsite',
    canActivate: [SiteAvailabilityGuard],
    canActivateChild: [SiteAvailabilityGuard],
    loadChildren: () =>
      import('./funnels/xsite/xsite.module').then((m) => m.XSiteModule),
  },
  {
    path: '',
    loadChildren: () =>
      import('./funnels/unauthed/unauthed.module').then(
        (m) => m.UnauthedModule
      ),
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      enableTracing: false,
      scrollPositionRestoration: 'top',
      // We need to disable the initialNavigation until we have the initialLoad, since our site-availability guard depends on it
      initialNavigation: 'disabled',
    }),
  ],
  exports: [RouterModule],
})
export class RoutingModule {}
