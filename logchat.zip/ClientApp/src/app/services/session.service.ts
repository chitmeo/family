import { Injectable } from '@angular/core';
import { ApiService } from '@wilson/wilsonng';
import * as CryptoJS from 'crypto-js';
import { timer } from 'rxjs';
import { switchMap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class SessionService {
  key = 'dv::si';

  constructor(private apiService: ApiService) {
    this.keepServerSessionAlive();
  }

  setSessionInformation(session: Session): void {
    if (session) {
      const json = JSON.stringify(session);
      sessionStorage.setItem(this.key, CryptoJS.AES.encrypt(json, this.key));
    }
  }

  getSessionInformation(): Session {
    const encryptedString = sessionStorage.getItem(this.key);
    if (encryptedString) {
      try {
        return JSON.parse(
          CryptoJS.AES.decrypt(encryptedString, this.key).toString(
            CryptoJS.enc.Utf8
          )
        );
      } catch (error) {
        // whatever is in sessionStorage is malformed, clear it
        this.deleteSessionInformation();
        return null;
      }
    }
  }

  deleteSessionInformation(): void {
    sessionStorage.removeItem(this.key);
  }

  saveFilters(filterString: string): void {
    sessionStorage.setItem('dvFilters', filterString);
  }

  clearFilters(): void {
    sessionStorage.removeItem('dvFilters');
  }

  getFilters(): string {
    return sessionStorage.getItem('dvFilters');
  }

  keepServerSessionAlive(): void {
    // ping the server to keep the aspnet session alive.
    // emit after 1 second, then every 2 minutes
    timer(0, 120000)
      .pipe(switchMap(() => this.apiService.unAuthedGet('KeepAlive')))
      .subscribe();
  }
}

export interface Session {
  accessCode: string;
  user: User;
}

export interface User {
  id: string;
  name: string;
  email: string;
  school: string;
}
