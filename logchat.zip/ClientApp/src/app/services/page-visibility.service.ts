import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class PageVisibilityService {
  private _pageVisible = new BehaviorSubject<boolean>(true);
  public pageVisible = this._pageVisible.asObservable();

  show(): void {
    this._pageVisible.next(true);
  }

  hide(): void {
    this._pageVisible.next(false);
  }
}
