import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ApiService } from '@wilson/wilsonng';
import { Observable } from 'rxjs';
import { InitialLoadService } from './initial-load.service';

@Injectable({
  providedIn: 'root',
})
export class CommunityApiService {
  private apiService: ApiService;
  private headers: HttpHeaders;

  constructor(
    private httpService: HttpClient,
    private initialLoadService: InitialLoadService
  ) {
    this.initialize();
  }

  public initialize(): void {
    const urlPart = `https://${
      this.initialLoadService.initialLoad.isProduction ? '' : 'dev-'
    }community.wilsonacademy.com`;

    const token =
      this.initialLoadService.initialLoad.tokens['COMMUNITIES_API_KEY'];
    this.apiService = new ApiService(this.httpService, urlPart);
    this.headers = new HttpHeaders().set('SecretKey', token);
  }

  /**
   * Retrieves a video based ID
   *
   * @param videoId ID of video to be retrieved
   *
   * @returns Observable<Video>
   */
  public getVideo(videoId: string): Observable<Video> {
    return this.apiService.get<Video>(
      `/public/video/${videoId}`,
      undefined,
      this.headers
    );
  }

  /**
   * Retrieves an array of videos based on a search query
   *
   * @param term search query used to filter results
   * @returns Observable<Video>
   */
  public getVideos(ids: string[]): Observable<Video[]> {
    return this.apiService.post<Video[]>(`/public/videos/`, ids, this.headers);
  }

  /**
   * Retrieves an array of videos based on a search query
   *
   * @param term search query used to filter results
   * @returns Observable<Video>
   */
  public searchVideos(term: string, level: string): Observable<Video[]> {
    return this.apiService.get<Video[]>(
      `/public/videos/${level}/${term}`,
      undefined,
      this.headers
    );
  }
}

export interface Video {
  id: string;
  name: string;
  description: string;
  url: string;
  backupUrl: string;
  imageUrl: string;
}
