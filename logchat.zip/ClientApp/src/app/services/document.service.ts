import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { Guid } from 'guid-typescript';
import { ApiService } from '@wilson/wilsonng';
import { Wilson } from '../../def/Wilson';
import Document = Wilson.ViewDocument;
import ViewGroup = Wilson.ViewGroup;

@Injectable({
  providedIn: 'root',
})
export class DocumentService {
  private controller = 'document';
  private documentGroup: ViewGroup;
  allowAnnotations = false;
  showTableOfContents = false;

  constructor(private apiService: ApiService) {}

  public getDocumentGroupByShareCode(
    codeText: string,
    userId: string = null
  ): Observable<ViewGroup> {
    return this.apiService
      .unAuthedGet<ViewGroup>(
        `${this.controller}/GetDocumentGroupByShareCode/${codeText}/${
          userId || Guid.EMPTY
        }`
      )
      .pipe(
        tap((group: ViewGroup) => {
          // Store in cache
          this.documentGroup = group;
          return of(group);
        })
      );
  }

  public getDocumentGroupSecurityMetaByShareCode(
    codeText: string
  ): Observable<ViewGroup> {
    return this.apiService.unAuthedGet<ViewGroup>(
      `${this.controller}/GetDocumentGroupSecurityMetaByShareCode/${codeText}`
    );
  }

  public getDocumentRenderingLink(filePath: string): Observable<string> {
    return this.apiService
      .unAuthedGet<Document>(
        `${this.controller}/GetDocumentRenderingLink/${filePath}`
      )
      .pipe(map((obj) => obj.filePath));
  }

  public getDocumentForDownload(id: number): Observable<string> {
    return this.apiService
      .unAuthedGet<Document>(`${this.controller}/GetDocumentForDownload/${id}`)
      .pipe(map((obj) => obj.filePath));
  }

  public getDocumentAnnotations(
    documentId: number,
    userId: string
  ): Observable<AnnotationsData> {
    const local = localStorage.getItem(
      this.getAnnotationKeyLocalStorage(documentId)
    );

    // don't call the server if they aren't logged in
    if (!userId) return of({ server: '', local });

    return this.apiService
      .unAuthedGet<unknown>(
        `${this.controller}/GetAnnotations/${documentId}/${userId}`
      )
      .pipe(
        map(
          (obj) =>
            <AnnotationsData>{
              server: obj['data'],
              local: local,
            }
        )
      );
  }

  public saveDocumentAnnotations(
    annotationData: string,
    documentId: number,
    userId: string
  ): Observable<void> {
    if (userId) {
      const xml = new DOMParser().parseFromString(annotationData, 'text/xml');
      const data = { data: new XMLSerializer().serializeToString(xml) };
      return this.apiService.unAuthedPost<void>(
        `${this.controller}/SaveAnnotations/${documentId}/${userId}`,
        data
      );
    }

    return of(
      localStorage.setItem(
        this.getAnnotationKeyLocalStorage(documentId),
        annotationData
      )
    );
  }

  public getCurrentDocumentGroup(): ViewGroup {
    return this.documentGroup;
  }

  public resetCurrentDocumentGroup(): void {
    this.documentGroup = null;
  }

  private getAnnotationKeyLocalStorage(docId: number) {
    return `annotations_${docId}`;
  }
}

export interface AnnotationsData {
  server: string;
  local: string;
}
