import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';

@Injectable({
  providedIn: 'root',
})
export class ToastService {
  constructor(private messageService: MessageService, private router: Router) {}

  crudSuccess(type: string, method: string, detail: string = null): void {
    const detailString = detail ? `'${detail}'` : type;
    this.messageService.add({
      severity: 'success',
      summary: `${type} ${method}d`,
      detail: `${detailString} was ${method}d successfully.`,
    });
  }

  crudFailure(type: string, method: string): void {
    this.messageService.add({
      severity: 'error',
      summary: `Something went wrong`,
      detail: `${type} was not ${method}d.`,
    });
  }

  crudNotFound(type: string, id: number, redirect: string): void {
    this.messageService.add({
      severity: 'error',
      summary: `${type} Not Found`,
      detail: `Found no matching ${type.toLowerCase()} with id '${id}'.`,
    });
    this.router.navigate([redirect]);
  }

  crudDuplication(type: string, detail: string): void {
    this.messageService.add({
      severity: 'error',
      summary: `${type} not added`,
      detail: `${detail} has already been selected.`,
    });
  }

  crudInvalid(msg: string): void {
    this.messageService.add({
      severity: 'error',
      summary: `Something went wrong`,
      detail: msg,
    });
  }
}
