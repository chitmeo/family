import { Injectable } from '@angular/core';
import { ApiService } from '@wilson/wilsonng';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Video } from './community-api.service';
import { ToastService } from './toast.service';
import { Wilson } from '../../def/Wilson';
import AccessCode = Wilson.AccessCode;
import DirectoryResponse = Wilson.DirectoryResponse;
import Group = Wilson.Group;
import Document = Wilson.Document;
import Search = Wilson.Search;
import DocumentOption = Wilson.DocumentOption;

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  private controller = 'Admin';

  constructor(
    private apiService: ApiService,
    private toastService: ToastService
  ) {
    if (window['Cypress']) window['AdminService'] = this;
  }

  public getDocument(documentId: number): Observable<Document> {
    return this.apiService
      .get<Document>(`${this.controller}/GetDocument/${documentId}`)
      .pipe(
        catchError(() => {
          this.toastService.crudNotFound(
            'Document',
            documentId,
            '/admin/documents'
          );
          return of(null);
        })
      );
  }

  public getDocuments(
    search: Search,
    groupId: number = null
  ): Observable<Document[]> {
    return this.apiService.post<Document[]>(
      `${this.controller}/GetDocuments/${groupId || 0}`,
      search
    );
  }

  public getDocumentDirectory(
    search: Search
  ): Observable<DirectoryResponse<Document>> {
    return this.apiService.post<DirectoryResponse<Document>>(
      `${this.controller}/GetDocumentDirectory`,
      search
    );
  }

  public upsertDocument(
    document: Document,
    groups: Group[],
    options: DocumentOption[] = [],
    file: File = null,
    thumbnail: File = null,
    pageAttachments: DocumentPageWithAttachment[] = []
  ): Observable<number> {
    const formData = new FormData();
    if (file) {
      formData.append('file', file, file.name);
    }
    if (thumbnail) {
      formData.append('thumbnailFile', thumbnail, thumbnail.name);
    }
    formData.append('document', JSON.stringify(document));
    formData.append('groups', JSON.stringify(groups.map((x) => x.id)));
    formData.append(
      'options',
      JSON.stringify(options.map((x) => x.documentOptionTypeId))
    );
    formData.append('attachments', JSON.stringify(pageAttachments));
    return this.apiService
      .post<number>(`${this.controller}/UpsertDocument`, formData)
      .pipe(
        catchError(() => {
          this.toastService.crudFailure('Document', 'save');
          return of(-1);
        })
      );
  }

  public deleteDocument(documentId: number): Observable<number> {
    return this.apiService
      .delete<number>(`${this.controller}/DeleteDocument/${documentId}`)
      .pipe(
        catchError(() => {
          this.toastService.crudFailure('Document', 'delete');
          return of(null);
        })
      );
  }

  public getGroup(groupId: number): Observable<Group> {
    return this.apiService
      .get<Group>(`${this.controller}/GetGroup/${groupId}`)
      .pipe(
        catchError(() => {
          this.toastService.crudNotFound('Group', groupId, '/admin/groups');
          return of(null);
        })
      );
  }

  public getGroups(search: Search): Observable<Group[]> {
    return this.apiService.post<Group[]>(
      `${this.controller}/GetGroups`,
      search
    );
  }

  public getGroupDirectory(
    search: Search
  ): Observable<DirectoryResponse<Group>> {
    return this.apiService.post<DirectoryResponse<Group>>(
      `${this.controller}/GetGroupDirectory`,
      search
    );
  }

  public upsertGroup(group: Group, file: File = null): Observable<number> {
    const formData = new FormData();
    if (file) {
      formData.append('file', file, file.name);
    }
    formData.append('group', JSON.stringify(group));
    return this.apiService
      .post<number>(`${this.controller}/UpsertGroup`, formData)
      .pipe(
        catchError(() => {
          this.toastService.crudFailure('Group', 'save');
          return of(-1);
        })
      );
  }

  public deleteGroup(groupId: number): Observable<number> {
    return this.apiService
      .delete<number>(`${this.controller}/DeleteGroup/${groupId}`)
      .pipe(
        catchError(() => {
          this.toastService.crudFailure('Group', 'delete');
          return of(null);
        })
      );
  }

  public sortDocumentsInGroup(
    groupId: number,
    documentIds: number[]
  ): Observable<number> {
    return this.apiService.post<number>(
      `${this.controller}/SortDocumentsInGroup/${groupId}`,
      documentIds
    );
  }

  public getAccessCode(accessCodeId: number): Observable<AccessCode> {
    return this.apiService
      .get<AccessCode>(`${this.controller}/GetAccessCode/${accessCodeId}`)
      .pipe(
        catchError(() => {
          this.toastService.crudNotFound(
            'Document Code',
            accessCodeId,
            '/admin/access-codes'
          );
          return of(null);
        })
      );
  }

  public getAccessCodes(search: Search): Observable<AccessCode[]> {
    return this.apiService.post<AccessCode[]>(
      `${this.controller}/GetAccessCodes`,
      search
    );
  }

  public getAccessCodeDirectory(
    search: Search
  ): Observable<DirectoryResponse<AccessCode>> {
    return this.apiService.post<DirectoryResponse<AccessCode>>(
      `${this.controller}/GetAccessCodeDirectory`,
      search
    );
  }

  public getAccessCodeSecurityTypeValues(
    securityType: number,
    query: string
  ): Observable<Map<string, string>> {
    return this.apiService.get<Map<string, string>>(
      `${this.controller}/GetAccessCodeSecurityTypeValues/${securityType}/${query}`
    );
  }

  public upsertAccessCode(accessCode: AccessCode): Observable<number> {
    return this.apiService
      .post<number>(`${this.controller}/UpsertAccessCode`, accessCode)
      .pipe(
        catchError(() => {
          this.toastService.crudFailure('Document Code', 'save');
          return of(-1);
        })
      );
  }

  public deleteAccessCode(accessCodeId: number): Observable<number> {
    return this.apiService
      .delete<number>(`${this.controller}/DeleteAccessCode/${accessCodeId}`)
      .pipe(
        catchError(() => {
          this.toastService.crudFailure('Document Code', 'delete');
          return of(null);
        })
      );
  }
}

export interface DocumentPage {
  pageNumber: number;
}

export interface DocumentPageWithAttachment extends DocumentPage {
  resourceIds: string;
  videos?: Video[];
}
