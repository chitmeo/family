import { Injectable } from '@angular/core';
import { datadogRum } from '@datadog/browser-rum';

@Injectable({
  providedIn: 'root',
})
export class LogService {
  public setupDatadogMonitoring(
    datadogEnvironment: string,
    datadogSampleRate: string,
    datadogReplaySampleRate: string
  ): void {
    if (datadogEnvironment && datadogEnvironment.length) {
      datadogRum.init({
        applicationId: '29394999-8d7b-4898-a6de-4e07992a5f89',
        clientToken: 'pubea61f40cbac7ffb6f06ea34d3cdd057d',
        site: 'datadoghq.com',
        service: 'document-viewer',
        env: datadogEnvironment,
        sessionSampleRate: +datadogSampleRate || 10,
        sessionReplaySampleRate: +datadogReplaySampleRate || 0,
        trackUserInteractions: true,
        trackResources: false,
        trackLongTasks: false,
        defaultPrivacyLevel: 'mask-user-input',
      });
    }
  }
}
