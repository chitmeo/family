import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { DocumentPageWithAttachment } from './admin.service';
import { CommunityApiService, Video } from './community-api.service';

@Injectable({
  providedIn: 'root',
})
export class AttachmentsService {
  private _pagesWithAttachments = new BehaviorSubject<
    DocumentPageWithAttachment[]
  >([]);
  pagesWithAttachments = this._pagesWithAttachments.asObservable();

  constructor(private communityService: CommunityApiService) {}

  public setPagesWithAttachments(
    pagesWithAttachments: DocumentPageWithAttachment[]
  ): void {
    this._pagesWithAttachments.next(pagesWithAttachments);
  }

  public addAttachment(pageNumber: number, selectedVideo: Video): void {
    const pages = this._pagesWithAttachments.value;
    const page = pages.find((p) => p.pageNumber === pageNumber);

    if (page) {
      page.resourceIds = `${page.resourceIds},${selectedVideo.id}`;
      page.videos = page.videos
        ? [...page.videos, selectedVideo]
        : [selectedVideo];
      this.setPagesWithAttachments(pages);
    }

    if (!page) {
      const newPage = {
        pageNumber,
        resourceIds: selectedVideo.id,
        videos: [selectedVideo],
      };

      const addedPage = [...pages, newPage].sort(
        (a, b) => a.pageNumber - b.pageNumber
      );

      this.setPagesWithAttachments(addedPage);
    }
  }

  public deleteAttachment(pageNumber: number, videoId: string): void {
    const pages = this._pagesWithAttachments.value;
    const page = pages.find((p) => p.pageNumber === pageNumber);

    page.videos = page.videos.filter((v) => v.id != videoId);
    page.resourceIds = this.stringifyVideoIds(page.videos);
    this.setPagesWithAttachments(pages);

    if (!page.videos.length) {
      this.deletePage(pageNumber);
    }
  }

  public deletePage(pageNumber: number): void {
    const pages = this._pagesWithAttachments.value;

    const filteredPages = pages.filter((page) => page.pageNumber != pageNumber);
    this.setPagesWithAttachments(filteredPages);
  }

  public getAttachmentDetails(
    pageNumber: number,
    ids: string[]
  ): Observable<Video[]> {
    const pages = this._pagesWithAttachments.value;
    const page = pages.find((p) => p.pageNumber === pageNumber);

    return this.communityService.getVideos(ids).pipe(
      tap((results) => {
        page.videos = results;
      })
    );
  }

  public reorderVideos(pageNumber: number, videos: Video[]): void {
    const pages = this._pagesWithAttachments.value;
    const page = pages.find((p) => p.pageNumber === pageNumber);

    page.resourceIds = this.stringifyVideoIds(videos);
    page.videos = videos;

    this.setPagesWithAttachments(pages);
  }

  /**
   * Loops through an array of videos and compiles a string of IDs to be saved into DB
   * @param videos array of videos used to generate the resource string
   */
  stringifyVideoIds(videos: Video[]): string {
    return videos.reduce(
      (prev, current, index) => `${prev}${index ? ',' : ''}${current.id}`,
      ''
    );
  }
}
