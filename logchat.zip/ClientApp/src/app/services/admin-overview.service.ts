import { Injectable } from '@angular/core';
import { ApiService } from '@wilson/wilsonng';
import { Observable } from 'rxjs';
import { Wilson } from '../../def/Wilson';
import OverviewStatistics = Wilson.OverviewStatistics;

@Injectable({
  providedIn: 'root',
})
export class AdminOverviewService {
  private controller = 'Admin';

  constructor(private apiService: ApiService) {}

  public getOverviewStatistics(
    refreshCache = false
  ): Observable<OverviewStatistics> {
    return this.apiService.get<OverviewStatistics>(
      `${this.controller}/getOverviewStatistics`,
      [{ key: 'refreshCache', value: refreshCache.toString() }]
    );
  }
}
