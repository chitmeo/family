import { Injectable } from '@angular/core';
import { map, tap } from 'rxjs/operators';
import { GoogleAnalyticsService } from '@wilson/wilsonng';
import { LogService } from './log.service';
import { HttpBackend, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import mixpanel from 'mixpanel-browser';
import { Wilson } from '../../def/Wilson';
import InitialLoad = Wilson.InitialLoad;

@Injectable({
  providedIn: 'root',
})
export class InitialLoadService {
  initialLoad: InitialLoad;
  constructor(
    private googleAnalyticsService: GoogleAnalyticsService,
    private logService: LogService,
    private httpClient: HttpClient,
    private handler: HttpBackend,
    private router: Router
  ) {
    // Using httpClient here to bypass our interceptors
    this.httpClient = new HttpClient(this.handler);
  }

  getInitialLoad(): Promise<InitialLoad> {
    return this.httpClient
      .post('InitialLoad/GetInitialLoad', {})
      .pipe(
        map((load: InitialLoad) => (this.initialLoad = load)),
        tap(() => {
          this.router.initialNavigation();
          if (this.initialLoad) {
            this.setGoogleAnalyticsKeyAndInitialize();
            this.setMixPanelKeyAndInitialize();
            this.logService.setupDatadogMonitoring(
              this.initialLoad.tokens['DATADOG_MONITORING_ENVIRONMENT'],
              this.initialLoad.tokens['DATADOG_SAMPLE_RATE'],
              this.initialLoad.tokens['DATADOG_REPLAY_SAMPLE_RATE']
            );
          }
        })
      )
      .toPromise();
  }

  private setGoogleAnalyticsKeyAndInitialize(): void {
    const key = this.initialLoad.isProduction ? 'G-Z2R78WLQ1V' : 'G-5H2HM5NX05';
    this.googleAnalyticsService.setKey(key);
    this.googleAnalyticsService.initialize();
  }

  private setMixPanelKeyAndInitialize(): void {
    const prodToken = 'ba49ee92e74530223c8cb96c2def29ae';
    const devToken = 'd4ad2e94d03d69386a4072dda5221e1d';
    const key = this.initialLoad.isProduction ? prodToken : devToken;
    mixpanel.init(key);
    mixpanel.register({ Application: 'Document Viewer' });
  }
}
