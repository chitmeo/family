import { Pipe, PipeTransform } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';
import { MatchHighlightService } from '@wilson/wilsonng';

@Pipe({
  name: 'matchHighlight',
})
export class MatchHighlightPipe implements PipeTransform {
  constructor(private matchHighlightService: MatchHighlightService) {}

  transform(value: string, term: string): SafeHtml {
    if (term.length === 0) return value;
    return this.matchHighlightService.markContentMatches(
      value,
      term.toLowerCase()
    );
  }
}
