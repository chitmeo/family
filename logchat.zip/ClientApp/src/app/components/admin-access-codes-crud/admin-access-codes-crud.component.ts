import { Component, HostListener, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {
  UntypedFormGroup,
  Validators,
  UntypedFormBuilder,
  UntypedFormControl,
} from '@angular/forms';
import { MenuItem, SelectItem } from 'primeng/api';
import {
  AutoCompleteCompleteEvent,
  AutoCompleteSelectEvent,
} from 'primeng/autocomplete';
import { Observable } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';
import { AdminService } from 'src/app/services/admin.service';
import { ToastService } from 'src/app/services/toast.service';
import { ComponentCanDeactivate } from 'src/app/guards/pending-changes.guard';
import {
  FormErrors,
  FormGroupService,
  TitleService,
  RouterNavigationService,
  AuthenticationService,
} from '@wilson/wilsonng';
import { Wilson } from '../../../def/Wilson';
import AccessCode = Wilson.AccessCode;
import Group = Wilson.Group;
import AccessCodeSecurity = Wilson.AccessCodeSecurity;
import Swal from 'sweetalert2';

@Component({
  selector: 'app-admin-access-codes-crud',
  templateUrl: './admin-access-codes-crud.component.html',
  styleUrls: ['./admin-access-codes-crud.component.scss'],
})
export class AdminAccessCodesCrudComponent
  implements OnInit, ComponentCanDeactivate
{
  accessCodeForm: UntypedFormGroup;
  code: AccessCode;
  dialogVisible = false;
  path: MenuItem[];
  createMode: boolean;
  id: number;
  group: Group;
  groupSuggestions: Group[];
  securitySuggestions: SelectItem[];
  initTime: Date;
  expiration: Date;
  active: boolean;

  securities: SecurityType[] = [
    { name: 'Community', type: 1 },
    { name: 'Training', type: 2 },
    { name: 'Training Template', type: 3 },
  ];

  // errors
  errors: FormErrors = {
    main: '',
    codeText: '',
    expiration: '',
    groupId: '',
  };

  constructor(
    private fb: UntypedFormBuilder,
    private adminService: AdminService,
    private router: Router,
    private route: ActivatedRoute,
    private toastService: ToastService,
    private routerNavigationService: RouterNavigationService,
    private titleService: TitleService,
    private formGroupService: FormGroupService,
    private authService: AuthenticationService
  ) {}

  @HostListener('window:beforeunload')
  canDeactivate(): boolean {
    return this.accessCodeForm.pristine;
  }

  ngOnInit(): void {
    const id = this.route.snapshot.params['id'];
    if (id === 'create') {
      this.createMode = true;
      this.initUI();
    } else {
      this.createMode = false;
      this.id = +id;
      this.initUI();
      this.getAccessCode().subscribe();
    }

    this.titleService.setPageName(
      `${this.createMode ? 'Create' : 'Edit'} Document Code`
    );
  }

  goBack(): void {
    this.routerNavigationService.goToPreviousUrl('/admin/access-codes');
  }

  showDialog(): void {
    this.dialogVisible = true;
  }

  hideDialog(): void {
    this.dialogVisible = false;
  }

  initUI(): void {
    this.initForm();
    this.setupBreadcrumbs();
  }

  initForm(): void {
    this.accessCodeForm = this.fb.group({
      id: [0],
      codeText: [
        { value: '', disabled: !this.createMode },
        Validators.required,
      ],
      notes: [''],
      expiration: ['', Validators.required],
      groupId: ['', Validators.required],
      allowAnonymousEntry: [true],
    });

    // add securities to form
    this.securities.forEach((security) => {
      this.accessCodeForm.addControl(
        security.name,
        new UntypedFormControl({ value: null, disabled: true })
      );
      this.errors[security.name] = '';
    });

    // if a group is pre-selected (in query params), get group info and add it to the form
    const gId = this.route.snapshot.queryParams['groupId'];
    if (gId) {
      this.adminService
        .getGroup(gId)
        .pipe(
          tap((group) => {
            this.setValue('groupId', group.id);
            this.group = group;
          })
        )
        .subscribe();
    }

    // set values for custom binding
    this.initTime = new Date();
    this.expiration = null;
    this.group = null;
    this.active = true;
  }

  /**
   * fills the form with values from an accessCode
   *
   * @param accessCode accessCode object to fill the form with
   */
  preFillForm(accessCode: AccessCode): void {
    this.setValue('id', accessCode.id);
    this.setValue('codeText', accessCode.codeText);
    this.setValue('notes', accessCode.notes);
    this.setValue('expiration', accessCode.expiration);
    this.setValue('groupId', accessCode.groupId);
    this.setValue('allowAnonymousEntry', accessCode.allowAnonymousEntry);

    this.initTime = accessCode.createdDate;
    this.expiration = new Date(accessCode.expiration);
    this.group = accessCode.group;
    this.active = accessCode.active;

    // this will get remapped during submission
    accessCode.accessCodeSecurities.forEach((security) => {
      const tempSecurities = [...this.securities];
      const secType = tempSecurities.find(
        (x) => x.type === security.accessCodeSecurityTypeId
      );
      secType.selected = true;
      this.setValue(secType.name, {
        label: security.name,
        value: security.value,
      });
      this.securities = tempSecurities;
    });

    this.securities.forEach((sec) => {
      if (!sec.selected) {
        this.setValue(sec.name, null);
        this.accessCodeForm.controls[sec.name].disable();
      }
    });
    this.validateSecurities();

    // mark the form as untouched
    this.accessCodeForm.markAsPristine();
  }

  getAccessCode(): Observable<AccessCode> {
    return this.adminService.getAccessCode(this.id).pipe(
      tap((accessCode) => {
        if (accessCode) {
          this.code = accessCode;
          this.preFillForm(accessCode);
        } else {
          this.toastService.crudNotFound(
            'Document Code',
            this.id,
            '/admin/access-codes'
          );
        }
      })
    );
  }

  clearError(field: string): void {
    this.errors[field] = '';
  }

  /**
   * updates the value in a FormControl
   *
   * @param controlName name of the control to update
   * @param value value to set
   */
  setValue(controlName: string, value: unknown): void {
    this.accessCodeForm.controls[controlName].setValue(value);
    this.accessCodeForm.controls[controlName].markAsDirty();

    if (this.errors[controlName]) {
      this.errors[controlName] = null;
    }
  }

  /**
   * retrieves a value from a FormControl
   *
   * @param controlName name of the control
   */
  getValue(controlName: string): unknown {
    return this.accessCodeForm.controls[controlName].value;
  }

  setAnonymous(event: { checked: boolean; originalEvent: Event }): void {
    if (!this.createMode) {
      if (event.checked) {
        Swal.fire({
          title: '<div class="swal2-icon swal2-warning swal2-icon-show"><div class="swal2-icon-content">!</div></div>Warning',
          text: 'Changing this Access Code to public will display the Chatbot for all associated documents with Chatbot enabled. Are you sure you want to continue?',
          showCancelButton: true,
          customClass: {
            title: 'title',
            confirmButton: 'btn btn-primary',
            cancelButton: 'btn btn-danger'
          }
        }).then((result) => {
          if (!result.isConfirmed) {
            this.setValue('allowAnonymousEntry', false);

            return;
          }

          this.securities = this.securities.map((x) => {
            x.selected = false;
            return x;
          });

          this.validateSecurities();
        });

        return;
      }
    }

    if (event.checked) {
      this.securities = this.securities.map((x) => {
        x.selected = false;
        return x;
      });
    }

    this.validateSecurities();
  }

  setSecurity(event: { checked: boolean; originalEvent: Event }): void {
    this.validateSecurities();

    // any security setting means we cannot allow anonymous entry
    if (event.checked) {
      this.setValue('allowAnonymousEntry', false);
    }
  }

  validateSecurities(): void {
    this.securities.forEach((sec) => {
      const control = this.accessCodeForm.controls[sec.name];
      if (sec.selected) {
        this.formGroupService.setRequired(this.accessCodeForm, sec.name);
        control.enable();
      } else {
        this.formGroupService.clearValidators(this.accessCodeForm, sec.name);
        control.disable();
      }
      control.updateValueAndValidity();
    });
  }

  dirtify(): void {
    this.accessCodeForm.markAsDirty();
  }

  onGroupSelect(event: AutoCompleteSelectEvent): void {
    this.setValue('groupId', event.value.id);
    this.accessCodeForm.markAsDirty();
  }

  groupFillSuggestions(event: AutoCompleteCompleteEvent): void {
    this.adminService
      .getGroups({
        filters: [
          {
            column: 'title',
            value: event.query,
            filterType: 4,
          },
        ],
        sort: {
          column: 'title',
          direction: 1,
        },
        skip: 0,
        take: 100,
        dateRanges: null,
      })
      .pipe(
        tap((groups: Group[]) => {
          this.groupSuggestions = groups;
        })
      )
      .subscribe();
  }

  securityFillSuggestions(
    secType: number,
    event: AutoCompleteCompleteEvent
  ): void {
    if (!event.query) return;

    this.adminService
      .getAccessCodeSecurityTypeValues(secType, event.query)
      .pipe(
        tap((secTypeValues: Map<string, string>) => {
          // Turn Map into array to be used in auto-complete dropdown
          const keys = Object.keys(secTypeValues);
          this.securitySuggestions = keys.map(
            (val) =>
              ({
                label: secTypeValues[val],
                value: val,
              } as SelectItem)
          );
        })
      )
      .subscribe();
  }

  validateForm(): boolean {
    const requiredFields = ['codeText', 'expiration', 'groupId'];

    // add any selected securities to required fields
    this.securities.forEach((sec) => {
      if (sec.selected) {
        requiredFields.push(sec.name);
      }
    });

    for (const field of requiredFields) {
      if (!this.formGroupService.checkValidity(this.accessCodeForm, field)) {
        this.formGroupService.setError(this.errors, field, 'is required.');
      }
    }

    return this.accessCodeForm.valid;
  }

  submitAccessCode(closeAfterSave = true): void {
    // validate the form
    if (!this.validateForm()) return;

    // confirm security settings
    if (!this.confirmSecurity()) return;

    const accessCode: AccessCode = {
      id: this.getValue('id'),
      codeText: this.getValue('codeText'),
      notes: this.getValue('notes'),
      expiration: this.getValue('expiration'),
      allowAnonymousEntry: this.getValue('allowAnonymousEntry'),
      active: this.active,
      groupId: this.getValue('groupId'),
      accessCodeSecurities: [],
      createdDate: this.initTime,
    } as AccessCode;

    // map the selected securities to accessCodeSecurityTypes
    this.securities
      .filter((x) => x.selected)
      .forEach((security) => {
        const accessCodeSecurity: AccessCodeSecurity = {
          accessCodeSecurityTypeId: security.type,
          value: this.getValue(security.name)['value'],
        } as AccessCodeSecurity;

        accessCode.accessCodeSecurities.push(accessCodeSecurity);
      });

    this.authService
      .getUser()
      .pipe(
        map((user) => {
          if (this.createMode) accessCode.createdBy = user.name;
          accessCode.modifiedBy = user.name;
          return accessCode;
        }),
        switchMap((accessCode) =>
          this.adminService.upsertAccessCode(accessCode)
        ),
        tap((id) => {
          this.accessCodeForm.markAsPristine();
          const method = this.createMode ? 'create' : 'update';
          if (id === -1) this.toastService.crudFailure('Document Code', method);
          else {
            this.toastService.crudSuccess(
              'Document Code',
              method,
              accessCode.codeText
            );
          }
          if (closeAfterSave) this.goBack();
        })
      )
      .subscribe();
  }

  confirmDeletion(): void {
    if (!this.id || this.createMode) {
      return;
    }

    const confirmed = confirm(
      'Are you sure you want to delete this document code?'
    );
    if (confirmed) {
      this.deleteAccessCode().subscribe();
    }
  }

  deleteAccessCode(): Observable<number> {
    return this.adminService.deleteAccessCode(this.id).pipe(
      tap(() => {
        this.accessCodeForm.markAsPristine();
        this.toastService.crudSuccess('Document Code', 'delete');
        void this.router.navigate(['/admin/access-codes']);
      })
    );
  }

  setupBreadcrumbs(): void {
    this.path = [
      { label: 'Overview', routerLink: '/admin' },
      { label: 'Document Codes', routerLink: '../' },
      { label: this.createMode ? 'Create' : 'Edit' },
    ];
  }

  /**
   * Show a confirmation before saving without security.
   *
   * @returns {boolean}
   */
  confirmSecurity(): boolean {
    let isAnonymousEntryAllowed = this.getValue('allowAnonymousEntry') as boolean;
    let isSecured = this.securities.some((x) => x.selected)

    if (!isAnonymousEntryAllowed && !isSecured) {
      return confirm('Access Code security settings are not configured. This will disable the Chatbot for all associated documents. Are you sure you want to continue?');
    }

    return true;
  }
}

export interface SecurityType {
  name: string;
  type: number;
  selectedValue?: string;
  selected?: boolean;
}
