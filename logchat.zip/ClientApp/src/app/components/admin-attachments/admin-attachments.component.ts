import { Component, Input, OnInit } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { ConfirmationService } from 'primeng/api';
import { DocumentPageWithAttachment } from 'src/app/services/admin.service';
import { AttachmentsService } from 'src/app/services/attachments.service';
import { Video } from 'src/app/services/community-api.service';

@Component({
  selector: 'app-admin-attachments',
  templateUrl: './admin-attachments.component.html',
  styleUrls: ['./admin-attachments.component.scss'],
})
export class AdminAttachmentsComponent implements OnInit {
  @Input() form: UntypedFormGroup;
  pagesWithAttachments: DocumentPageWithAttachment[];
  videos: Video[];

  constructor(
    private confirmationService: ConfirmationService,
    private attachmentsService: AttachmentsService
  ) {}

  ngOnInit(): void {
    this.attachmentsService.pagesWithAttachments.subscribe(
      (pages) => (this.pagesWithAttachments = pages)
    );
  }

  /**
   * Method ran to retrieve attachment details for selected or expanded page
   * @param page the page in order to retrieve attachment data for
   */
  expandPage(page: DocumentPageWithAttachment): void {
    const ids = page.resourceIds.split(',');
    if (!page.videos || page.videos.length !== ids.length) {
      this.attachmentsService
        .getAttachmentDetails(page.pageNumber, ids)
        .subscribe();
    }
  }

  /**
   * Triggers confirmation dialoge box then calls delete method if confirmed
   * @param event click even that triggered the delete
   * @param page page to remove from this.pagesWithAttachments array
   */
  deletePage(event: Event, page: DocumentPageWithAttachment): void {
    this.confirmationService.confirm({
      key: page.pageNumber.toString(),
      target: event.target,
      acceptIcon: 'pi pi-check',
      rejectIcon: 'pi pi-times',
      acceptLabel: 'Delete',
      rejectLabel: 'Cancel',
      message: `Are you sure you want to delete all attachments on page ${page.pageNumber}?`,
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.attachmentsService.deletePage(page.pageNumber);
        this.form.markAsDirty();
      },
    });
  }

  /**
   * Triggers confirmation dialoge box then calls delete method if confirmed
   * @param event click even that triggered the delete
   * @param page page to remove from this.pagesWithAttachments array
   * @param video page to remove from this.pagesWithAttachments array
   */
  deleteVideo(
    event: Event,
    page: DocumentPageWithAttachment,
    video: Video
  ): void {
    this.confirmationService.confirm({
      key: video.id,
      target: event.target,
      acceptIcon: 'pi pi-check',
      rejectIcon: 'pi pi-times',
      acceptLabel: 'Delete',
      rejectLabel: 'Cancel',
      message: `Are you sure you want to delete ${video.name}?`,
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.attachmentsService.deleteAttachment(page.pageNumber, video.id);
        this.form.markAsDirty();
      },
    });
  }
}
