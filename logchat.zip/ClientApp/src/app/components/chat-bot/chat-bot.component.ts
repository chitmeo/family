import { Component, Input, OnInit, SecurityContext } from '@angular/core';
import { ApiService, AuthenticationService, SpinnerService } from '@wilson/wilsonng';
import mixpanel from 'mixpanel-browser';
import { marked } from 'marked';
import { DomSanitizer } from '@angular/platform-browser';

import { Wilson } from '../../../def/Wilson';
import Document = Wilson.ViewDocument;
import ViewGroup = Wilson.ViewGroup;
import { tap, catchError, of } from 'rxjs';
import { v4 as uuidv4 } from 'uuid';

interface QA {
  index?: number; // used for updating when the Question ID is null
  qId?: string; // question ID
  q: string; // question
  a: any; // answer
  t: Date; // time
  h?: boolean; // helpful
  docId?: number; // document id
}
interface ChatbotInstruction {
  id: string;
  type: 'Instruction';
  content: string;
}
interface ChatbotSuggestQuestion {
  id: string;
  type: 'SuggestQuestion';
  content: string;
}
interface ChatbotQuestion {
  id: string;
  type: 'Question';
  content: string;
}
interface ChatbotAnswer {
  id: string;
  type: 'Answer';
  content: string | undefined;
  helpful: boolean | undefined;
  waitingAnswer: boolean;
  errorMsg: any[];
}

type ChatbotMessage = ChatbotInstruction | ChatbotSuggestQuestion | ChatbotQuestion | ChatbotAnswer;

interface ChatbotThreadMessage {
  documentId: number;
  threadId: string;
  messages: Array<ChatbotMessage>;
}
interface AnswerResponse {
  threadId: string,
  role: string,
  content: string,
  createdAt: string,
}

@Component({
  selector: 'app-chat-bot',
  templateUrl: './chat-bot.component.html',
  styleUrl: './chat-bot.component.scss'
})
export class ChatBotComponent implements OnInit{
  @Input() documentGroup: ViewGroup;
  @Input() document: Document;
  readonly controller = 'chatbot'

  readonly SCRIPT_PATTERN = /<|>|<script|javascript:|onerror|onload|alert\(/i;
  readonly VIEW_CHAT = 'chat';
  readonly VIEW_HISTORY = 'history';
  readonly CHAT_HISTORY = 'chat-history';

  private readonly _threadMsgList: Array<ChatbotThreadMessage> = [];

  sidebarVisible = false;
  viewMode: string = this.VIEW_CHAT;

  invalidQuestion: boolean = false;
  question: string = ``;
  waitingAnswer: boolean = false;

  // History
  days: string[] = [];
  groupQAByDay: Record<string, QA[]> = {} as any;
  thirtyDaysAgo: number;

  get messages(): Array<ChatbotInstruction | ChatbotSuggestQuestion | ChatbotQuestion | ChatbotAnswer> {
    const threadMsg = this._getThreadMsg();

    return threadMsg?.messages ?? [];
  }

  constructor(private readonly spinnerService: SpinnerService,
    private readonly apiService: ApiService,
    private readonly sanitizer: DomSanitizer,
    private readonly authenticationService: AuthenticationService
  ) {}

  ngOnInit(): void {
    let today = new Date();
    this.thirtyDaysAgo = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 30, 0, 0, 0).getTime();
  }

  //#region Private
  private _initialChatView() {
    this._clearChatView();

    // If this is a new chat, initialize the chat view
    let threadMsg = this._getThreadMsg();

    if (threadMsg) {
      return;
    }

    threadMsg = <ChatbotThreadMessage>{
      documentId: this.document.id,
      threadId: '',
      messages: []
    }

    // Add an instruction message
    threadMsg.messages.push(<ChatbotInstruction>{
      id: `msg_${uuidv4()}`,
      type: 'Instruction',
      content: `Hi! I'm Mira, the Fundations Teacher's Manual Chatbot. \
                Ask a question in the box below, or choose from the list of popular prompts. \
                Please don’t share any student's personally identifiable information (PII) with me.`
    });

    // Add some sample questions
    const sampleQuestions = this.suggestedQuestions();

    sampleQuestions.forEach((q) => {
      threadMsg.messages.push(<ChatbotSuggestQuestion>{
        id: `msg_${uuidv4()}`,
        type: 'SuggestQuestion',
        content: q
      });
    });

    // Add a new thread message
    this._threadMsgList.push(threadMsg);
  }

  private _clearChatView() {
    this.question = '';
    this.waitingAnswer = false;
  }

  private _getThreadMsg(): ChatbotThreadMessage | undefined {
    return this._threadMsgList.find(x => x.documentId === this.document.id);
  }

  private _addMsg(question: string, answer?: string) : ChatbotThreadMessage
  {
    const msgQ = <ChatbotQuestion>{
      id: `msg_${uuidv4()}`,
      type: 'Question',
      content: question
    };
    const msgA = <ChatbotAnswer>{
      id: `msg_${uuidv4()}`,
      type: 'Answer',
      content: answer ? this.genMarkdownContent(answer) : '',
      waitingAnswer: false,
      errorMsg: [],
    };
    // The thread message always exists because of the _initialChatView() call in the beginning
    const threadMsg = this._getThreadMsg();

    threadMsg.messages.push(msgQ);
    threadMsg.messages.push(msgA);

    return threadMsg;
  }

  private _scrollToLastQuestion() {
    setTimeout(() => {
      const askContainers = document.querySelectorAll(".chat-ask-container");

      // When there are questions, scroll to the last one
      if (askContainers.length > 0) {
        const lastAskContainer = askContainers[askContainers.length - 1];

        lastAskContainer.scrollIntoView({ behavior: "smooth", inline: "nearest", block: "start" });
      }
    }, 200);
  }

  private _scrollToQuestion(msgId: string) {
    if (!msgId) {
      return;
    }

    setTimeout(() => {
      const askContainers = document.querySelectorAll('.chat-ask-container');

      // When there are questions, scroll to the question with the specified ID.
      if (askContainers.length > 0) {
        const askContainer = Array.from(askContainers).find(x =>
          x.getAttribute('data-question-id') === msgId
        );

        if (askContainer) {
          askContainer.scrollIntoView({ behavior: "smooth", inline: "nearest", block: "start" });
        }
      }
    }, 200);
  }

  private _updateHistoryItem(data: QA) {
    const listQA = this.getHistory(data.docId);
    const qa = listQA[data.index];

    if (qa) {
      listQA[data.index] = <QA>{ ...data, index: undefined };
    }

    localStorage.setItem(this.storageKey(data.docId), JSON.stringify(listQA));
  }

  private _addMsgByHistoryItem(qa: QA) {
    let lastMsgQ = null as ChatbotMessage;

    if (qa.qId) {
      const threadMsg = this._getThreadMsg();

      if (threadMsg?.messages?.length > 0) {
        const questions = threadMsg.messages.filter(x => x.type == "Question");

        if (questions.length > 0) {
          lastMsgQ = questions.find(x => x.id == qa.qId);
        }
      }
    }

    if (lastMsgQ) {
      this._scrollToQuestion(lastMsgQ.id);

      return;
    }

    // Add new question/answer to the chat view
    const threadMsg = this._addMsg(qa.q, qa.a);
    const msgQ = threadMsg.messages.at(-2);

    // Update the history with the new Question ID
    if (!qa.qId) {
      qa.qId = msgQ.id;

      this._updateHistoryItem(qa);
    }

    // Scroll to the last question
    this._scrollToLastQuestion();
  }
  //#endregion

  suggestedQuestions() {
    return this.document.sampleQuestions?.split('|') ?? [];
  }
  openSidebar() {
    this.sidebarVisible = true;
    this.waitingAnswer = false;
    this.gotoChatHome();
  }
  closeSidebar() {
    this.sidebarVisible = false;
  }
  onVisibleChange(visible: boolean) {
    if(visible) {
      mixpanel.track(`Chatbot Opened`, {'Document Id': this.document?.id});
    }
  }
  gotoChatHistory() {
    this.getChatHistory();
    this.viewMode = this.VIEW_HISTORY;
  }
  gotoChatHome() {
    this._initialChatView();
    this.viewMode = this.VIEW_CHAT;
    this.customTabIndex();
  }
  gotoChatView(qa?: QA) {
    this.viewMode = this.VIEW_CHAT;
    if(qa) {
      this._clearChatView();
      this._addMsgByHistoryItem(qa);
    }
    this.customTabIndex();
  }
  selectSuggestQuestion(question: string) {
    this.invalidQuestion = false;
    this.question = question;
    mixpanel.track(`Chatbot Select Suggested Question`, { 'Document Id': this.document?.id });
    this.ask();
  }
  onQuestionChange(value: string) {
    this.validateQuestion();
  }
  handleSubmitQuestion(event: KeyboardEvent) {
    event.preventDefault();
    this.ask();
  }

  handleAddNewLineInQuestion(event: KeyboardEvent) {
    event.preventDefault();
    const textarea = event.target as HTMLTextAreaElement;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    this.question =
      this.question.slice(0, start) + '\n' + this.question.slice(end);
    setTimeout(() => {
      const newIndex = start + 1;

      textarea.selectionStart = newIndex;
      textarea.selectionEnd = newIndex;
    });
  }
  validateQuestion() {
    let question = this.question.trim();
    this.invalidQuestion = question.length > 5000 || this.SCRIPT_PATTERN.test(question);
  }

  ask() {
    if(!this.question || this.invalidQuestion) {
      return;
    }

    this.gotoChatView();
    const question = this.question.trim();
    const threadMsg = this._addMsg(question);
    const msgQ = threadMsg.messages.at(-2);
    const msgA = <ChatbotAnswer>threadMsg.messages.at(-1);
    let body = {
          accessCode: this.documentGroup.codeText,
          documentId: this.document.id,
          threadId: threadMsg.threadId,
          question
        };

    this._clearChatView();
    this.spinnerService.deactivateInterceptor();
    this.waitingAnswer = true;
    msgA.waitingAnswer = true;

    // Scroll down to the last question
    this._scrollToLastQuestion();

    return this.apiService
      .post<AnswerResponse>(`${this.controller}/question`, body)
      .pipe(
        tap((res: AnswerResponse) => {
          this.spinnerService.activateInterceptor();

          // Update the Thread ID
          if (threadMsg.threadId !== res.threadId) {
            threadMsg.threadId = res.threadId;
          }

          // Update the answer
          msgA.content = this.genMarkdownContent(res.content);

          this.waitingAnswer = false;
          msgA.waitingAnswer = false;

          this.customTabIndex();

          // Add a new history item
          this.saveHistory({ qId: msgQ.id, q: body.question, a: res.content, t: new Date(), docId: body.documentId });
          mixpanel.track(`Chatbot Conversation`, { 'Document Id': this.document?.id });
        }),
        catchError((err: any) => {
          this.spinnerService.activateInterceptor();
          msgA.errorMsg.push({ severity: 'error', detail: err.error?.message ?? 'There was an error generating a response. Please try again later.' });
          this.waitingAnswer = false;
          msgA.waitingAnswer = false;
          return of(null);
        }),
      )
      .subscribe(() => {
        const lastMsgA = threadMsg.messages.at(-1);

        if (lastMsgA.id === msgA.id) {
          this._scrollToLastQuestion();
        }
      });
  }

  genMarkdownContent(markdownText: string) {
    const html = marked(markdownText, { async: false });
    const sanitized =  this.sanitizer.sanitize(SecurityContext.HTML, html) ?? '';

    return sanitized;
  }

  feedback(msgId: string, helpful: boolean) {
    const threadMsg = this._getThreadMsg();

    if (threadMsg) {
      const msg = threadMsg.messages.find(x => x.id == msgId);

      if (msg?.type === 'Answer') {
        msg.helpful = helpful;
      }
    }

    mixpanel.track(`Chatbot Conversation ${helpful ? 'Helpful' : 'Not Helpful'}`, { 'Document Id': this.document?.id });
  }

  storageKey(docId?: number) {
    let userId = this.authenticationService.currentUser?.wilsonId ?? '';
    return `${this.CHAT_HISTORY}:${userId}:${docId ?? this.document.id}`;
  }

  getChatHistory() {
    this.days = [];
    let listQA = this.getHistory();

    // Add an index for each item to be used for updating when the Question ID is null
    listQA = listQA.map((qa: QA, index: number) => ({ ...qa, index }));

    this.historyByDay(listQA);
  }

  getHistory(docId?: number) {
    let historyStr = localStorage.getItem(this.storageKey(docId));
    if(historyStr) {
      try {
        let listQA = JSON.parse(historyStr);
        return listQA.filter(qa => qa.t && new Date(qa.t).getTime() > this.thirtyDaysAgo)
                      .sort((a: QA, b: QA) => new Date(b.t).getTime() - new Date(a.t).getTime());
      } catch (error) {
        console.error("Error parsing chat history:", error);
        return [];
      }
    } else {
      return [];
    }
  }

  historyByDay(listQA) {
    this.groupQAByDay = listQA.reduce((acc, qa) => {
        const dateStr = new Date(qa.t).toLocaleDateString('en-US', {year: 'numeric',month: '2-digit',day: '2-digit'});
        acc[dateStr] ??= [];
        acc[dateStr].push(qa);
        return acc;
      }, {} as any);
      this.days = Object.keys(this.groupQAByDay);
  }

  saveHistory(newQA: QA) {
    let listQA = this.getHistory(newQA.docId);
    listQA.push(newQA);
    localStorage.setItem(this.storageKey(newQA.docId), JSON.stringify(listQA));
  }
  customTabIndex() {
    // support Safari
    setTimeout(() => {
      document.querySelectorAll('p-button')?.forEach((pBtn) => {
        const button = pBtn.querySelector('button');
        button.setAttribute('tabindex', '0');
        const pTooltip = pBtn.getAttribute('ptooltip');
        if(pTooltip) {
          button.setAttribute('aria-label', pTooltip);
        }
      });
    }, 200);
  }
}
