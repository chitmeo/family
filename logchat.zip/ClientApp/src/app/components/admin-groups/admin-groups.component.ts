import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Observable } from 'rxjs';
import { debounceTime, mergeMap, tap } from 'rxjs/operators';
import { AdminService } from 'src/app/services/admin.service';
import { TitleService } from '@wilson/wilsonng';
import { AdminBaseComponent } from '../admin-base/admin-base.component';
import { Wilson } from '../../../def/Wilson';
import DirectoryResponse = Wilson.DirectoryResponse;
import Group = Wilson.Group;

@Component({
  selector: 'app-admin-groups',
  templateUrl: './admin-groups.component.html',
  styleUrls: [],
})
export class AdminGroupsComponent extends AdminBaseComponent implements OnInit {
  groups: Group[];
  path: MenuItem[];
  totalRecords: number;
  pageSize = 25;

  constructor(
    private adminService: AdminService,
    private titleService: TitleService
  ) {
    super();
  }

  ngOnInit(): void {
    this.initialize();
    this.titleService.setPageName('Groups');
  }

  initialize(): void {
    this.setupBreadcrumbs();
    this.setupSearch();
    this.setupSearchHandler().subscribe();
  }

  getGroups(): Observable<DirectoryResponse<Group>> {
    return this.adminService.getGroupDirectory(this.search).pipe(
      tap((response: DirectoryResponse<Group>) => {
        this.groups = response.data;
        this.totalRecords = response.total;
      })
    );
  }

  setupSearch(): void {
    this.search = {
      filters: [],
      dateRanges: [],
      skip: 0,
      take: this.pageSize,
      sort: null,
    };
  }
  setupSearchHandler(): Observable<DirectoryResponse<Group>> {
    return this.searchSubject.pipe(
      debounceTime(500),
      mergeMap(() => this.getGroups())
    );
  }

  setupBreadcrumbs(): void {
    this.path = [
      { label: 'Overview', routerLink: '/admin' },
      { label: 'Groups' },
    ];
  }

  lazyLoadGroups(event: TableLazyLoadEvent): void {
    // event.first = First row offset
    // event.rows = Number of rows per page
    // event.sortField = Field name to sort with
    // event.sortOrder = Sort order as number, 1 for asc and -1 for dec
    // filters: FilterMetadata object having field as key and filter value, filter matchMode as value

    this.search.skip = event.first;
    this.search.take = event.rows;
    this.search.sort = {
      column: event.sortField as string,
      direction: event.sortOrder,
    };
    this.getGroups().subscribe();
  }
}
