import { Component, OnInit } from '@angular/core';
import { UtilityService } from '@wilson/wilsonng';
import mixpanel from 'mixpanel-browser';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
})
export class FooterComponent implements OnInit {
  copyrightYears: string;

  constructor(private utilityService: UtilityService) {}

  ngOnInit(): void {
    this.copyrightYears = this.utilityService.getCopyrightYearsString(2021);
  }

  /* istanbul ignore next */
  ngAfterViewInit(): void {
    this.mixPanelTracking();
  }

  /* istanbul ignore next */
  mixPanelTracking(): void {
    mixpanel.track_links('#btnTermsAndConditions', 'Go to Term and Conditions');
    mixpanel.track_links('#btnPrivacyPolicy', 'Go to Privacy Policy');
    mixpanel.track_links(
      '#btnTrademarkGuidelines',
      'Go to Trademark Guidelines'
    );
  }
}
