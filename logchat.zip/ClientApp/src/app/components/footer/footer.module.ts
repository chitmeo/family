import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FooterComponent } from './footer.component';
import { UIModule } from '../../ui.module';

@NgModule({
  declarations: [FooterComponent],
  imports: [CommonModule, UIModule],
  exports: [FooterComponent],
})
export class FooterModule {}
