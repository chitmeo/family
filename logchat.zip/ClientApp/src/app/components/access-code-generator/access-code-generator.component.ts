import { HttpParams } from '@angular/common/http';
import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
} from '@angular/core';
import { tap } from 'rxjs/operators';
import { AdminService } from 'src/app/services/admin.service';
import { AutoCompleteCompleteEvent } from 'primeng/autocomplete';
import { Wilson } from '../../../def/Wilson';
import AccessCode = Wilson.AccessCode;
import Document = Wilson.Document;

@Component({
  selector: 'app-access-code-generator',
  templateUrl: './access-code-generator.component.html',
  styleUrls: ['./access-code-generator.component.scss'],
})
export class AccessCodeGeneratorComponent implements OnChanges {
  @Input() visible = false;
  @Input() code: AccessCode;
  @Output('dialogClosed') dialogClosed = new EventEmitter();
  selectedDocument: Document;
  documentSuggestions: Document[];
  selectedPage: number;
  generatedURL: string;
  successfulCopy = false;
  allowAnnotations = false;
  showTableOfContents = false;

  constructor(private adminService: AdminService) {}

  ngOnChanges(): void {
    this.generateURL();
  }

  handleClose(): void {
    this.dialogClosed.emit();
  }

  clearSelectedPage(): void {
    this.selectedPage = null;
    this.generateURL();
  }

  generateURL(): void {
    if (this.code) {
      const base = window.location.origin;
      let params = new HttpParams();
      params = params.set('accessCode', this.code.codeText);

      if (this.selectedDocument) {
        params = params.set('documentId', this.selectedDocument.id.toString());

        if (this.selectedPage >= 1) {
          params = params.set('documentPage', this.selectedPage.toString());
        }
      }

      if (this.allowAnnotations) {
        params = params.set('ano', '1');
      }

      if (this.showTableOfContents) {
        params = params.set('toc', '1');
      }

      this.generatedURL = `${base}?${params.toString()}`;
    }
  }

  documentFillSuggestions(event: AutoCompleteCompleteEvent): void {
    this.adminService
      .getDocuments(
        {
          filters: [
            {
              column: 'title',
              value: event.query,
              filterType: 4,
            },
          ],
          sort: {
            column: 'title',
            direction: 1,
          },
          skip: 0,
          take: 100,
          dateRanges: null,
        },
        this.code.groupId
      )
      .pipe(
        tap((documents: Document[]) => {
          // only keep the documents in the group
          this.documentSuggestions = documents.map(
            (document) =>
              ({
                id: document.id,
                title: document.title,
                description: document.description,
              } as Document)
          );
        })
      )
      .subscribe();
  }

  openDocument(): void {
    if (!this.selectedDocument) {
      return;
    }

    this.adminService
      .getDocument(this.selectedDocument.id)
      .pipe(
        tap((doc) => {
          window.open(doc.filePath, '_blank');
        })
      )
      .subscribe();
  }

  copyURL(url: string): void {
    navigator.clipboard.writeText(url).then(
      () => {
        this.successfulCopy = true;
      },
      () => {
        this.successfulCopy = false;
      }
    );
  }
}
