import { Component, HostListener, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {
  UntypedFormGroup,
  Validators,
  UntypedFormBuilder,
} from '@angular/forms';
import { MenuItem, SelectItem } from 'primeng/api';
import { Observable } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';
import { AdminService } from 'src/app/services/admin.service';
import { OverlayPanel } from 'primeng/overlaypanel';
import {
  AutoCompleteCompleteEvent,
  AutoCompleteSelectEvent,
} from 'primeng/autocomplete';
import { ToastService } from 'src/app/services/toast.service';
import { FileSelectEvent, FileUpload } from 'primeng/fileupload';
import { ComponentCanDeactivate } from 'src/app/guards/pending-changes.guard';
import {
  FormErrors,
  FormGroupService,
  TitleService,
  RouterNavigationService,
  AuthenticationService,
} from '@wilson/wilsonng';
import { Wilson } from '../../../def/Wilson';
import AccessCode = Wilson.AccessCode;
import DocumentGroup = Wilson.DocumentGroup;
import Group = Wilson.Group;
import Document = Wilson.Document;

@Component({
  selector: 'app-admin-groups-crud',
  templateUrl: './admin-groups-crud.component.html',
  styleUrls: ['./admin-groups-crud.component.scss'],
})
export class AdminGroupsCrudComponent
  implements OnInit, ComponentCanDeactivate
{
  @ViewChild('coverPicker') coverPicker: FileUpload;
  @ViewChild('documents') documentPanel: OverlayPanel;
  groupForm: UntypedFormGroup;
  path: MenuItem[];
  createMode: boolean;
  id: number;
  accessCodes: AccessCode[];
  documentSuggestions: Document[];
  initTime: Date;
  documentGroups: DocumentGroup[] = [];
  coverPreviewUrl: string;
  coverPreset: string;
  coverMode: string;
  reorderMode = false;
  selectedDocumentIndex = -1;
  imagePresets: SelectItem[];
  loaded = false;
  group: Group;

  // errors
  errors: FormErrors = {
    main: '',
    title: '',
    description: '',
    cover: '',
  };

  constructor(
    private fb: UntypedFormBuilder,
    private adminService: AdminService,
    private router: Router,
    private route: ActivatedRoute,
    private routerNavigationService: RouterNavigationService,
    private toastService: ToastService,
    private titleService: TitleService,
    private formGroupService: FormGroupService,
    private authService: AuthenticationService
  ) {
    this.imagePresets = [
      {
        label: 'Administrator Community',
        value: 'administrator-community-cover.png',
      },
      { label: 'Fundations', value: 'fundations-cover.png' },
      { label: 'Fundations Pre-K', value: 'fundations-pre-k-cover.png' },
      { label: 'Just Words', value: 'just-words-cover.png' },
      { label: 'Ready to Rise', value: 'ready-to-rise.png' },
      { label: 'Wilson Academy', value: 'wilson-academy-cover.png' },
      { label: 'Wilson Cursive', value: 'wilson-cursive-cover.png' },
      { label: 'Wilson Implementation Network', value: 'WIN-cover.png' },
      { label: 'Wilson Reading System', value: 'wrs-cover.png' },
      { label: 'Wilson (Generic)', value: 'wilson-generic-cover.png' },
    ];
  }

  @HostListener('window:beforeunload')
  canDeactivate(): boolean {
    return this.groupForm.pristine;
  }

  ngOnInit(): void {
    const id = this.route.snapshot.params['id'];
    if (id === 'create') {
      this.createMode = true;
      this.loaded = true;
      this.initUI();
    } else {
      this.createMode = false;
      this.id = +id;
      this.initUI();
      this.getGroup().subscribe();
    }

    this.titleService.setPageName(
      `${this.createMode ? 'Create' : 'Edit'} Group`
    );
  }

  goBack(): void {
    this.routerNavigationService.goToPreviousUrl('/admin/groups');
  }

  initUI(): void {
    this.initForm();
    this.setupBreadcrumbs();
  }

  initForm(): void {
    this.groupForm = this.fb.group({
      id: [0],
      title: ['', Validators.required],
      description: ['', Validators.required],
      coverImageUrl: [''],
      cover: [null],
    });

    // set values for custom binding
    this.coverMode = 'none';
    this.coverPreset = this.imagePresets[0].value;
    this.initTime = new Date();
    this.accessCodes = [];
  }

  /**
   * fills the form with values from an group
   *
   * @param group group object to fill the form with
   */
  preFillForm(group: Group): void {
    this.setValue('id', group.id);
    this.setValue('title', group.title);
    this.setValue('description', group.description);
    this.setValue('cover', null);
    if (!group.coverImageUrl) {
      this.coverMode = 'none';
    } else {
      this.coverMode = group.coverImageUrl.startsWith('/stock/')
        ? 'preset'
        : 'custom';
    }
    this.initTime = group.createdDate;
    this.accessCodes = group.accessCodes;
    this.documentGroups = group.documentGroups;

    if (this.coverMode === 'preset') {
      this.coverPreset = group.coverImageUrl.replace('/stock/', '');
    } else if (this.coverMode === 'custom') {
      this.setValue('coverImageUrl', group.coverImageUrl);
    }

    // mark the form as untouched
    this.groupForm.markAsPristine();
    this.loaded = true;
  }

  getGroup(): Observable<Group> {
    return this.adminService.getGroup(this.id).pipe(
      tap((group) => {
        if (group) {
          this.group = group;
          this.preFillForm(group);
        } else {
          this.toastService.crudNotFound('Group', this.id, '/admin/groups');
        }
      })
    );
  }

  clearError(field: string): void {
    this.errors[field] = '';
  }

  /**
   * updates the value in a FormControl
   *
   * @param controlName name of the control to update
   * @param value value to set
   */
  setValue(controlName: string, value: unknown): void {
    this.groupForm.controls[controlName].setValue(value);
    this.groupForm.controls[controlName].markAsDirty();
  }

  /**
   * retrieves a value from a FormControl
   *
   * @param controlName name of the control
   */
  getValue(controlName: string): unknown {
    return this.groupForm.controls[controlName].value;
  }

  dirtify(): void {
    this.groupForm.markAsDirty();
  }

  setCover(event: FileSelectEvent): void {
    const cover = event.files[0];
    this.clearError('cover');
    const reader = new FileReader();
    reader.onload = ({ target: { result } }) => {
      this.setValue('coverImageUrl', null);
      this.coverPreviewUrl = result.toString();
      this.coverPicker.clear();
    };

    this.setValue('cover', cover);
    reader.readAsDataURL(cover);
  }

  onDocumentSelect(event: AutoCompleteSelectEvent): void {
    // only add if new value does not exist in doc groups
    if (!this.documentGroups.find((dg) => dg.documentId === event.value.id)) {
      this.documentGroups = [
        {
          documentId: event.value.id,
          ordinal: this.documentGroups.length,
          document: {
            title: event.value.title,
            description: event.value.description,
          },
        } as DocumentGroup,
        ...this.documentGroups,
      ];
      this.dirtify();
    } else {
      this.toastService.crudDuplication('Document', event.value.title);
    }
    this.documentPanel.hide();
  }

  documentFillSuggestions(event: AutoCompleteCompleteEvent): void {
    this.adminService
      .getDocuments({
        filters: [
          {
            column: 'title',
            value: event.query,
            filterType: 4,
          },
        ],
        sort: {
          column: 'title',
          direction: 1,
        },
        skip: 0,
        take: 100,
        dateRanges: null,
      })
      .pipe(
        tap((documents: Document[]) => {
          this.documentSuggestions = documents
            .filter(
              (document) =>
                !this.documentGroups.find((dg) => document.id === dg.documentId)
            )
            .map(
              (document) =>
                ({
                  id: document.id,
                  title: document.title,
                  description: document.description,
                } as Document)
            );
        })
      )
      .subscribe();
  }

  toggleReorderMode(): void {
    this.reorderMode = !this.reorderMode;
    this.selectedDocumentIndex = -1;
  }

  selectOrReorderDocument(index: number): void {
    // If we've already selected a document, then perform the reorder
    if (this.selectedDocumentIndex >= 0) {
      if (this.selectedDocumentIndex !== index) {
        this.reorderDocuments(this.selectedDocumentIndex, index);
      }
      this.selectedDocumentIndex = -1;
      this.dirtify();
    }
    // Otherwise, select this document
    else {
      this.selectedDocumentIndex = index;
    }
  }

  reorderDocuments(from: number, to: number): void {
    const docToMove = this.documentGroups.splice(from, 1)[0];
    const newIndex = to > from ? to - 1 : to;
    this.documentGroups.splice(newIndex, 0, docToMove);
  }

  rowIsSelected(index: number): boolean {
    return (
      this.selectedDocumentIndex > -1 &&
      this.documentGroups[index].documentId ===
        this.documentGroups[this.selectedDocumentIndex].documentId
    );
  }

  removeDocument(id: number): void {
    this.documentGroups = this.documentGroups.filter(
      (dg) => dg.documentId !== id
    );
    this.dirtify();
  }

  validateForm(): boolean {
    // set custom validators based on field values
    if (this.coverMode === 'custom' && !this.getValue('coverImageUrl')) {
      this.formGroupService.setRequired(this.groupForm, 'cover');
    } else {
      this.formGroupService.clearValidators(this.groupForm, 'cover');
    }

    const requiredFields = ['title', 'description', 'cover'];
    for (const field of requiredFields) {
      if (!this.formGroupService.checkValidity(this.groupForm, field)) {
        this.formGroupService.setError(this.errors, field, 'is required.');
      }
    }

    return this.groupForm.valid;
  }

  submitGroup(): void {
    // validate the form
    if (!this.validateForm()) return;

    const group: Group = {
      id: this.getValue('id'),
      title: this.getValue('title'),
      description: this.getValue('description'),
      documentGroups: this.documentGroups.map((dg) => ({
        documentId: dg.documentId,
        ordinal: dg.ordinal,
      })),
      accessCodes: this.accessCodes,
      createdDate: this.initTime,
    } as Group;

    if (this.coverMode === 'preset') {
      group.coverImageUrl = '/stock/' + this.coverPreset;
    }

    // only upload the image if in custom mode and
    let file = null;
    if (this.coverMode === 'custom') {
      file = this.getValue('cover');
    }

    // First we get the user then we call the upsert, finally we tap results and handle accordingly
    this.authService
      .getUser()
      .pipe(
        map((user) => {
          if (this.createMode) group.createdBy = user.name;
          group.modifiedBy = user.name;
          return group;
        }),
        switchMap((group) => this.adminService.upsertGroup(group, file)),
        tap((id) => {
          const method = this.createMode ? 'create' : 'update';
          this.groupForm.markAsPristine();
          if (id === -1) this.toastService.crudFailure('Group', method);
          else {
            this.toastService.crudSuccess('Group', method, group.title);
            this.goBack();
          }
        })
      )
      .subscribe();
  }

  confirmAccessCodeDeletion(id: number): void {
    const confirmed = confirm(
      'Are you sure you want to delete this document code?'
    );
    if (confirmed) {
      this.deleteAccessCode(id).subscribe();
    }
  }

  deleteAccessCode(id: number): Observable<number> {
    return this.adminService.deleteAccessCode(id).pipe(
      tap(() => {
        this.toastService.crudSuccess('Document Code', 'delete');
        this.accessCodes = this.accessCodes.filter((code) => code.id !== id);
      })
    );
  }

  confirmDeletion(): void {
    if (!this.id || this.createMode) {
      return;
    }

    const confirmed = confirm('Are you sure you want to delete this group?');
    if (confirmed) {
      this.deleteGroup().subscribe();
    }
  }

  deleteGroup(): Observable<number> {
    return this.adminService.deleteGroup(this.id).pipe(
      tap(() => {
        this.toastService.crudSuccess('Group', 'delete');
        this.groupForm.markAsPristine();
        void this.router.navigate(['/admin/groups']);
      })
    );
  }

  setupBreadcrumbs(): void {
    this.path = [
      { label: 'Overview', routerLink: '/admin' },
      { label: 'Groups', routerLink: '../' },
      { label: this.createMode ? 'Create' : 'Edit' },
    ];
  }
}
