import { Component, Input, OnChanges } from '@angular/core';
import mixpanel from 'mixpanel-browser';
import { DocumentPageWithAttachment } from 'src/app/services/admin.service';
import { Video } from 'src/app/services/community-api.service';
import { Wilson } from '../../../def/Wilson';
import Document = Wilson.ViewDocument;

@Component({
  selector: 'app-attachments',
  templateUrl: './attachments.component.html',
  styleUrls: ['./attachments.component.scss'],
})
export class AttachmentsComponent implements OnChanges {
  @Input() attachments: DocumentPageWithAttachment;
  @Input() parentDocument: Document;
  attachmentsLoaded = false;
  attachmentCount: number;
  videoModal: VideoModal;

  constructor() {
    this.videoModal = {
      isOpen: false,
      video: undefined,
    };
  }

  ngOnChanges(): void {
    const ids =
      this.attachments?.resourceIds === ''
        ? new Set()
        : new Set(this.attachments?.resourceIds.split(','));
    this.attachmentCount = this.attachments ? ids.size : 0;
    this.attachmentsLoaded = !!this.attachmentCount;
  }

  openVideoModal(video: Video): void {
    this.videoModal = {
      isOpen: true,
      video,
    };
    mixpanel.track('Attachment Viewed', {
      'Document Id': this.parentDocument.id,
      'Document Title': this.parentDocument.title,
      'Attachment Title': video.name,
      'Attachment URL': video.url,
    });
  }
}

export interface VideoModal {
  isOpen: boolean;
  video: Video;
}
