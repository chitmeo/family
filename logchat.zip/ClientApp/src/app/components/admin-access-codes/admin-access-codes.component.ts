import { Component, OnInit } from '@angular/core';
import { TitleService } from '@wilson/wilsonng';
import { LazyLoadEvent, MenuItem, SelectItem } from 'primeng/api';
import { Observable } from 'rxjs';
import { debounceTime, mergeMap, tap } from 'rxjs/operators';
import { AdminService } from 'src/app/services/admin.service';
import { AdminBaseComponent } from '../admin-base/admin-base.component';
import { Wilson } from '../../../def/Wilson';
import DirectoryResponse = Wilson.DirectoryResponse;
import AccessCode = Wilson.AccessCode;

@Component({
  selector: 'app-admin-access-codes',
  templateUrl: './admin-access-codes.component.html',
  styleUrls: [],
})
export class AdminAccessCodesComponent
  extends AdminBaseComponent
  implements OnInit
{
  accessCodes: AccessCode[];
  path: MenuItem[];
  statuses: SelectItem[];
  totalRecords: number;
  pagesize = 25;
  dialogVisible = false;
  activeCode: AccessCode;
  constructor(
    private adminService: AdminService,
    private titleService: TitleService
  ) {
    super();
  }

  ngOnInit(): void {
    this.initialize();
    this.titleService.setPageName('Document Codes');
  }

  initialize(): void {
    this.setupStatuses();
    this.setupBreadcrumbs();
    this.setupSearch();
    this.setupSearchHandler().subscribe();
  }

  getAccessCodes(): Observable<DirectoryResponse<AccessCode>> {
    return this.adminService.getAccessCodeDirectory(this.search).pipe(
      tap((response: DirectoryResponse<AccessCode>) => {
        this.accessCodes = response.data;
        this.totalRecords = response.total;
      })
    );
  }

  showDialog(codeId: number): void {
    this.adminService
      .getAccessCode(codeId)
      .pipe(
        tap((code) => {
          this.activeCode = code;
          this.dialogVisible = true;
        })
      )
      .subscribe();
  }

  hideDialog(): void {
    this.dialogVisible = false;
  }

  setupStatuses(): void {
    this.statuses = [
      { label: 'Active', value: true },
      { label: 'Inactive', value: false },
    ];
  }

  setupSearch(): void {
    this.search = {
      filters: [],
      dateRanges: [],
      skip: 0,
      take: this.pagesize,
      sort: null,
    };
  }
  setupSearchHandler(): Observable<DirectoryResponse<AccessCode>> {
    return this.searchSubject.pipe(
      debounceTime(500),
      mergeMap(() => this.getAccessCodes())
    );
  }

  setupBreadcrumbs(): void {
    this.path = [
      { label: 'Overview', routerLink: '/admin' },
      { label: 'Document Codes' },
    ];
  }

  lazyLoadAccessCodes(event: LazyLoadEvent): void {
    // event.first = First row offset
    // event.rows = Number of rows per page
    // event.sortField = Field name to sort with
    // event.sortOrder = Sort order as number, 1 for asc and -1 for dec
    // filters: FilterMetadata object having field as key and filter value, filter matchMode as value

    this.search.skip = event.first;
    this.search.take = event.rows;
    this.search.sort = {
      column: event.sortField,
      direction: event.sortOrder,
    };
    this.getAccessCodes().subscribe();
  }
}
