import { Component, Input } from '@angular/core';
import { MessageService, SelectItem } from 'primeng/api';
import { Subscription } from 'rxjs';
import { tap } from 'rxjs/operators';
import { AttachmentsService } from 'src/app/services/attachments.service';
import {
  CommunityApiService,
  Video,
} from 'src/app/services/community-api.service';
import { AutoCompleteCompleteEvent } from 'primeng/autocomplete';

@Component({
  selector: 'app-admin-attachments-overlay',
  templateUrl: './admin-attachments-overlay.component.html',
  styleUrls: ['./admin-attachments-overlay.component.scss'],
})
export class AdminAttachmentsOverlayComponent {
  @Input()
  selectedPage: number;

  levels: SelectItem[];
  selectedLevel: string;
  selectedVideo: Video;
  videos: Video[];
  subscription: Subscription;

  constructor(
    private communityService: CommunityApiService,
    private messageService: MessageService,
    private attachmentService: AttachmentsService
  ) {
    this.levels = [
      {
        label: 'K',
        value: 'k',
      },
      {
        label: '1',
        value: '1',
      },
      {
        label: '2',
        value: '2',
      },
      {
        label: '3',
        value: '3',
      },
    ];
  }

  /**
   * Adds video to selected page's videos array, if page doesnt exist it addes the page to the array as well
   * @param pageNumber page to add video attachment to
   * @param selectedVideo video object to add
   */
  addAttachment(pageNumber: number, selectedVideo: Video): void {
    if (!pageNumber || !selectedVideo) {
      this.messageService.add({
        severity: 'error',
        summary: `An error occured`,
        detail: `Please select a page and video.`,
      });

      return;
    }

    this.attachmentService.addAttachment(pageNumber, selectedVideo);

    // Clear input fields
    this.selectedVideo = undefined;
  }

  /**
   * Method to run when the as the user is typing in the videos input in order to suggest options
   * @param event
   */
  suggestVideos(event: AutoCompleteCompleteEvent, level: string): void {
    this.communityService
      .searchVideos(event.query, level)
      .pipe(tap((result: Video[]) => (this.videos = result)))
      .subscribe();
  }
}
