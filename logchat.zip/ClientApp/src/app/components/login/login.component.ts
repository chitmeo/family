/* eslint-disable @typescript-eslint/naming-convention */
import { Component, OnDestroy, OnInit } from '@angular/core';
import {
  UntypedFormGroup,
  Validators,
  UntypedFormBuilder,
} from '@angular/forms';
import { trigger, transition, style, animate } from '@angular/animations';
import { DocumentService } from 'src/app/services/document.service';
import { ActivatedRoute, Router } from '@angular/router';
import { catchError, switchMap, tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import {
  Session,
  SessionService,
  User,
} from 'src/app/services/session.service';
import {
  TitleService,
  GoogleAnalyticsService,
  AuthenticationService,
  RedirectService,
} from '@wilson/wilsonng';
import { PageVisibilityService } from 'src/app/services/page-visibility.service';
import mixpanel from 'mixpanel-browser';
import { Wilson } from '../../../def/Wilson';
import ViewGroup = Wilson.ViewGroup;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  animations: [
    trigger('fadeIn', [
      transition(':enter', [
        style({ opacity: 0 }),
        animate('1s ease-out', style({ opacity: 1 })),
      ]),
    ]),
  ],
})
export class LoginComponent implements OnInit, OnDestroy {
  accessCodeLoginForm: UntypedFormGroup;
  userInfoLoginForm: UntypedFormGroup;
  accessCode: string;
  accessCodeLoginActive = true;
  accessCodeValidated = false;
  requireUserInfo = true;
  accessCodeErrorText: string;
  userNameErrorText: string;
  userEmailErrorText: string;
  userSchoolErrorText: string;
  termsErrorText: string;
  currentYear = new Date().getFullYear();
  nextRequest = 'none';
  submitRequest = 'none';
  spinnerIcon = 'pi pi-spin pi-spinner';
  group: ViewGroup;
  isIframe = false;
  loginParams: LoginParams;

  constructor(
    private fb: UntypedFormBuilder,
    private documentService: DocumentService,
    private route: ActivatedRoute,
    private router: Router,
    private sessionService: SessionService,
    private googleAnalyticsService: GoogleAnalyticsService,
    private titleService: TitleService,
    private pageVisibilityService: PageVisibilityService,
    private authenticationService: AuthenticationService,
    private redirectService: RedirectService
  ) {}

  ngOnInit(): void {
    this.titleService.setPageName('Log In');
    if (this.route.snapshot.queryParams['iframe'] === 'true') {
      this.isIframe = true;
    }

    this.buildLoginParamsMap();
    this.initializeForms();
    this.attemptAutoLogin();

    this.documentService.allowAnnotations =
      this.route.snapshot.queryParams['ano'] === '1';
    this.documentService.showTableOfContents =
      this.route.snapshot.queryParams['toc'] === '1';
  }

  ngOnDestroy(): void {
    this.pageVisibilityService.show();
  }

  attemptAutoLogin(): void {
    if (this.loginParams.accessCode?.length) {
      this.accessCodeLoginForm.controls['accessCode'].setValue(
        this.loginParams.accessCode
      );
      this.handleSubmitAccessCode();
    } else {
      this.pageVisibilityService.show();
    }

    if (this.loginParams.userName?.length) {
      this.userInfoLoginForm.controls['userName'].setValue(
        this.loginParams.userName
      );
    }
    if (this.loginParams.userEmail?.length) {
      this.userInfoLoginForm.controls['userEmail'].setValue(
        this.loginParams.userEmail
      );
    }
    if (this.loginParams.userSchool?.length) {
      this.userInfoLoginForm.controls['userSchool'].setValue(
        this.loginParams.userSchool
      );
    }
  }

  initializeForms(): void {
    this.accessCodeLoginForm = this.fb.group({
      accessCode: ['', Validators.required],
    });

    this.userInfoLoginForm = this.fb.group({
      userName: ['', Validators.required],
      userEmail: ['', [Validators.required, Validators.email]],
      userSchool: ['', Validators.required],
      terms: [false, Validators.requiredTrue],
    });
    this.pageVisibilityService.hide();
  }

  handleSubmitAccessCode(): void {
    this.nextRequest = this.spinnerIcon;

    // check that form input is valid
    if (this.accessCodeLoginForm.invalid) {
      this.accessCodeErrorText = 'This field is required.';
      this.nextRequest = 'none';
      this.pageVisibilityService.show();
      return;
    }
    // get doc id from input as code text
    this.accessCode = this.accessCodeLoginForm.controls['accessCode'].value;

    // chat with document service
    this.documentService
      .getDocumentGroupSecurityMetaByShareCode(this.accessCode)
      .pipe(
        switchMap((group: ViewGroup) => {
          if (group.requiresUniversalLogin) {
            return this.loginUser();
          } else if (group.allowAnonymousEntry || this.userInfoAlreadySaved()) {
            // if the group allows anonymous access or the user's session info is already saved... go right to directory
            this.requireUserInfo = false;
            this.accessCodeValidated = true;
            return this.toDirectory(this.accessCode);
          } else {
            // if the group does NOT allow anonymous access and we don't have the user's information yet... get the user's information
            this.accessCodeLoginActive = false;
            this.requireUserInfo = true;
            this.accessCodeValidated = true;
            this.pageVisibilityService.show();
            return of(null);
          }
        }),
        catchError((err) => {
          if (this.isIframe) {
            void this.router.navigate(['forbidden']);
          }
          console.error(err);
          this.accessCodeErrorText = `Sorry, the document code you have entered is either not currently active or has expired. Please
          <a href="https://www.wilsonlanguage.com/contact-us/" target="_blank">contact Wilson Customer Support</a> if you require assistance.`;
          this.nextRequest = 'none';
          this.pageVisibilityService.show();
          return of(null);
        })
      )
      .subscribe();
  }

  private loginUser(): Observable<ViewGroup> {
    if (!this.authenticationService.isLoggedIn()) {
      let query: string;
      if (this.accessCode) {
        query = `accessCode=${this.accessCode}`;
      }
      this.redirectService.setRedirectCookie(query);
      this.authenticationService.login();
      return of(null);
    } else {
      return this.toDirectory(this.accessCode);
    }
  }

  clearErrors(): void {
    this.userNameErrorText = null;
    this.userEmailErrorText = null;
    this.userSchoolErrorText = null;
    this.termsErrorText = null;
  }

  handleSubmitUserInfo(): void {
    this.submitRequest = this.spinnerIcon;
    this.clearErrors();
    // check that form input is valid
    if (this.userInfoLoginForm.invalid) {
      if (this.userInfoLoginForm.controls['userName'].invalid) {
        this.userNameErrorText = 'This field is required.';
      }
      if (this.userInfoLoginForm.controls['userEmail'].invalid) {
        this.userEmailErrorText = 'Please enter a valid email address.';
      }
      if (this.userInfoLoginForm.controls['userSchool'].invalid) {
        this.userSchoolErrorText = 'This field is required.';
      }
      if (this.userInfoLoginForm.controls['terms'].invalid) {
        this.termsErrorText = 'You must accept the terms to continue.';
      }
      this.submitRequest = 'none';
      this.pageVisibilityService.show();
      return;
    }
    // bring user to document directory
    this.toDirectory(this.accessCode).subscribe();
  }

  toDirectory(accessCode: string): Observable<ViewGroup> {
    return this.documentService
      .getDocumentGroupByShareCode(
        accessCode,
        this.authenticationService.currentUser?.wilsonId
      )
      .pipe(
        tap((group: ViewGroup) => {
          if (!group) {
            this.accessCodeErrorText =
              'The user you are logged in as does not have access to use this code.';
            this.nextRequest = 'none';
            this.pageVisibilityService.show();
            return;
          }
          this.group = group;
          this.fillSessionInformation(this.group.allowAnonymousEntry);
          this.registerUserWithGoogleAnalytics();
          this.registerUserWithMixPanel();
          mixpanel.track('Login', {
            'Access Code': accessCode,
          });
          this.findFinalDestination();
        })
      );
  }

  findFinalDestination(): void {
    const docId = this.loginParams['documentId'] || null;
    const docPage = this.loginParams['documentPage'] || null;
    const docExists = this.group.documents?.find((doc) => doc.id === +docId);

    const queryParams = {};
    if (docPage) {
      queryParams['page'] = docPage;
    }

    const isXSite = this.route.snapshot.queryParams['xSite'] === '1';

    if (isXSite) {
      queryParams['xSite'] = this.route.snapshot.queryParams['xSite'];
      queryParams['return'] = this.route.snapshot.queryParams['return'];
      queryParams['programId'] = this.route.snapshot.queryParams['programId'];
      queryParams['title'] = this.route.snapshot.queryParams['title'];
      queryParams['subtitle'] = this.route.snapshot.queryParams['subtitle'];
      queryParams['reg'] = this.route.snapshot.queryParams['reg'];
    }

    if (docExists) {
      void this.router.navigate([`/viewer/document/${docId}`], {
        queryParams,
      });
    } else {
      let path = '';

      if (this.isIframe) {
        path = '/iframe';
      } else if (isXSite) {
        path = '/xsite';
      } else {
        path = '/viewer';
      }

      path +=
        this.group?.documents?.length === 1
          ? `/document/${this.group.documents[0].id}`
          : '';

      void this.router.navigate([path], { queryParams });
    }
  }

  fillSessionInformation(allowAnonymousEntry = false): void {
    // Always set new document code in session
    const session = {
      accessCode: this.accessCode,
    } as Session;

    // Only save info for "user" object if allowAnonymousEntry is true. Otherwise, just leave the "user" undefined
    if (!allowAnonymousEntry) {
      // If user info already exists in session, use that. Otherwise, grab user info from form
      const existingUserInfo =
        this.sessionService.getSessionInformation()?.user;
      session.user =
        existingUserInfo ||
        ({
          id: this.authenticationService.currentUser?.wilsonId,
          name: this.userInfoLoginForm.controls['userName'].value,
          email: this.userInfoLoginForm.controls['userEmail'].value,
          school: this.userInfoLoginForm.controls['userSchool'].value,
        } as User);
    }

    this.sessionService.setSessionInformation(session);
  }

  userInfoAlreadySaved(): boolean {
    const session = this.sessionService.getSessionInformation();
    return !!session?.user;
  }

  registerUserWithGoogleAnalytics(): void {
    const id = this.authenticationService.currentUser?.wilsonId;
    if (id) {
      this.googleAnalyticsService.setUserId(id);
    }
  }

  /* istanbul ignore next */
  registerUserWithMixPanel(): void {
    const user = this.sessionService.getSessionInformation()?.user;

    if (user) {
      mixpanel.identify(user.email);
      mixpanel.people.set({
        $name: user.name,
        $email: user.email,
        $distinct_id: user.email,
        'Wilson ID': user.id,
      });

      // do not track test users
      if (user.email == 'uitester@wilsonlanguage.com') {
        mixpanel.opt_out_tracking();
      }

      mixpanel.track('Arrived On Site');
    }
  }

  private buildLoginParamsMap(): void {
    const params = this.route.snapshot.queryParams;
    this.loginParams = {} as LoginParams;
    this.loginParams.accessCode = params['accessCode'] || null;
    this.loginParams.userName = params['userName'] || null;
    this.loginParams.userEmail = params['userEmail'] || null;
    this.loginParams.userSchool = params['userSchool'] || null;
    this.loginParams.documentId = params['documentId'] || null;
    this.loginParams.documentPage = params['documentPage'] || null;
  }
}

interface LoginParams {
  accessCode: string;
  userName: string;
  userEmail: string;
  userSchool: string;
  documentId: string;
  documentPage: string;
}
