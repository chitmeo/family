import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ElementRef,
  NgZone,
  OnInit,
  Renderer2,
  ViewChild,
} from '@angular/core';
import { MenuItem } from 'primeng/api';
import { ActivatedRoute, Params } from '@angular/router';
import {
  DocumentService,
  AnnotationsData,
} from '../../services/document.service';
import { map, switchMap, tap } from 'rxjs/operators';
import { from, Observable, of } from 'rxjs';
import {
  AuthenticationService,
  SpinnerService,
  TitleService,
} from '@wilson/wilsonng';
import WebViewer, { Core, UI, WebViewerInstance } from '@pdftron/webviewer';
import { SessionService } from 'src/app/services/session.service';
import { saveAs } from 'file-saver';
import { DocumentPageWithAttachment } from 'src/app/services/admin.service';
import { CommunityApiService } from 'src/app/services/community-api.service';
import { InitialLoadService } from 'src/app/services/initial-load.service';
import mixpanel from 'mixpanel-browser';
import { Wilson } from '../../../def/Wilson';
import Document = Wilson.ViewDocument;
import ViewGroup = Wilson.ViewGroup;

@Component({
  selector: 'app-view-document',
  templateUrl: './view-document.component.html',
  styleUrls: ['./view-document.component.scss'],
})
export class ViewDocumentComponent implements AfterViewInit, OnInit {
  @ViewChild('viewer') viewerRef: ElementRef;
  wvInstance: WebViewerInstance;

  path: MenuItem[];
  documentGroup: ViewGroup;
  groupName: string;
  listOpen = true;
  sidebarVisible = false;
  directoryURL: string;
  documentUrl: string;
  screenHeight: number;
  currentDocumentId: number;
  currentDocumentName: string;
  token: string;
  attachmentSidebarIsActive = false;
  attachmentSidebarClosedByUser = false;
  documentSidebarIsActive: boolean;
  documentViewer: Core.DocumentViewer;
  PDFNet: typeof Core.PDFNet;

  attachments: DocumentPageWithAttachment[];
  currentPage: DocumentPageWithAttachment;
  currentDocumentPage: Observable<DocumentPageWithAttachment>;
  currentAttachmentCount: string;
  attachmentBadge: HTMLElement;
  pageNumber: number;
  pageOffset: number;
  pageCount: number;
  document: Document;
  showModal: boolean;
  currentDocumentIntroVideo: string;
  queryParams = {} as Params;
  isXSite = false;

  constructor(
    private documentService: DocumentService,
    private authenticationService: AuthenticationService,
    private route: ActivatedRoute,
    private titleService: TitleService,
    private spinnerService: SpinnerService,
    private sessionService: SessionService,
    private cdref: ChangeDetectorRef,
    private communityService: CommunityApiService,
    private ngZone: NgZone,
    private initialLoadService: InitialLoadService,
    private elRef: ElementRef,
    private renderer: Renderer2
  ) {}

  ngOnInit(): void {
    this.currentDocumentId = Number(this.route.snapshot.params.documentId);
    this.isXSite = this.route.snapshot.queryParams['xSite'] === '1';
  }
  async ngAfterViewInit(): Promise<void> {
    await this.webviewerAfterInit();
    this.initialize().subscribe();
    this.removeFocusFromLastBreadcrumb();
    this.initializeBadge();
  }

  async webviewerAfterInit(): Promise<void> {
    this.wvInstance = await WebViewer(
      {
        path: 'assets/lib/',
        licenseKey:
          this.initialLoadService.initialLoad.tokens['PdfTronWebViewerKey'],
        enableAzureWorkaround: true,
        accessibleMode: true,
        // authors are always "Guest", just rename them to "You" since people can only create and read their own
        annotationUser: 'You',
        fullAPI: true,
      },
      this.viewerRef.nativeElement
    );
    this.wvInstance.UI.setToolbarGroup('toolbarGroup-View');
    this.wvInstance.UI.disableElements(['toolbarGroup-Forms']);
    this.wvInstance.UI.disableElements(['toolbarGroup-Insert']);

    this.wvInstance.UI.setActiveLeftPanel('outlinesPanel');
    if (this.documentService.showTableOfContents) {
      this.wvInstance.UI.openElements(['leftPanel']);
    }

    this.addAnnotationAndFillableSettings();
    this.insertCustomButtons();

    this.wvInstance.Core.documentViewer.addEventListener(
      'documentLoaded',
      () => {
        this.onPageNumberUpdated(null);
        this.pageCount = this.wvInstance.Core.documentViewer
          .getDocument()
          .getPageCount();
      }
    );

    this.wvInstance.Core.documentViewer.addEventListener(
      'pageNumberUpdated',
      (pageNumber) => this.onPageNumberUpdated(pageNumber)
    );
  }

  async onPageNumberUpdated(pageNumber: number | null): Promise<void> {
    this.showOrHideButtons();

    if (!pageNumber) {
      this.setupNewPDfViewerDocument();
      pageNumber = this.wvInstance.Core.documentViewer.getCurrentPage();
    }

    this.pageNumber =
      pageNumber - this.pageOffset < 1
        ? undefined
        : pageNumber - this.pageOffset;

    this.ngZone.run(() => {
      this.currentDocumentPage = this.getPageWithAttachments(pageNumber);
    });
  }

  getPageWithAttachments(
    pageNumber: number
  ): Observable<DocumentPageWithAttachment> {
    const currentPage = this.attachments.find(
      (page) => page.pageNumber === pageNumber
    );

    return this.getVideoData(currentPage).pipe(
      tap((cPage) => {
        const count = cPage?.videos.length ?? 0;
        this.updateBadge(count);
        if (!this.attachmentSidebarClosedByUser && cPage?.videos.length) {
          this.attachmentSidebarIsActive = true;
        }
      })
    );
  }

  setupNewPDfViewerDocument(): void {
    // set zoom fit
    this.wvInstance.UI.setFitMode(this.wvInstance.UI.FitMode.FitWidth);
    // set initial page
    const pageNumber = this.route.snapshot?.queryParams['page'];
    if (pageNumber) {
      this.wvInstance.Core.documentViewer.setCurrentPage(+pageNumber, false);
    }
  }

  addAnnotationAndFillableSettings(): void {
    const { documentViewer, annotationManager } = this.wvInstance.Core;

    documentViewer.setDocumentXFDFRetriever(async () => {
      return this.documentService
        .getDocumentAnnotations(
          this.getCurrentDocument().id,
          this.sessionService.getSessionInformation().user?.id
        )
        .pipe(map((item: AnnotationsData) => item.server || item.local))
        .toPromise();
    });

    // annotation saving
    annotationManager.addEventListener(
      'annotationChanged',
      (_annotations, _action, { imported }) => {
        if (imported) {
          return;
        }
        this.saveAnnotations().subscribe();
      }
    );

    // fillable form saving
    annotationManager.addEventListener('fieldChanged', () =>
      this.saveAnnotations().subscribe()
    );

    this.documentService.allowAnnotations
      ? annotationManager.disableReadOnlyMode()
      : annotationManager.enableReadOnlyMode();
  }

  initialize(): Observable<string> {
    this.spinnerService.show();
    this.getGroupDocuments();
    this.screenHeight = window.innerHeight;
    if (this.documentGroup.documents.length <= 1) {
      this.listOpen = false;
    }
    return this.sidebarSubscription();
  }

  getGroupDocuments(): void {
    this.documentGroup = this.documentService.getCurrentDocumentGroup();
    this.groupName = this.documentGroup.title;
  }

  getCurrentDocument(): Document {
    if (this.document?.id !== this.currentDocumentId) {
      const documentGroup = this.documentService.getCurrentDocumentGroup();
      this.document = documentGroup.documents.find(
        (doc) => doc.id == this.currentDocumentId
      );
    }
    return this.document;
  }

  insertCustomButtons(): void {
    this.wvInstance.UI.setHeaderItems((header) => {
      const headerRef = header.get('menuButton');
      const dg = this.documentService.getCurrentDocumentGroup();
      if (dg?.documents?.length > 1) {
        this.insertDocumentsBtn(headerRef);
      }
      this.insertPrintBtn(headerRef);
      this.insertAttachmentsBtn(headerRef);
      this.insertDownloadBtn(headerRef);
      this.insertFullscreenBtn(headerRef);
    });
  }

  insertPrintBtn(headerRef: UI.Header): void {
    this.wvInstance.UI.disableElements(['printButton']);
    headerRef.insertBefore({
      type: 'actionButton',
      img: 'icon-header-print-line',
      title: 'Print',
      onClick: () => {
        this.wvInstance.UI.print();
        mixpanel.track('Document Printed', {
          'Document Id': this.currentDocumentId,
          'Document Title': this.currentDocumentName,
        });
      },
      dataElement: 'customPrintButton',
    });
  }

  insertFullscreenBtn(headerRef: UI.Header): void {
    headerRef.insertBefore({
      type: 'actionButton',
      img: 'icon-header-full-screen',
      title: 'Toggle Fullscreen',
      dataElement: 'FullscreenButton',
      onClick: () => {
        this.wvInstance.UI.toggleFullScreen();
      },
    });
    //ignoring the native fullscreen button
    this.wvInstance.UI.disableElements(['fullscreenButton']);
  }

  insertDownloadBtn(headerRef: UI.Header): void {
    this.wvInstance.UI.disableElements(['downloadButton']);
    headerRef.insertBefore({
      type: 'actionButton',
      img: 'icon-download',
      onClick: () => {
        this.documentService
          .getDocumentForDownload(this.currentDocumentId)
          .subscribe((downloadUrl) => {
            saveAs(downloadUrl, `${this.currentDocumentName}.pdf`);
            mixpanel.track('Document Downloaded', {
              'Document Id': this.currentDocumentId,
              'Document Title': this.currentDocumentName,
            });
          });
      },
      dataElement: 'customDownloadButton',
    });
  }

  insertAttachmentsBtn(headerRef: UI.Header): void {
    headerRef.insertAfter({
      type: 'statefulButton',
      hidden: ['mobile'],
      initialState: 'active',
      dataElement: 'attachmentButton',
      states: {
        active: {
          title: `Hide Attachments`,
          img: 'ic_fileattachment_24px',
          onClick: (update) => {
            update('inactive');
            this.toggleAttachmentSidebar();
            this.cdref.detectChanges();
          },
        },
        inactive: {
          title: 'Show Attachments',
          img: 'ic_fileattachment_24px',
          onClick: (update) => {
            update('active');
            this.toggleAttachmentSidebar();
            this.cdref.detectChanges();
          },
        },
      },
    });
  }

  insertDocumentsBtn(headerRef: UI.Header): void {
    headerRef.insertAfter({
      type: 'statefulButton',
      hidden: ['mobile'],
      initialState: 'active',
      dataElement: 'documentsSidebarButton',
      states: {
        active: {
          title: 'Hide Documents',
          img: 'ic_menu_black_24px',
          onClick: (update) => {
            update('inactive');
            this.toggleDocumentSidebar();
            this.cdref.detectChanges();
          },
        },
        inactive: {
          title: 'Show Documents',
          img: 'ic_menu_black_24px',
          onClick: (update) => {
            update('active');
            this.toggleDocumentSidebar();
            this.cdref.detectChanges();
          },
        },
      },
    });
  }
  setRenderingLink(): Observable<string> {
    const doc = this.getCurrentDocument();
    mixpanel.track('Document Viewed', {
      'Document Id': doc.id,
      'Document Title': doc.title,
    });

    return this.documentService
      .getDocumentRenderingLink(doc.filePath)
      .pipe(
        tap((documentLink: string) =>
          this.wvInstance.UI.loadDocument(documentLink)
        )
      );
  }

  saveAnnotations(): Observable<void> {
    const annotationsObs = from(
      this.wvInstance.Core.annotationManager.exportAnnotations({
        widgets: false,
        links: false,
      })
    );

    const doc = this.getCurrentDocument();
    return annotationsObs.pipe(
      switchMap((xfdfData: string) =>
        this.documentService.saveDocumentAnnotations(
          xfdfData,
          doc.id,
          this.sessionService.getSessionInformation().user?.id
        )
      )
    );
  }

  getDocumentName(): void {
    const currentDocument = this.getCurrentDocument();
    this.attachments = currentDocument.attachments;
    this.currentDocumentName = currentDocument.title;
    this.pageOffset = currentDocument.pageOffset;
    this.titleService.setPageName(this.currentDocumentName);
    this.setupBreadcrumbs();

    this.documentSidebarIsActive = this.documentGroup.documents.length > 1;
  }

  sidebarSubscription(): Observable<string> {
    return this.route.params.pipe(
      tap((params) => {
        this.currentDocumentId = Number(params['documentId']);
        this.getDocumentName();
        this.spinnerService.hide();
      }),
      switchMap(() => this.setRenderingLink())
    );
  }

  toggleMenu(): void {
    this.listOpen = !this.listOpen;
    this.sidebarVisible = !this.sidebarVisible;
  }

  toggleDocumentSidebar(): void {
    this.documentSidebarIsActive = !this.documentSidebarIsActive;
  }

  toggleAttachmentSidebar(): void {
    this.attachmentSidebarClosedByUser = true;
    this.attachmentSidebarIsActive = !this.attachmentSidebarIsActive;
  }

  setupBreadcrumbs(): void {
    if (this.documentGroup.documents.length > 1) {
      if (this.isXSite) {
        this.getXSiteParams();
        this.path = [
          { label: 'Home', url: this.queryParams['return'] },
          {
            label: this.groupName,
            routerLink: '/xsite/directory',
            queryParams: this.queryParams,
          },
          { label: this.currentDocumentName },
        ];
      } else {
        this.path = [
          { label: this.groupName, routerLink: '/viewer' },
          { label: this.currentDocumentName },
        ];
      }
    } else {
      this.path = [{ label: this.currentDocumentName }];
    }
  }

  getXSiteParams(): void {
    this.queryParams['xSite'] = this.route.snapshot.queryParams['xSite'];
    this.queryParams['return'] = this.route.snapshot.queryParams['return'];
    this.queryParams['programId'] =
      this.route.snapshot.queryParams['programId'];
    this.queryParams['title'] = this.route.snapshot.queryParams['title'];
    this.queryParams['subtitle'] = this.route.snapshot.queryParams['subtitle'];
    this.queryParams['reg'] = this.route.snapshot.queryParams['reg'];
  }

  removeFocusFromLastBreadcrumb(): void {
    const bc = document.querySelector(
      '.p-breadcrumb ul li:last-child .p-menuitem-link'
    );
    if (!!bc) {
      bc.setAttribute('tabindex', '-1');
    }
  }

  getVideoData(
    currentPage: DocumentPageWithAttachment
  ): Observable<DocumentPageWithAttachment> {
    if (!currentPage) return of(undefined);
    if (!!currentPage?.videos) return of(currentPage);

    const ids = currentPage.resourceIds.split(',');

    return this.communityService.getVideos(ids).pipe(
      switchMap((videos) => {
        const vidIds = videos.map((video) => video.id);
        currentPage.resourceIds = !vidIds.length ? '' : vidIds.toString();
        currentPage.videos = videos;
        this.currentAttachmentCount = videos.length.toString();
        return of(currentPage);
      })
    );
  }

  initializeBadge(): void {
    const iframe = <HTMLElement>(
      this.elRef.nativeElement.querySelector('iframe').contentWindow.document
    );
    const attachmentButton = iframe.querySelector(
      "[data-element='attachmentButton']"
    );

    this.attachmentBadge = <HTMLElement>this.renderer.createElement('span');
    this.attachmentBadge.setAttribute(
      'style',
      'position: absolute; background: #333;top: 0; right: 0; color: #fff; padding: 0.5rem; border-radius: 60%; height: 1rem; width: 1rem; font-size: 0.5rem; display: flex; justify-content: center; align-items: center;'
    );

    this.renderer.appendChild(attachmentButton, this.attachmentBadge);
  }

  updateBadge(count: number): void {
    const display = count ? 'flex' : 'none';
    this.renderer.setStyle(this.attachmentBadge, 'display', display);
    this.renderer.setProperty(this.attachmentBadge, 'innerText', `${count}`);
  }

  goToPage(pageNumber: number): void {
    const goToPage = pageNumber + this.pageOffset;
    this.wvInstance.Core.documentViewer.setCurrentPage(goToPage, true);
  }

  private showOrHideButtons(): void {
    // Dynamically show or hide certain buttons
    const print = 'customPrintButton';
    const download = 'customDownloadButton';
    const document = this.getCurrentDocument();
    const elemsToEnable = [];
    const elemsToDisable = [];

    // Print
    if (document.allowPrint) {
      this.wvInstance.UI.hotkeys.on(this.wvInstance.UI.hotkeys.Keys.CTRL_P);
      this.wvInstance.UI.hotkeys.on(this.wvInstance.UI.hotkeys.Keys.COMMAND_P);
      elemsToEnable.push(print);
    } else {
      this.wvInstance.UI.hotkeys.off(this.wvInstance.UI.hotkeys.Keys.CTRL_P);
      this.wvInstance.UI.hotkeys.off(this.wvInstance.UI.hotkeys.Keys.COMMAND_P);
      elemsToDisable.push(print);
    }

    // Download
    document.allowSave
      ? elemsToEnable.push(download)
      : elemsToDisable.push(download);

    if (document.watermark) {
      const userId = this.authenticationService.currentUser?.wilsonId ?? '';
      void this.wvInstance.Core.documentViewer.setWatermark({
        custom: (ctx, _, w, h) => {
          ctx.font = '9px sans-serif';
          ctx.textAlign = 'center';
          ctx.fillStyle = 'gray';
          ctx.globalAlpha = 0.35;
          ctx.fillText('Do not copy. ' + userId, w / 2, h - 15);
        },
      });
    }

    if (document.selectable) {
      this.wvInstance.Core.Tools.TextSelectTool.enableTextSelection();
    } else {
      this.wvInstance.Core.Tools.TextSelectTool.disableTextSelection();
    }

    this.wvInstance.UI.enableElements(elemsToEnable);
    this.wvInstance.UI.disableElements(elemsToDisable);
  }
}
