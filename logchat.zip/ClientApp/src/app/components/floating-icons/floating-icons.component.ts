import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-floating-icons',
  templateUrl: './floating-icons.component.html',
  styleUrls: ['./floating-icons.component.scss'],
})
export class FloatingIconsComponent {
  @Input() fullHeight = true;

  iconImage(): string {
    return this.fullHeight ? fullHeightImage : halfImage;
  }
}

export const fullHeightImage = 'assets/svg/floating-icons-full.svg';
export const halfImage = 'assets/svg/floating-icons-half.svg';
