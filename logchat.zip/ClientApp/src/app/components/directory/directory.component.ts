import { Component, OnInit } from '@angular/core';
import { SelectItem } from 'primeng/api';
import { DocumentService } from '../../services/document.service';
import { PaginatorState } from 'primeng/paginator';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { TitleService, MatchHighlightService } from '@wilson/wilsonng';
import { SessionService } from 'src/app/services/session.service';
import { Wilson } from '../../../def/Wilson';
import Document = Wilson.ViewDocument;
import ViewGroup = Wilson.ViewGroup;

@Component({
  selector: 'app-directory',
  templateUrl: './directory.component.html',
  styleUrls: ['./directory.component.scss'],
})
export class DirectoryComponent implements OnInit {
  documentGroup: ViewGroup;
  filteredDocumentsGrid: Document[];
  filteredDocumentsTable: Document[];
  filterBy = '';
  viewOptions: SelectItem[] = [
    { label: 'Grid', value: 'grid' },
    { label: 'List', value: 'list' },
  ];
  currentView: string;
  currentPage = 0;
  firstRecord = 0;
  pagesize = 20;
  queryParams = {} as Params;

  constructor(
    private documentService: DocumentService,
    private router: Router,
    private route: ActivatedRoute,
    private titleService: TitleService,
    private sessionService: SessionService,
    private matchHighlightService: MatchHighlightService
  ) {}

  saveFilters(): void {
    this.sessionService.saveFilters(
      JSON.stringify({
        filterBy: this.filterBy,
        currentView: this.currentView,
      })
    );
    this.getFilteredDocuments();
  }

  clearFilter(): void {
    this.filterBy = '';
    this.saveFilters();
    this.getFilteredDocuments();
  }

  ngOnInit(): void {
    this.initUI();
    this.getGroupDocuments();
    this.determineXSite();
  }

  getFilters(): string {
    return this.sessionService.getFilters();
  }

  parseImage(url = ''): string {
    const filter = '/stock/';
    const stockLocation = '../../../assets/img/';
    let outputURL = url;
    if (url.startsWith(filter)) {
      outputURL = url.replace(filter, stockLocation);
    }

    return outputURL;
  }

  getGroupDocuments(): void {
    this.documentGroup = this.documentService.getCurrentDocumentGroup();
    this.titleService.setPageName(this.documentGroup.title);
    this.getFilteredDocuments();
  }

  getFilteredDocuments(): void {
    const searchPhrase = this.filterBy.toLowerCase();
    const filtered = this.documentGroup.documents.filter(
      ({ title, description }) =>
        title.toLowerCase().includes(searchPhrase) ||
        description.toLowerCase().includes(searchPhrase)
    );

    this.filteredDocumentsTable = filtered;
    this.filteredDocumentsGrid = filtered.slice(
      this.currentPage * this.pagesize,
      (this.currentPage + 1) * this.pagesize
    );
  }

  determineXSite(): void {
    if (this.route.snapshot.queryParams['xSite'] === '1') {
      this.queryParams['xSite'] = this.route.snapshot.queryParams['xSite'];
      this.queryParams['return'] = this.route.snapshot.queryParams['return'];
      this.queryParams['programId'] =
        this.route.snapshot.queryParams['programId'];
      this.queryParams['title'] = this.route.snapshot.queryParams['title'];
      this.queryParams['subtitle'] =
        this.route.snapshot.queryParams['subtitle'];
      this.queryParams['reg'] = this.route.snapshot.queryParams['reg'];
    }
  }

  paginate(event: PaginatorState): void {
    this.currentPage = event.page || event.first / this.pagesize;
    this.firstRecord = this.currentPage * this.pagesize || 1;
    this.getFilteredDocuments();
  }

  initUI(): void {
    let filters: { currentView: string; filterBy: string };
    try {
      filters = JSON.parse(this.getFilters());
    } catch (error) {
      filters = null;
    }
    this.currentView = filters?.currentView || this.viewOptions[0].value;
    this.filterBy = filters?.filterBy || '';
  }

  toDocument(documentId: number): void {
    void this.router.navigate(['../', 'document', documentId], {
      relativeTo: this.route,
      queryParams: this.queryParams,
    });
  }
}
