import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { AdminOverviewService } from 'src/app/services/admin-overview.service';
import { TitleService } from '@wilson/wilsonng';
import { Wilson } from '../../../def/Wilson';
import OverviewStatistics = Wilson.OverviewStatistics;

@Component({
  selector: 'app-admin-overview',
  templateUrl: './admin-overview.component.html',
  styleUrls: ['./admin-overview.component.scss'],
})
export class AdminOverviewComponent implements OnInit {
  statistics: OverviewStatistics;

  constructor(
    private adminOverviewService: AdminOverviewService,
    private titleService: TitleService
  ) {}

  ngOnInit(): void {
    this.getOverviewData().subscribe();
    this.titleService.setPageName('Overview');
  }

  getOverviewData(refresh = false): Observable<OverviewStatistics> {
    return this.adminOverviewService
      .getOverviewStatistics(refresh)
      .pipe(
        tap((response: OverviewStatistics) => (this.statistics = response))
      );
  }

  refreshData(): void {
    this.getOverviewData(true).subscribe();
  }
}
