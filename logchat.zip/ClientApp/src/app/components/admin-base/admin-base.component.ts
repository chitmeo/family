import { Component } from '@angular/core';
import { Calendar } from 'primeng/calendar';
import { Subject } from 'rxjs';
import { Wilson } from '../../../def/Wilson';
import Search = Wilson.Search;

@Component({
  selector: 'app-admin-base',
  template: ``,
})
export class AdminBaseComponent {
  search: Search;
  searchSubject = new Subject();

  wildcardFilterColumn(column: string, value: string, wildcard = true): void {
    // remove any original version of the column from the search
    this.search.filters = this.search.filters.filter(
      (x) => x.column !== column
    );

    if (value && value.length) {
      // add new search in if value has content
      this.search.filters = [
        ...this.search.filters,
        {
          column,
          value,
          filterType: wildcard ? 4 : 1,
        },
      ];
    }
    this.searchSubject.next(this.search);
  }

  dateRangeFilterColumn(column: string, calendar: Calendar): void {
    const dates = calendar.value;
    // remove any original version of the column from the search
    this.search.dateRanges = this.search.dateRanges.filter(
      (x) => x.column !== column
    );

    if (dates && dates.length) {
      // add new search in if value has content
      this.search.dateRanges = [
        ...this.search.dateRanges,
        {
          column: column,
          start: dates[0],
          end: dates[1],
        },
      ];
    }
    this.searchSubject.next(this.search);
  }
}
