import { Component, OnInit } from '@angular/core';
import { TitleService } from '@wilson/wilsonng';

@Component({
  selector: 'app-coming-soon',
  templateUrl: './coming-soon.component.html',
  styleUrls: [],
})
export class ComingSoonComponent implements OnInit {
  currentYear = new Date().getFullYear();
  constructor(private titleService: TitleService) {}

  ngOnInit(): void {
    this.titleService.setPageName('Coming Soon');
  }
}
