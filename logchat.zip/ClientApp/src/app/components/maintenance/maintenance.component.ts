import { Component, OnInit } from '@angular/core';
import { TitleService } from '@wilson/wilsonng';

@Component({
  selector: 'app-maintenance',
  templateUrl: './maintenance.component.html',
  styleUrls: [],
})
export class MaintenanceComponent implements OnInit {
  currentYear = new Date().getFullYear();
  constructor(private titleService: TitleService) {}

  ngOnInit(): void {
    this.titleService.setPageName('Down for Maintenance');
  }
}
