import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { DocumentService } from 'src/app/services/document.service';
import { UtilityService, AuthenticationService } from '@wilson/wilsonng';
import { InitialLoadService } from 'src/app/services/initial-load.service';
import { SessionService, User } from 'src/app/services/session.service';
import pkg from '../../../../package.json';
import mixpanel from 'mixpanel-browser';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  @Input() isAdmin: boolean;
  menuOptions: MenuItem[];
  clientOptions: MenuItem[];
  adminOptions: MenuItem[];
  currentBuildNumber: string;
  currentVersionNumber: string;
  canClickTitle: boolean;

  constructor(
    private sessionService: SessionService,
    private documentService: DocumentService,
    private initialLoadService: InitialLoadService,
    private router: Router,
    private authenticationService: AuthenticationService,
    private utilityService: UtilityService
  ) {}

  ngOnInit(): void {
    this.initialize();
  }

  initialize(): void {
    this.fillMenuItems();
    this.initMenuOptions();
    this.getBuildData();
    this.setTitleClickable();
    this.router.events.subscribe(() => this.setTitleClickable());
  }

  initMenuOptions(): void {
    this.menuOptions = this.isAdmin ? this.adminOptions : this.clientOptions;
  }

  support(): void {
    window.open(
      'https://www.wilsonlanguage.com/contact-us/',
      '_blank',
      'noopener'
    );
  }

  feedback(): void {
    const user =
      this.sessionService.getSessionInformation()?.user || ({} as User);
    user.email = user.email || 'anonymous';
    user.school = user.school || 'anonymous';
    window.open(
      'https://wilsonlanguagetraining.wufoo.com/forms/wilson-digital-products-feedback/',
      '_blank',
      'noopener'
    );
  }

  setTitleClickable(): void {
    const dg = this.documentService.getCurrentDocumentGroup();
    this.canClickTitle =
      this.isAdmin ||
      (!this.router.url.endsWith('/directory') && dg?.documents.length > 1);
  }

  clickTitle(): void {
    if (this.isAdmin) {
      void this.router.navigate(['/admin']);
    } else {
      const dg = this.documentService.getCurrentDocumentGroup();
      if (dg?.documents.length > 1) {
        void this.router.navigate(['/viewer/directory']);
      }
    }
  }

  closeDocument(): void {
    this.sessionService.clearFilters();
    const session = this.sessionService.getSessionInformation();
    if (session) {
      mixpanel.track('Logout');
      session.accessCode = null;
      this.sessionService.setSessionInformation(session);
    }
    this.documentService.resetCurrentDocumentGroup();
  }

  redirectToLogin(): void {
    void this.router.navigate(['/login']);
  }

  fillMenuItems(): void {
    this.clientOptions = [
      {
        label: 'Open Document',
        icon: 'fas fa-folder-open',
        styleClass: 'i-openDocument',
        command: () => {
          this.closeDocument();
          this.redirectToLogin();
        },
      },
      {
        label: 'Support',
        icon: 'fas fa-info-circle',
        command: () => {
          this.support();
          mixpanel.track('Go to Support');
        },
      },
      {
        label: 'Feedback',
        icon: 'fas fa-comments',
        command: () => this.feedback(),
      },
      { separator: true },
      {
        label: 'Log Out',
        icon: 'fas fa-sign-out',
        styleClass: 'i-exit',
        command: () => {
          this.closeDocument();
          if (this.authenticationService.isLoggedIn()) {
            this.authenticationService.logout();
          } else {
            this.redirectToLogin();
          }
        },
      },
    ];

    this.adminOptions = [
      {
        label: 'Sign Out',
        icon: 'fas fa-sign-out',
        styleClass: 'i-exit',
        command: () => {
          this.authenticationService.logout();
        },
      },
    ];
  }

  runCommand(event: KeyboardEvent, toggleBtn: HTMLElement): void {
    this.utilityService.menuKeyboardEvent(event, toggleBtn);
  }

  getBuildData(): void {
    this.currentBuildNumber =
      this.initialLoadService.initialLoad.currentBuildNumber;
    this.currentVersionNumber = pkg.version;
  }
}
