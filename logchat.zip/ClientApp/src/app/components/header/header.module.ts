import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header.component';
import { UIModule } from '../../ui.module';

@NgModule({
  declarations: [HeaderComponent],
  imports: [CommonModule, UIModule],
  exports: [HeaderComponent],
})
export class HeaderModule {}
