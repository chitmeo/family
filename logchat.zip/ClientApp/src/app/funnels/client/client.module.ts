import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { UIModule } from 'src/app/ui.module';
import { DirectoryComponent } from 'src/app/components/directory/directory.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ClientComponent } from './client.component';
import { ClientRoutingModule } from './client-routing.module';
import { HeaderModule } from 'src/app/components/header/header.module';
import { FooterModule } from 'src/app/components/footer/footer.module';
import { ViewDocumentComponent } from 'src/app/components/view-document/view-document.component';
import { AttachmentsComponent } from 'src/app/components/attachments/attachments.component';
import { DocumentsComponent } from 'src/app/components/documents/documents.component';
import { MatchHighlightPipe } from '../../pipes/match-highlight.pipe';
import { AutoResizeTextareaDirective } from '../../directives/auto-resize-textarea.directive';
import { ChatBotComponent } from 'src/app/components/chat-bot/chat-bot.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    ClientRoutingModule,
    UIModule,
    HeaderModule,
    FooterModule,
  ],
  declarations: [
    AutoResizeTextareaDirective,
    // Components
    AttachmentsComponent,
    DocumentsComponent,
    ClientComponent,
    DirectoryComponent,
    ViewDocumentComponent,
    MatchHighlightPipe,
    ChatBotComponent,
  ],
  exports: [
    AutoResizeTextareaDirective
  ]
})
export class ClientModule {}
