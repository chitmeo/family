import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DirectoryComponent } from 'src/app/components/directory/directory.component';
import { ViewDocumentComponent } from 'src/app/components/view-document/view-document.component';
import { DocumentGroupResolver } from 'src/app/resolvers/document-group.resolver';
import { ClientComponent } from './client.component';

const routes: Routes = [
  {
    path: '',
    component: ClientComponent,
    children: [
      {
        path: '',
        redirectTo: 'directory',
        pathMatch: 'full',
      },
      {
        path: 'directory',
        component: DirectoryComponent,
        resolve: {
          documentGroup: DocumentGroupResolver,
        },
      },
      {
        path: 'document/:documentId',
        component: ViewDocumentComponent,
        resolve: {
          documentGroup: DocumentGroupResolver,
        },
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ClientRoutingModule {}
