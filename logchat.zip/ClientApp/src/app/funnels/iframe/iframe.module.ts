import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { UIModule } from 'src/app/ui.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { IframeRoutingModule } from './iframe-routing.module';
import { HeaderModule } from 'src/app/components/header/header.module';
import { FooterModule } from 'src/app/components/footer/footer.module';
import { IframeComponent } from './iframe.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    IframeRoutingModule,
    UIModule,
    HeaderModule,
    FooterModule,
  ],
  declarations: [
    // Components
    IframeComponent,
  ],
  providers: [],
})
export class IframeModule {}
