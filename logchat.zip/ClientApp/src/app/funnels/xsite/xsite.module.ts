import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { UIModule } from 'src/app/ui.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { XSiteRoutingModule } from './xsite-routing.module';
import { HeaderModule } from 'src/app/components/header/header.module';
import { FooterModule } from 'src/app/components/footer/footer.module';
import { XSiteComponent } from './xsite.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    XSiteRoutingModule,
    UIModule,
    HeaderModule,
    FooterModule,
  ],
  declarations: [
    // Components
    XSiteComponent,
  ],
  providers: [],
})
export class XSiteModule {}
