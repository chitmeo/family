import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-xsite',
  templateUrl: './xsite.component.html',
  styleUrls: ['./xsite.component.scss'],
})
export class XSiteComponent implements OnInit {
  returnUrl: string = null;
  theme: string = null;
  title: string = null;
  subtitle: string = null;
  hasReg = false;

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    // get all the query params
    this.returnUrl =
      this.route.snapshot.queryParams['return'] || 'https://wilsonacademy.com';
    this.theme = this.route.snapshot.queryParams['programId'] || 'wilson';
    this.title = this.route.snapshot.queryParams['title'] || 'wilsons';
    this.subtitle = this.route.snapshot.queryParams['subtitle'] || null;
    this.hasReg = this.route.snapshot.queryParams['reg'] === '1' || false;
  }
}
