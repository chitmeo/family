import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminAccessCodesCrudComponent } from 'src/app/components/admin-access-codes-crud/admin-access-codes-crud.component';
import { AdminAccessCodesComponent } from 'src/app/components/admin-access-codes/admin-access-codes.component';
import { AdminDocumentsCrudComponent } from 'src/app/components/admin-documents-crud/admin-documents-crud.component';
import { AdminDocumentsComponent } from 'src/app/components/admin-documents/admin-documents.component';
import { AdminGroupsCrudComponent } from 'src/app/components/admin-groups-crud/admin-groups-crud.component';
import { AdminGroupsComponent } from 'src/app/components/admin-groups/admin-groups.component';
import { AdminOverviewComponent } from 'src/app/components/admin-overview/admin-overview.component';
import { AuthGuard } from 'src/app/guards/auth.guard';
import { PendingChangesGuard } from 'src/app/guards/pending-changes.guard';
import { AdminComponent } from './admin.component';

const routes: Routes = [
  {
    path: '',
    component: AdminComponent,
    canActivateChild: [AuthGuard],
    children: [
      {
        path: '',
        component: AdminOverviewComponent,
      },
      {
        path: 'documents',
        children: [
          {
            path: '',
            component: AdminDocumentsComponent,
          },
          {
            path: ':id',
            component: AdminDocumentsCrudComponent,
            canDeactivate: [PendingChangesGuard],
          },
        ],
      },
      {
        path: 'groups',
        children: [
          {
            path: '',
            component: AdminGroupsComponent,
          },
          {
            path: ':id',
            component: AdminGroupsCrudComponent,
            canDeactivate: [PendingChangesGuard],
          },
        ],
      },
      {
        path: 'access-codes',
        children: [
          {
            path: '',
            component: AdminAccessCodesComponent,
          },
          {
            path: ':id',
            component: AdminAccessCodesCrudComponent,
            canDeactivate: [PendingChangesGuard],
          },
        ],
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdminRoutingModule {}
