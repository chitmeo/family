import { Component, OnInit } from '@angular/core';
import {
  RedirectService,
  SpinnerService,
  TitleService,
} from '@wilson/wilsonng';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss'],
})
export class AdminComponent implements OnInit {
  constructor(
    private titleService: TitleService,
    private redirectService: RedirectService,
    private spinnerService: SpinnerService
  ) {}

  ngOnInit(): void {
    this.titleService.setQualifier('Admin');
    this.redirectService.clearRedirectCookie();
    // we don't use the auto-spinner on this funnel
    this.spinnerService.deactivateInterceptor();
  }

  onActivate(): void {
    // scroll to top every time the route changes
    window.scroll(0, 0);
  }
}
