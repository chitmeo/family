import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { UIModule } from 'src/app/ui.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AdminRoutingModule } from './admin-routing.module';
import { HeaderModule } from 'src/app/components/header/header.module';
import { FooterModule } from 'src/app/components/footer/footer.module';
import { AdminComponent } from './admin.component';
import { AdminOverviewComponent } from 'src/app/components/admin-overview/admin-overview.component';
import { AdminDocumentsComponent } from 'src/app/components/admin-documents/admin-documents.component';
import { AdminDocumentsCrudComponent } from 'src/app/components/admin-documents-crud/admin-documents-crud.component';
import { AdminGroupsComponent } from 'src/app/components/admin-groups/admin-groups.component';
import { AdminAccessCodesComponent } from 'src/app/components/admin-access-codes/admin-access-codes.component';
import { AdminAccessCodesCrudComponent } from 'src/app/components/admin-access-codes-crud/admin-access-codes-crud.component';
import { AdminGroupsCrudComponent } from 'src/app/components/admin-groups-crud/admin-groups-crud.component';
import { PendingChangesGuard } from 'src/app/guards/pending-changes.guard';
import { CamelToSentencePipeModule } from '@wilson/wilsonng';
import { AdminBaseComponent } from 'src/app/components/admin-base/admin-base.component';
import { AccessCodeGeneratorComponent } from 'src/app/components/access-code-generator/access-code-generator.component';
import { AdminAttachmentsComponent } from 'src/app/components/admin-attachments/admin-attachments.component';
import { AdminAttachmentsOverlayComponent } from 'src/app/components/admin-attachments-overlay/admin-attachments-overlay.component';
import { ToastService } from 'src/app/services/toast.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AdminRoutingModule,
    UIModule,
    HeaderModule,
    FooterModule,
    CamelToSentencePipeModule,
  ],
  declarations: [
    // Components
    AdminBaseComponent,
    AdminComponent,
    AdminOverviewComponent,
    AdminDocumentsComponent,
    AdminDocumentsCrudComponent,
    AdminGroupsComponent,
    AdminGroupsCrudComponent,
    AdminAccessCodesComponent,
    AdminAccessCodesCrudComponent,
    AccessCodeGeneratorComponent,
    AdminAttachmentsComponent,
    AdminAttachmentsOverlayComponent,
  ],
  providers: [PendingChangesGuard, ToastService],
})
export class AdminModule {}
