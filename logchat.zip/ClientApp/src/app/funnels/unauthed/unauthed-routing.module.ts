import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NotFoundComponent, ForbiddenComponent } from '@wilson/wilsonng';
import { ComingSoonComponent } from 'src/app/components/coming-soon/coming-soon.component';
import { LoginComponent } from 'src/app/components/login/login.component';
import { MaintenanceComponent } from 'src/app/components/maintenance/maintenance.component';
import { SiteAvailabilityGuard } from 'src/app/guards/site-availability.guard';
import { NotFoundDataResolver } from 'src/app/resolvers/not-found-data.resolver';
import { UnauthedComponent } from './unauthed.component';

const routes: Routes = [
  {
    path: '',
    component: UnauthedComponent,
    children: [
      {
        path: 'login',
        canActivate: [SiteAvailabilityGuard],
        component: LoginComponent,
      },
      {
        path: 'notfound',
        component: NotFoundComponent,
        resolve: {
          notFoundData: NotFoundDataResolver,
        },
      },
      {
        path: 'comingsoon',
        component: ComingSoonComponent,
      },
      {
        path: 'maintenance',
        component: MaintenanceComponent,
      },
      {
        path: 'forbidden',
        component: ForbiddenComponent,
      },
      {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full',
      },
      {
        path: '**',
        redirectTo: '/notfound',
        pathMatch: 'full',
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UnauthedRoutingModule {}
