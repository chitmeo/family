import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { UIModule } from 'src/app/ui.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { UnauthedComponent } from './unauthed.component';
import { UnauthedRoutingModule } from './unauthed-routing.module';
import { MaintenanceComponent } from 'src/app/components/maintenance/maintenance.component';
import { ComingSoonComponent } from 'src/app/components/coming-soon/coming-soon.component';
import { FloatingIconsComponent } from 'src/app/components/floating-icons/floating-icons.component';
import { LoginComponent } from 'src/app/components/login/login.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    UnauthedRoutingModule,
    UIModule,
  ],
  declarations: [
    // Components
    FloatingIconsComponent,
    UnauthedComponent,
    LoginComponent,
    MaintenanceComponent,
    ComingSoonComponent,
  ],
})
export class UnauthedModule {}
