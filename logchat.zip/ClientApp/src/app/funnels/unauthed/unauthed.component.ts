import { Component, OnInit } from '@angular/core';
import { TitleService } from '@wilson/wilsonng';

@Component({
  selector: 'app-unauthed',
  templateUrl: './unauthed.component.html',
  styleUrls: ['./unauthed.component.scss'],
})
export class UnauthedComponent implements OnInit {
  constructor(private titleService: TitleService) {}

  ngOnInit(): void {
    this.titleService.setQualifier('');
  }
}
