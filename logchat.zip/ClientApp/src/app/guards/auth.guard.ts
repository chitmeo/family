import { Injectable } from '@angular/core';
import { AuthenticationService, RedirectService } from '@wilson/wilsonng';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard {
  constructor(
    private authenticationService: AuthenticationService,
    private redirectService: RedirectService
  ) {}

  canActivate(): boolean {
    return this.verifyUser();
  }

  canActivateChild(): boolean {
    return this.verifyUser();
  }

  private verifyUser(): boolean {
    const userIsLoggedIn = this.authenticationService.isLoggedIn();
    if (!userIsLoggedIn) {
      this.redirectService.setRedirectCookie(
        window.location.search.split('?')[1]
      );
      this.authenticationService.login();
      return false;
    }

    return true;
  }
}
