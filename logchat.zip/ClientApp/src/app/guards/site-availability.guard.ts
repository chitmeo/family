import { Injectable } from '@angular/core';
import {
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';
import { InitialLoadService } from '../services/initial-load.service';

@Injectable({
  providedIn: 'root',
})
export class SiteAvailabilityGuard {
  private backdoorKey = 'backdoor';
  constructor(
    private initialLoadService: InitialLoadService,
    private router: Router
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean | UrlTree {
    return this.siteAvailable(route, state);
  }

  canActivateChild(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean | UrlTree {
    return this.siteAvailable(route, state);
  }

  private siteAvailable(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean | UrlTree {
    this.setBackdoor(state);
    if (localStorage.getItem(this.backdoorKey) === 'true') {
      return true;
    }
    if (this.initialLoadService.initialLoad?.isDownForMaintenance) {
      return this.router.parseUrl('maintenance');
    } else if (this.initialLoadService.initialLoad?.isComingSoon) {
      return this.router.parseUrl('comingsoon');
    }
    return true;
  }

  private setBackdoor(state: RouterStateSnapshot): void {
    if (state.url.toLowerCase().indexOf('backdoor=true') > -1) {
      localStorage.setItem(this.backdoorKey, 'true');
    } else if (state.url.toLowerCase().indexOf('backdoor=false') > -1) {
      localStorage.setItem(this.backdoorKey, 'false');
    }
  }
}
