import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RedirectService, RouterNavigationService } from '@wilson/wilsonng';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { PageVisibilityService } from './services/page-visibility.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  pageVisible = false;

  constructor(
    private routerNavigationService: RouterNavigationService,
    private pageVisibilityService: PageVisibilityService,
    private cdr: ChangeDetectorRef,
    private router: Router,
    private redirectService: RedirectService
  ) {}

  ngOnInit(): void {
    this.watchPageVisibility().subscribe();
    this.routerNavigationService.startTrackingPreviousUrl();
    this.redirectUser();
  }

  watchPageVisibility(): Observable<boolean> {
    return this.pageVisibilityService.pageVisible.pipe(
      tap((visible) => {
        this.pageVisible = visible;
        this.cdr.detectChanges();
      })
    );
  }

  private redirectUser(): void {
    const redirect = this.redirectService.getRedirectCookie();
    if (redirect) {
      this.router.navigateByUrl(`${redirect}`);
      if (!redirect.startsWith('/admin')) {
        this.redirectService.clearRedirectCookie();
      }
    }
  }
}
