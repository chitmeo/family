using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DocumentViewer.Database;
using DocumentViewer.Database.AdminModels.Search;
using DocumentViewer.Database.AdminModels.Upsert;
using DocumentViewer.Database.ClientModels;
using DocumentViewer.Database.EntityModels;
using DocumentViewer.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using WilsonNet.Services;
using Document = DocumentViewer.Database.EntityModels.Document;
using Group = DocumentViewer.Database.EntityModels.Group;

namespace DocumentViewer.Services;

public class GroupService(
    IRepository<Group> repository,
    IDocViewerCollectionsContext context,
    IAzureService azureService) : RepositoryServiceBase<Group>(repository), IGroupService
{
    public async Task<Group> GetGroup(int groupId)
    {
        return await GetQueryable(groupId).Select(g => new Group
        {
            Id = g.Id,
            CreatedDate = g.CreatedDate,
            ModifiedDate = g.ModifiedDate,
            CreatedBy = g.CreatedBy,
            ModifiedBy = g.ModifiedBy,
            Title = g.Title,
            Description = g.Description,
            CoverImageUrl = g.CoverImageUrl,
            AccessCodes = g.AccessCodes.Select(a => new AccessCode
            {
                Id = a.Id,
                CodeText = a.CodeText,
                Notes = a.Notes
            }).ToList(),
            DocumentGroups = g.DocumentGroups.Select(dg => new DocumentGroup
            {
                DocumentId = dg.DocumentId,
                GroupId = dg.GroupId,
                Ordinal = dg.Ordinal,
                Document = new Document
                {
                    Id = dg.Document.Id,
                    Title = dg.Document.Title,
                    Description = dg.Document.Description
                }
            })
                .OrderBy(dg => dg.Ordinal)
                .ToList()
        }).FirstOrDefaultAsync();
    }

    public async Task<List<Group>> GetGroups(Search searchModel)
    {
        var query = context.Groups
            .Include(d => d.AccessCodes)
            .Include(d => d.DocumentGroups)
            .AsQueryable();

        query = FullSearchFilter(query, searchModel.Filters);
        query = FullSearchDateFilter(query, searchModel.DateRanges);
        query = FullSearchSort(query, searchModel.Sort);
        query = FullSearchSkipTake(query, searchModel.Skip, searchModel.Take);

        return await query.Select(x => new Group
        {
            Id = x.Id,
            CreatedDate = x.CreatedDate,
            ModifiedDate = x.ModifiedDate,
            CreatedBy = x.CreatedBy,
            ModifiedBy = x.ModifiedBy,
            Title = x.Title,
            Description = x.Description,
            // take one document group just to know if we have at least one
            DocumentGroups = x.DocumentGroups.Select(g => new DocumentGroup
            {
                DocumentId = g.DocumentId
            }).Take(1).ToList(),
            // retrieve all access codes to verify the security
            AccessCodes = x.AccessCodes.Select(a => new AccessCode
            {
                Id = a.Id,
                CodeText = a.CodeText,
                AccessCodeSecurities = a.AccessCodeSecurities.Select(s => new AccessCodeSecurity
                {
                    AccessCodeSecurityTypeId = s.AccessCodeSecurityTypeId,
                    Value = s.Value
                }).ToList(),
            }).ToList()
        }).ToListAsync();
    }

    public async Task<int> SortDocumentsInGroup(int groupId, int[] documentIds)
    {
        var docGroups = await context.DocumentGroups
            .Where(x => x.GroupId == groupId && documentIds.Contains(x.DocumentId)).ToListAsync();
        for (var i = 0; i < documentIds.Length; i++)
        {
            docGroups.Find(x => x.DocumentId == documentIds[i]).Ordinal = i;
        }

        return await context.SaveChangesAsync();
    }

    public async Task<ViewGroup> GetDirectoryByAccessCode(string codeText)
    {
        var queryChatbotDocuments = context.Documents
            .Where(d =>
                d.DocumentGroups.Any(g =>
                    g.Group.AccessCodes.Any(c =>
                        c.CodeText.ToLower() == codeText.ToLower()
                        && (c.AllowAnonymousEntry || c.AccessCodeSecurities.Any())
                    )
                )
            )
            .Where(d => d.DocumentOptions.Any(o => o.DocumentOptionTypeId == (int)DocumentOptionTypeDefinition.Chatbot))
            .Select(d => new { d.Id })
            .Distinct();

        return await context.AccessCodes
            .Select(x =>
                new ViewGroup
                {
                    Id = x.Group.Id,
                    CodeText = x.CodeText,
                    Title = x.Group.Title,
                    Description = x.Group.Description,
                    AllowAnonymousEntry = x.AllowAnonymousEntry,
                    CoverImageUrl = x.Group.CoverImageUrl,
                    RequiresUniversalLogin = x.AccessCodeSecurities.Count != 0,
                    Documents = x.Group.DocumentGroups.Select(d =>
                            new ViewDocument
                            {
                                Id = d.Document.Id,
                                Title = d.Document.Title,
                                Description = d.Document.Description,
                                ThumbnailUrl = d.Document.ThumbnailUrl,
                                FilePath = d.Document.FilePath,
                                Ordinal = d.Ordinal,
                                Attachments = d.Document.DocumentAttachments.Select(attachment => new Attachment
                                {
                                    PageNumber = attachment.PageNumber,
                                    ResourceIds = attachment.ResourceIds
                                }),
                                PageOffset = d.Document.PageOffset,
                                AllowAdminDelete = d.Document.AllowAdminDelete,
                                AllowSave = d.Document.DocumentOptions.Any(x => x.DocumentOptionTypeId == 1),
                                AllowPrint = d.Document.DocumentOptions.Any(x => x.DocumentOptionTypeId == 2),
                                Watermark = d.Document.DocumentOptions.Any(x => x.DocumentOptionTypeId == 3),
                                Selectable = d.Document.DocumentOptions.Any(x => x.DocumentOptionTypeId == 4),
                                IntroductoryVideoUrl = d.Document.IntroductoryVideoUrl,
                                EnableChatbot = queryChatbotDocuments.Any(x => x.Id == d.Document.Id),
                                SampleQuestions = d.Document.SampleQuestions
                            })
                        .OrderBy(d => d.Ordinal)
                        .ToList()
                })
            .FirstOrDefaultAsync(x => x.CodeText.ToLower() == codeText.ToLower());
    }

    public async Task<ViewGroup> GetDirectorySecurityInformation(string codeText)
    {
        var group = await context.AccessCodes
            .Where(x => x.CodeText.ToLower() == codeText.ToLower() && x.Active && x.Expiration > DateTime.UtcNow)
            .Select(x => new
            {
                x.AllowAnonymousEntry,
                RequiresUniversalLogin = x.AccessCodeSecurities.Count != 0,
                AccessCodeSecurities = x.AccessCodeSecurities.Select(s => new AccessCodeSecurity
                {
                    AccessCodeSecurityTypeId = s.AccessCodeSecurityTypeId,
                    Value = s.Value
                }).ToList()
            }).FirstOrDefaultAsync();

        if (group == null)
        {
            return null;
        }

        return new ViewGroup
        {
            AllowAnonymousEntry = group.AllowAnonymousEntry,
            RequiresUniversalLogin = group.RequiresUniversalLogin,
            RequiredSecurities = group.AccessCodeSecurities.ToDictionary(x => x.AccessCodeSecurityTypeId, x => x.Value)
        };
    }

    public async Task<int> UpsertGroup(Group group, IFormFile file)
    {
        // get the original group record (if it exists)
        var efGroup = await context.Groups.AsNoTracking()
            // we only need created info at the moment
            .Select(x => new Group { Id = x.Id, CreatedBy = x.CreatedBy, CreatedDate = x.CreatedDate })
            .FirstOrDefaultAsync(x => x.Id == group.Id);

        var documentIds = new List<int>(group.DocumentGroups.Select(x => x.DocumentId));

        // null out associated data we don't upsert initially
        group.DocumentGroups = null;
        group.AccessCodes = null;

        group.ModifiedDate = DateTime.UtcNow;
        // prefer the original created info, otherwise use what's passed in
        group.CreatedBy = efGroup?.CreatedBy ?? group.CreatedBy;
        group.CreatedDate = efGroup?.CreatedDate ?? group.CreatedDate;

        // if they have a custom file as the cover image, upload it, otherwise keep the url passed in
        group.CoverImageUrl = file != null
            ? await azureService.SaveThumbnailToAzure("secure-doc-thumbnail", file)
            : group?.CoverImageUrl;

        // upsert object which backfills the group's id (if it was 0)
        await context.Upsert(group);

        // we get the full list of documentids everytime
        // remove the old ones and add the new ones
        context.DocumentGroups.RemoveRange(context.DocumentGroups.Where(x => x.GroupId == group.Id));
        for (var i = 0; i < documentIds.Count; i++)
        {
            context.DocumentGroups.Add(new DocumentGroup
            {
                DocumentId = documentIds[i],
                GroupId = group.Id,
                Ordinal = i + 1 // +1 since ordinals are not zero-indexed
            });
        }

        await context.SaveChangesAsync();
        return group.Id;
    }
}