﻿using Amazon.Runtime.Internal;
using Azure;
using Azure.AI.OpenAI.Assistants;
using DocumentViewer.Services.Interfaces;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace DocumentViewer.Services;

[ExcludeFromCodeCoverage]
public class AzureAssistantsService(AssistantsClient client) : IAzureAssistantsService
{
    public Task<Response<AssistantThread>> CreateThreadAsync(CancellationToken token)
    {
        return client.CreateThreadAsync(token);
    }

    public Task<Response<ThreadMessage>> CreateMessageAsync(string threadId, MessageRole role, string content, CancellationToken token)
    {
        return client.CreateMessageAsync(threadId, role, content, cancellationToken: token);
    }

    public Task<Response<ThreadRun>> CreateRunAsync(string threadId, string assistantId, CancellationToken token)
    {
        return client.CreateRunAsync(threadId, new CreateRunOptions(assistantId), token);
    }

    public Task<Response<AssistantThread>> GetThreadAsync(string threadId, CancellationToken token)
    {
        return client.GetThreadAsync(threadId, token);
    }
    public Task<Response<ThreadRun>> GetRunAsync(string threadId, string runId, CancellationToken token)
    {
        return client.GetRunAsync(threadId, runId, token);
    }

    public Task<Response<PageableList<ThreadMessage>>> GetMessagesAsync(string threadId, CancellationToken token)
    {
        return client.GetMessagesAsync(threadId, cancellationToken: token);
    }

    public Task<Response<PageableList<ThreadMessage>>> GetMessagesAsync(string threadId, int limit, CancellationToken token)
    {
        return client.GetMessagesAsync(threadId, limit, cancellationToken: token);
    }
}
