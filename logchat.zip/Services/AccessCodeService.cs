using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DocumentViewer.Database;
using DocumentViewer.Database.AdminModels.Search;
using DocumentViewer.Database.AdminModels.Upsert;
using DocumentViewer.Database.EntityModels;
using DocumentViewer.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace DocumentViewer.Services;

public class AccessCodeService(
    IRepository<AccessCode> repository,
    IDocViewerCollectionsContext context,
    IAccessCodeSecurityValueService accessCodeSecurityValueService)
    : RepositoryServiceBase<AccessCode>(repository), IAccessCodeService
{
    public async Task<bool> IsAccessCodeValid(string codeText)
    {
        return await context.AccessCodes
            .AsNoTracking()
            .AnyAsync(x =>
                EF.Functions.Like(x.CodeText, $"%{codeText}%") &&
                x.Expiration > DateTime.UtcNow && x.Active);
    }

    public async Task<AccessCode> GetAccessCode(int accessCodeId)
    {
        var code = await GetQueryable(accessCodeId).AsNoTracking().Select(a => new AccessCode
        {
            Id = a.Id,
            CreatedDate = a.CreatedDate,
            ModifiedDate = a.ModifiedDate,
            CreatedBy = a.CreatedBy,
            ModifiedBy = a.ModifiedBy,
            CodeText = a.CodeText,
            Expiration = a.Expiration,
            Notes = a.Notes,
            Active = a.Active,
            AllowAnonymousEntry = a.AllowAnonymousEntry,
            GroupId = a.GroupId,
            Group = new Group
            {
                Id = a.Group.Id,
                Title = a.Group.Title
            },
            AccessCodeSecurities = a.AccessCodeSecurities
                .Select(acs => new AccessCodeSecurity
                {
                    AccessCodeSecurityTypeId = acs.AccessCodeSecurityTypeId,
                    Value = acs.Value
                }).ToList()
        }).FirstOrDefaultAsync();

        if (code != null)
        {
            // get the security values' names
            foreach (var s in code.AccessCodeSecurities)
            {
                var kv = await accessCodeSecurityValueService.SearchEntryById(s.Value, s.AccessCodeSecurityTypeId);
                s.Name = kv.Value;
            }
        }

        return code;
    }

    public async Task<List<AccessCode>> GetAccessCodes(Search searchModel)
    {
        var query = context.AccessCodes
            .Include(d => d.Group)
            .Include(d => d.AccessCodeSecurities)
            .AsQueryable();

        query = FullSearchFilter(query, searchModel.Filters);
        query = FullSearchDateFilter(query, searchModel.DateRanges);
        query = FullSearchSort(query, searchModel.Sort);
        query = FullSearchSkipTake(query, searchModel.Skip, searchModel.Take);

        return await query.Select(a => new AccessCode
        {
            Id = a.Id,
            CreatedDate = a.CreatedDate,
            ModifiedDate = a.ModifiedDate,
            CreatedBy = a.CreatedBy,
            ModifiedBy = a.ModifiedBy,
            CodeText = a.CodeText,
            Expiration = a.Expiration,
            Active = a.Active,
            Group = new Group
            {
                Id = a.Group.Id,
                Title = a.Group.Title
            },
        }).ToListAsync();
    }

    public async Task<int> UpsertAccessCode(AccessCode accessCode)
    {
        // get the original access code (if it exists)
        var efAccessCode = await context.AccessCodes.AsNoTracking()
            .Select(x => new AccessCode { Id = x.Id, CreatedBy = x.CreatedBy, CreatedDate = x.CreatedDate })
            .FirstOrDefaultAsync(x => x.Id == accessCode.Id);
        var isEfSecured = await context.AccessCodeSecurities.AnyAsync(a => a.AccessCodeId == accessCode.Id);

        // store the new securities for insert
        var securities = new List<KeyValuePair<int, string>>();
        accessCode.AccessCodeSecurities.ToList().ForEach(x =>
        {
            securities.Add(new KeyValuePair<int, string>(x.AccessCodeSecurityTypeId, x.Value));
        });
        accessCode.AccessCodeSecurities = null;

        // we get the full list of access code securities each time
        // so delete and reinsert
        context.AccessCodeSecurities.RemoveRange(
            context.AccessCodeSecurities.Where(x => x.AccessCodeId == accessCode.Id));

        accessCode.ModifiedDate = DateTime.UtcNow;
        // prefer the original created info, otherwise use what's passed in
        accessCode.CreatedBy = efAccessCode?.CreatedBy ?? accessCode.CreatedBy;
        accessCode.CreatedDate = efAccessCode?.CreatedDate ?? accessCode.CreatedDate;

        // upsert the record
        await context.Upsert(accessCode);

        // upsert the new securities
        context.AccessCodeSecurities.AddRange(securities.Select(x => new AccessCodeSecurity
        {
            AccessCodeId = accessCode.Id,
            AccessCodeSecurityTypeId = x.Key,
            Value = x.Value
        }));

        await context.SaveChangesAsync();

        // If security is not configured, the chatbot must be disabled for all documents that use this access code
        var isChatbotDisabled = false;
        var isSecured = securities.Count > 0;
        // If this is an update, check whether the security settings have changed
        var isSecurityChanged = efAccessCode == null 
            || accessCode.AllowAnonymousEntry != efAccessCode.AllowAnonymousEntry
            || isSecured != isEfSecured;

        if (isSecurityChanged)
        {
            isChatbotDisabled = !accessCode.AllowAnonymousEntry && securities.Count == 0;
        }

        if (isChatbotDisabled)
        {
            var documentOptions = await context.DocumentOptions
                .Where(x => x.Document.DocumentGroups.Any(a => a.GroupId == accessCode.GroupId))
                .Where(x => x.DocumentOptionTypeId == (int)DocumentOptionTypeDefinition.Chatbot)
                .ToArrayAsync();

            if (documentOptions.Length > 0)
            {
                context.DocumentOptions.RemoveRange(documentOptions);
                await context.SaveChangesAsync();
            }
        }

        return accessCode.Id;
    }
}