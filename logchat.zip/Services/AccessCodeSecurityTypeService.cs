using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DocumentViewer.Database;
using DocumentViewer.Database.EntityModels;
using DocumentViewer.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace DocumentViewer.Services;

public class AccessCodeSecurityTypeService(IDocViewerCollectionsContext context) : IAccessCodeSecurityTypeService
{
    public async Task<List<AccessCodeSecurityType>> GetAccessCodeSecurityTypes()
    {
        return await context.AccessCodeSecurityTypes.Select(x => new AccessCodeSecurityType
        {
            Id = x.Id,
            Type = x.Type,
            Description = x.Description
        }).ToListAsync();
    }
}