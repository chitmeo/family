﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using DocumentViewer.Database.AdminModels.Search;
using WilsonNet.Services.BaseDatabaseServices;
using WilsonNet.Services.BaseDatabaseServices.Interfaces;
using WilsonNet.Services.BaseDatabaseServices.Models;
using WilsonNet.Services.EntityFrameworkServices.Entities;
using Filter = DocumentViewer.Database.AdminModels.Search.Filter;
using Sort = DocumentViewer.Database.AdminModels.Search.Sort;

namespace DocumentViewer.Services;

public class RepositoryServiceBase<T> : RepositoryServiceBase<T, int> where T : BaseEntity<int>
{
    protected RepositoryServiceBase(IRepository<T, int> repository) : base(repository) {}
    
    /// <summary>
    /// Filters the query on a list of filter key/values
    /// </summary>
    /// <param name="query">The in-progress query</param>
    /// <param name="filters">The filters to use</param>
    /// <typeparam name="T">The entity type being worked on</typeparam>
    protected static IQueryable<T> FullSearchFilter(IQueryable<T> query, IReadOnlyCollection<Filter> filters)
    {
        if (filters == null || filters.Count == 0)
        {
            return query;
        }

        return filters.Aggregate(query, (current, filter) => filter.FilterType switch
        {
            FilterTypeDefinition.StartsWith => current.Where($"{filter.Column}.StartsWith(@0)", filter.Value),
            FilterTypeDefinition.EndsWith => current.Where($"{filter.Column}.EndsWith(@0)", filter.Value),
            FilterTypeDefinition.Contains => current.Where($"{filter.Column}.Contains(@0)", filter.Value),
            FilterTypeDefinition.NotContains => current.Where($"!{filter.Column}.Contains(@0)", filter.Value),
            FilterTypeDefinition.Equals => current.Where($"{filter.Column} == @0", filter.Value),
            FilterTypeDefinition.NotEquals => current.Where($"{filter.Column} <> @0", filter.Value),
            FilterTypeDefinition.LessThan => current.Where($"{filter.Column} < @0", filter.Value),
            FilterTypeDefinition.LessThanEqualTo => current.Where($"{filter.Column} <= @0", filter.Value),
            FilterTypeDefinition.GreaterThan => current.Where($"{filter.Column} > @0", filter.Value),
            FilterTypeDefinition.GreaterThanEqualTo => current.Where($"{filter.Column} >= @0", filter.Value),
            _ => throw new ArgumentException($"Provided FilterType '{filter.FilterType}' is not valid"),
        });
    }

    /// <summary>
    /// Sort records for a full search
    /// </summary>
    /// <param name="sort">The key-value pair, key: sort column, value: sort direction</param>
    /// <param name="query">The in-progress query</param>
    /// <typeparam name="T">The entity type being worked on</typeparam>
    protected static IQueryable<T> FullSearchSort(IQueryable<T> query, Sort sort)
    {
        if (sort == null) return query;
        var sortDirection = sort.Direction == SortDirectionDefinition.Ascending ? "ASC" : "DESC";
        query = query.OrderBy($"{sort.Column} {sortDirection}");

        return query;
    }

    /// <summary>
    /// Filters the full search on a range of dates
    /// </summary>
    /// <param name="dateRanges">Key: Property Name, Value: date range object with start and end dates</param>
    /// <param name="query">The in-progress query</param>
    /// <typeparam name="T">The entity type being worked on</typeparam>
    protected static IQueryable<T> FullSearchDateFilter(IQueryable<T> query, List<DateRange> dateRanges)
    {
        if (dateRanges == null || dateRanges.Count == 0)
        {
            return query;
        }

        foreach (var dateRange in dateRanges)
        {
            if (dateRange.Start != null)
            {
                query = query.Where($"{dateRange.Column} >= @0", dateRange.Start.Value.ToString("yyyy-MM-dd HH:mm:ss.fff"));
            }

            if (dateRange.End != null)
            {
                query = query.Where($"{dateRange.Column} <= @0", dateRange.End.Value.ToString("yyyy-MM-dd HH:mm:ss.fff"));
            }
        }

        return query;
    }

    /// <summary>
    /// Skips and Takes records on the query for paging purposes
    /// </summary>
    /// <param name="skip">The number of records to skip</param>
    /// <param name="take">The number of records to take</param>
    /// <param name="query">The in-progress query</param>
    /// <typeparam name="T">The entity type being worked on</typeparam>
    protected static IQueryable<T> FullSearchSkipTake(IQueryable<T> query, int skip, int take)
    {
        if (skip > 0)
        {
            query = query.Skip(skip);
        }

        if (take > 0)
        {
            query = query.Take(take);
        }

        return query;
    }
}
