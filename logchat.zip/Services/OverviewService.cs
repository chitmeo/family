using System;
using System.Linq;
using System.Threading.Tasks;
using DocumentViewer.Database;
using DocumentViewer.Database.AdminModels.Overview;
using DocumentViewer.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace DocumentViewer.Services;

public class OverviewService(IDocViewerCollectionsContext context) : IOverviewService
{
    private static OverviewStatistics _cache;
    private const int CacheHours = 12;

    public async Task<OverviewStatistics> GetOverviewStatistics(bool cacheBust)
    {
        if (_cache != null && !cacheBust && _cache.OverviewLastCalculated >= DateTime.UtcNow.AddHours(-CacheHours))
        {
            return _cache;
        }

        var overviewStatistics = new OverviewStatistics
        {
            DocumentStatistics = await GetDocumentStatistics(),
            GroupStatistics = await GetGroupStatistics(),
            AccessCodeStatistics = await GetAccessCodeStatistics(),
            OverviewLastCalculated = DateTime.UtcNow
        };
        _cache = overviewStatistics;
        return overviewStatistics;
    }

    private async Task<DocumentStatistics> GetDocumentStatistics()
    {
        var docStatistics = new DocumentStatistics
        {
            Total = await context.Documents.CountAsync(),
            TotalUnassigned = await context.Documents.CountAsync(x => x.DocumentGroups.Count == 0),
            Recent = await context.Documents
                .OrderByDescending(x => x.CreatedDate)
                .Take(10)
                .Select(x => new OverviewDocument
                {
                    Id = x.Id,
                    CreatedDate = x.CreatedDate,
                    ModifiedDate = x.ModifiedDate,
                    CreatedBy = x.CreatedBy,
                    ModifiedBy = x.ModifiedBy,
                    Title = x.Title,
                    Description = x.Description,
                    IsInGroup = x.DocumentGroups.Count != 0
                }).ToListAsync()
        };

        return docStatistics;
    }

    private async Task<GroupStatistics> GetGroupStatistics()
    {
        var groupStatistics = new GroupStatistics
        {
            Total = await context.Groups.CountAsync(),
            TotalWithoutDocuments = await context.Groups.CountAsync(x => x.DocumentGroups.Count == 0),
            TotalWithoutAccessCodes = await context.Groups.CountAsync(x => x.AccessCodes.Count == 0)
        };

        return groupStatistics;
    }

    private async Task<AccessCodeStatistics> GetAccessCodeStatistics()
    {
        var acStatistics = new AccessCodeStatistics
        {
            Total = await context.AccessCodes.CountAsync(),
            TotalSecure = await context.AccessCodes.CountAsync(x => x.AccessCodeSecurities.Count != 0),
            TotalUnsecure = await context.AccessCodes.CountAsync(x => x.AccessCodeSecurities.Count == 0)
        };

        return acStatistics;
    }
}