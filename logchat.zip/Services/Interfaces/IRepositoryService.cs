﻿using WilsonNet.Services.BaseDatabaseServices.Interfaces;
using WilsonNet.Services.EntityFrameworkServices.Entities;

namespace DocumentViewer.Services.Interfaces;

public interface IRepositoryService<T> : IRepositoryService<T, int> where T : BaseEntity<int>;