using System.Collections.Generic;
using System.Threading.Tasks;
using DocumentViewer.Database.AdminModels.Search;
using DocumentViewer.Database.AdminModels.Upsert;
using DocumentViewer.Database.ClientModels;
using Microsoft.AspNetCore.Http;
using Document = DocumentViewer.Database.EntityModels.Document;

namespace DocumentViewer.Services.Interfaces;

public interface IDocumentService : IRepositoryService<Document>
{
    /// <summary>
    /// Retrieve one document
    /// </summary>
    /// <param name="documentId">The id of the document to retrieve</param>
    /// <param name="isForDownload">Whether we are retrieving the document for download</param>
    /// <returns>A single document</returns>
    Task<Document> GetDocument(int documentId, bool isForDownload = false);

    /// <summary>
    /// Retrieve a list of documents
    /// </summary>
    /// <param name="searchModel">The query parameters in which to find the documents</param>
    /// <returns>The list of documents found</returns>
    Task<List<Document>> GetDocuments(Search searchModel, int groupId = 0);

    /// <summary>
    /// Upsert a document and save associated files to azure
    /// </summary>
    /// <param name="document">The document model to save</param>
    /// <param name="file">The file to upload to azure</param>
    /// <param name="thumbnail">The thumbnail to upload to azure</param>
    /// <returns>The document id</returns>
    Task<int> UpsertDocument(DocumentUpsert document, IFormFile file, IFormFile thumbnail);

    /// <summary>
    /// Retrieve a list of document option types
    /// </summary>
    /// <returns>The list of document option types found</returns>
    Task<List<DocumentOptionType>> GetDocumentOptionTypes();

    /// <summary>
    /// Retrieve a list of document types
    /// </summary>
    /// <returns>The list of document types found</returns>
    Task<List<DocumentType>> GetDocumentTypes();

    /// <summary>
    /// Get the fully qualified url for a document by id
    /// </summary>
    /// <param name="documentId">The document's id</param>
    /// <returns>The fully qualified url</returns>
    Task<string> GetFullyQualifiedUrl(int documentId);

    Task<bool> IsDocumentInAccessCodeGroup(string accessCode, int documentId);

    string GetAzureFileLink(string filePath);

    Task<string> SaveAnnotationsFile(string xfdfData, string docId, string userId);

    Task<string> GetAnnotationsFile(string docId, string userId);
    Task<int> DeleteDocument(int documentId);
}