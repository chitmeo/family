using System.Collections.Generic;
using System.Threading.Tasks;
using DocumentViewer.Database.EntityModels;

namespace DocumentViewer.Services.Interfaces;

public interface IAccessCodeSecurityTypeService
{
    Task<List<AccessCodeSecurityType>> GetAccessCodeSecurityTypes();
}