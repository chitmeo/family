﻿using DocumentViewer.Database.ChatbotModels;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace DocumentViewer.Services.Interfaces;

public interface IChatbotService
{
    public Task<ChatbotAssistantAnswer> SendQuestionToAssistant(ChatbotAssistantQuestion requestData, CancellationToken token);
    public Task<IDictionary<int, string>> ValidateAssistantQuestion(ChatbotAssistantQuestion requestData, ChatbotUser user, CancellationToken token);
}
