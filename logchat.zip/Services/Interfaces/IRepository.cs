﻿using WilsonNet.Services.BaseDatabaseServices.Interfaces;
using WilsonNet.Services.EntityFrameworkServices.Entities;

namespace DocumentViewer.Services.Interfaces;

public interface IRepository<T> : IRepository<T, int> where T : BaseEntity<int>;