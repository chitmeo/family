using System.Threading.Tasks;
using DocumentViewer.Database.AdminModels.Overview;

namespace DocumentViewer.Services.Interfaces;

public interface IOverviewService
{
    /// <summary>
    /// Retrieve the overview statistics
    /// </summary>
    /// <param name="cacheBust">Whether to get the statistics fresh, or to use the last cached version</param>
    /// <returns>The overview statics model</returns>
    Task<OverviewStatistics> GetOverviewStatistics(bool cacheBust);
}