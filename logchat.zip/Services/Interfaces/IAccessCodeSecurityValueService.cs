using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DocumentViewer.Services.Interfaces;

public interface IAccessCodeSecurityValueService
{
    Task<Dictionary<Guid, string>> SearchEntriesInType(string query, int securityType);
    Task<KeyValuePair<Guid, string>> SearchEntryById(string id, int securityType);
    Task<bool> IsUserInSecurity(Guid userId, int securityType, string securityValue);
}