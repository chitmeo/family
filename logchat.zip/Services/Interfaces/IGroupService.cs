using System.Collections.Generic;
using System.Threading.Tasks;
using DocumentViewer.Database.AdminModels.Search;
using DocumentViewer.Database.EntityModels;
using Microsoft.AspNetCore.Http;

namespace DocumentViewer.Services.Interfaces;

public interface IGroupService : IRepositoryService<Group>
{
    /// <summary>
    /// Retrieve a single group and its associated data
    /// </summary>
    /// <param name="groupId">The id of the group to retrieve</param>
    /// <returns>The first group found</returns>
    Task<Group> GetGroup(int groupId);

    /// <summary>
    /// Retrieve a list of groups
    /// </summary>
    /// <param name="searchModel">The search parameters for the query</param>
    /// <returns>A list of groups that match the query parameters</returns>
    Task<List<Group>> GetGroups(Search searchModel);

    /// <summary>
    /// Sort a list of documents within a group
    /// </summary>
    /// <param name="groupId">The group to sort</param>
    /// <param name="documentIds">The document ids provided in the correct sort order</param>
    /// <returns>The integer id of the operation</returns>
    Task<int> SortDocumentsInGroup(int groupId, int[] documentIds);

    /// <summary>
    /// Retrieve a group and its associated documents by access code
    /// </summary>
    /// <param name="codeText">The access code used to find the group</param>
    /// <returns>A single group</returns>
    Task<Database.ClientModels.ViewGroup> GetDirectoryByAccessCode(string codeText);

    /// <summary>
    /// Upsert a group
    /// </summary>
    /// <param name="group">The group to upsert</param>
    /// <returns>The group's ID</returns>
    Task<int> UpsertGroup(Group group, IFormFile file);

    /// <summary>
    /// Retrieve only a groups security information for login
    /// </summary>
    /// <param name="codeText">The access code used</param>
    /// <returns>A partial group object containing only security information</returns>
    Task<Database.ClientModels.ViewGroup> GetDirectorySecurityInformation(string codeText);
}