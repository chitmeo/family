namespace DocumentViewer.Services.Interfaces;

public interface IWarmUpSeederService
{
    void Seed();
}