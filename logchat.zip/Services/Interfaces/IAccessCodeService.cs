using System.Collections.Generic;
using System.Threading.Tasks;
using DocumentViewer.Database.AdminModels.Search;
using DocumentViewer.Database.EntityModels;

namespace DocumentViewer.Services.Interfaces;

public interface IAccessCodeService : IRepositoryService<AccessCode>
{
    /// <summary>
    /// Retrieve a single access code and its associated data
    /// </summary>
    /// <param name="accessCodeId">The id of the access code to retrieve</param>
    /// <returns>The first access code found</returns>
    Task<AccessCode> GetAccessCode(int accessCodeId);

    /// <summary>
    /// Retrieve a list of access codes
    /// </summary>
    /// <param name="searchModel">The search paarameter for the query</param>
    /// <returns>A list of access codes found</returns>
    Task<List<AccessCode>> GetAccessCodes(Search searchModel);

    /// <summary>
    /// Update or Insert an access code
    /// </summary>
    /// <param name="accessCode">The access code model to act upon</param>
    /// <returns>The Id of the access code</returns>
    Task<int> UpsertAccessCode(AccessCode accessCode);

    /// <summary>
    /// Determines if an access code is valid (no expired and active)
    /// </summary>
    /// <param name="codeText">The access code model to check</param>
    /// <returns>If the access code is valid</returns>
    Task<bool> IsAccessCodeValid(string codeText);
}