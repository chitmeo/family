﻿using Azure;
using Azure.AI.OpenAI.Assistants;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace DocumentViewer.Services.Interfaces;

public interface IAzureAssistantsService
{
    Task<Response<AssistantThread>> CreateThreadAsync(CancellationToken token);
    Task<Response<ThreadMessage>> CreateMessageAsync(string threadId, MessageRole role, string content, CancellationToken token);
    Task<Response<ThreadRun>> CreateRunAsync(string threadId, string assistantId, CancellationToken token);
    Task<Response<AssistantThread>> GetThreadAsync(string threadId, CancellationToken token);
    Task<Response<ThreadRun>> GetRunAsync(string threadId, string runId, CancellationToken token);
    Task<Response<PageableList<ThreadMessage>>> GetMessagesAsync(string threadId, CancellationToken token);
    Task<Response<PageableList<ThreadMessage>>> GetMessagesAsync(string threadId, int limit, CancellationToken token);
}
