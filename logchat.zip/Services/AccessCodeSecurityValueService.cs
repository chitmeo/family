using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using DocumentViewer.Database.AcademyModels;
using DocumentViewer.Services.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace DocumentViewer.Services;

public class AccessCodeSecurityValueService(
    IHttpClientFactory clientFactory,
    IConfiguration configuration,
    ILogger<AccessCodeSecurityValueService> logger)
    : IAccessCodeSecurityValueService
{
    private readonly string _academyBaseUrl = configuration["AcademyApi:BaseUrl"];
    private readonly string _academyApiSecretKey = configuration["AcademyApiSecretKey"];

    public async Task<Dictionary<Guid, string>> SearchEntriesInType(string query, int securityType)
    {
        try
        {
            var path = securityType switch
            {
                // Communities
                1 => "/UserClaims/getCommunityRolesByName?startsWith=",
                // Trainings
                2 => "/Trainings/getByNumber?startsWith=",
                // Training Templates
                3 => "/Trainings/getTemplatesByName?startsWith=",
                _ => ""
            };

            // Set up and send HTTP request
            var url = _academyBaseUrl + path + query;
            var client = clientFactory.CreateClient();
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Add("SecretKey", _academyApiSecretKey);
            var response = await client.SendAsync(request);

            var securities = new Dictionary<Guid, string>();
            if (response.IsSuccessStatusCode)
            {
                var responseStr = await response.Content.ReadAsStringAsync();
                switch (securityType)
                {
                    case 1:
                    {
                        var communities = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Community>>(responseStr);
                        securities = communities.ToDictionary(x => x.Id, x => x.Name);
                    }
                        break;
                    case 2:
                    {
                        var trainings = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Training>>(responseStr);
                        securities = trainings.ToDictionary(x => x.Id, x => x.Name);
                    }
                        break;
                    case 3:
                    {
                        var templates = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TrainingTemplate>>(responseStr);
                        securities = templates.ToDictionary(x => x.Id, x => x.Name);
                    }
                        break;
                }
            }
            else if (response.StatusCode != HttpStatusCode.NotFound)
            {
                logger.LogError("Error searching entries in security type {type}. HTTP error code: {code}", securityType, response.StatusCode);
            }
            return securities;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "SearchEntriesInType exited with an exception for security type {type}. Error: {msg}", securityType, ex.Message);
            return new Dictionary<Guid, string>();
        }
    }

    public async Task<KeyValuePair<Guid, string>> SearchEntryById(string id, int securityType)
    {
        try
        {
            var path = securityType switch
            {
                // Communities
                1 => "/UserClaims/getCommunityRoleById?communityId=",
                // Trainings
                2 => "/Trainings/getById?trainingId=",
                // Training Templates
                3 => "/Trainings/getTemplateById?templateId=",
                _ => ""
            };

            // Set up and send HTTP request
            var url = _academyBaseUrl + path + id;
            var client = clientFactory.CreateClient();
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Add("SecretKey", _academyApiSecretKey);
            var response = await client.SendAsync(request);

            var security = new KeyValuePair<Guid, string>();
            if (response.IsSuccessStatusCode)
            {
                var responseStr = await response.Content.ReadAsStringAsync();
                switch (securityType)
                {
                    case 1:
                    {
                        // The community endpoint returns an array instead of just a single object
                        var communityList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Community>>(responseStr);
                        security = new KeyValuePair<Guid, string>(communityList[0].Id, communityList[0].Name);
                    }
                        break;
                    case 2:
                    {
                        var training = Newtonsoft.Json.JsonConvert.DeserializeObject<Training>(responseStr);
                        security = new KeyValuePair<Guid, string>(training.Id, training.Name);
                    }
                        break;
                    case 3:
                    {
                        // The template endpoint returns an array instead of just a single object
                        var templateList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TrainingTemplate>>(responseStr);
                        security = new KeyValuePair<Guid, string>(templateList[0].Id, templateList[0].Name);
                    }
                        break;
                }
            }
            else
            {
                logger.LogError("Error searching entry by id for security type {type}, and id {id}. HTTP error code: {code}", securityType, id, response.StatusCode);
            }
            return security;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "SearchEntryById exited with an exception for security type {type}, and id {id}. Error: {msg}", securityType, id, ex.Message);
            return new KeyValuePair<Guid, string>();
        }
    }

    public async Task<bool> IsUserInSecurity(Guid userId, int securityType, string securityValue)
    {
        try
        {
            var path = securityType switch
            {
                // Communities
                1 => "/UserClaims/memberHasclaim?memberId=" + userId + "&roleId=",
                // Trainings
                2 => "/Trainings/isMemberInTraining?memberId=" + userId + "&trainingId=",
                // Training Templates
                3 => "/Trainings/isMemberInTrainingForTrainingTemplate?memberId=" + userId + "&trainingTemplateId=",
                _ => ""
            };
            // Set up and send HTTP request
            var url = _academyBaseUrl + path + securityValue;
            var client = clientFactory.CreateClient();
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Add("SecretKey", _academyApiSecretKey);
            var response = await client.SendAsync(request);
            var userIsInSecurity = false;
            if (response.IsSuccessStatusCode)
            {
                var responseStr = await response.Content.ReadAsStringAsync();
                _ = bool.TryParse(responseStr, out userIsInSecurity);
            }
            else
            {
                logger.LogError("Error checking if user with id {id} is in security {type}. HTTP error code: {code}", userId, securityType, response.StatusCode);
            }

            return userIsInSecurity;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "IsUserInSecurity exited with an exception for security type {type}, and id {id}. Error: {msg}", securityType, userId, ex.Message);
            return false;
        }
    }
}