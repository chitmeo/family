﻿using Azure;
using Azure.AI.OpenAI.Assistants;
using DocumentViewer.Database.AdminModels.Upsert;
using DocumentViewer.Database.ChatbotModels;
using DocumentViewer.Exceptions.Chatbot;
using DocumentViewer.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace DocumentViewer.Services;

public class ChatbotService (
    IAzureAssistantsService azureAssistantsService,
    IGroupService groupService,
    IAccessCodeSecurityValueService accessCodeSecurityValueService,
    IDocumentService documentService
) : IChatbotService
{
    private readonly int MAX_MESSAGES = (int)10e4; // 100,000 messages

    private async Task<Dictionary<int, string>> ValidatePrivateAccessCode(ChatbotAssistantQuestion requestData, ChatbotUser user)
    {
        var errors = new Dictionary<int, string>();

        if (string.IsNullOrEmpty(requestData.AccessCode))
        {
            errors.Add(StatusCodes.Status400BadRequest, "Access Code is required.");

            return errors;
        }

        var meta = await groupService.GetDirectorySecurityInformation(requestData.AccessCode);

        if (meta == null)
        {
            errors.Add(StatusCodes.Status404NotFound, "Access Code not found.");

            return errors;
        }

        if (!meta.AllowAnonymousEntry)
        {
            if (meta.RequiredSecurities.Count == 0)
            {
                errors.Add(StatusCodes.Status503ServiceUnavailable, "The chatbot is unavailable for this document.");

                return errors;
            }

            // if user is not logged in or we don't have a user id
            if (!user.IsAuthenticated || !user.Id.HasValue || user.Id == Guid.Empty)
            {
                errors.Add(StatusCodes.Status401Unauthorized, "Token is expired.");

                return errors;
            }

            var allowedChatbot = true;

            // if anonymous access is not allowed, verify that the user has all required security permissions
            foreach (var security in meta.RequiredSecurities)
            {
                var isUserInSecurity = await accessCodeSecurityValueService.IsUserInSecurity(
                    user.Id.Value,
                    security.Key,
                    security.Value
                );

                if (!isUserInSecurity)
                {
                    allowedChatbot = false;
                    break;
                }
            }

            if (!allowedChatbot)
            {
                errors.Add(StatusCodes.Status503ServiceUnavailable, "The chatbot is unavailable for this document.");
            }
        }

        return errors;
    }

    private async Task<Dictionary<int, string>> ValidateDocumentAndAssistant(ChatbotAssistantQuestion requestData)
    {
        var errors = new Dictionary<int, string>();

        if (!requestData.DocumentId.HasValue)
        {
            errors.Add(StatusCodes.Status400BadRequest, "Document ID is required.");

            return errors;
        }

        var document = await documentService.GetDocument(requestData.DocumentId.Value);

        if (document == null)
        {
            errors.Add(StatusCodes.Status404NotFound, "Document not found.");

            return errors;
        }

        var enabledChatbot = document.DocumentOptions.Any(a => a.DocumentOptionTypeId == (int)DocumentOptionTypeDefinition.Chatbot);

        if (!enabledChatbot)
        {
            errors.Add(StatusCodes.Status503ServiceUnavailable, "The chatbot is unavailable for this document.");

            return errors;
        }

        if (string.IsNullOrEmpty(document.AssistantId))
        {
            errors.Add(StatusCodes.Status404NotFound, "Assistant not found.");
        }

        return errors;
    }

    private async Task<Dictionary<int, string>> ValidateAssistantThread(string threadId, CancellationToken token)
    {
        var errors = new Dictionary<int, string>();

        if (string.IsNullOrEmpty(threadId))
        {
            return errors;
        }

        bool isThreadExists;

        try
        {
            var threadResp = await azureAssistantsService.GetThreadAsync(threadId, token);

            isThreadExists = threadResp.Value != null;
        }
        catch (RequestFailedException ex) when (ex.Status == 404)
        {
            isThreadExists = false;
        }
        catch (Exception)
        {
            isThreadExists = false;
        }

        if (!isThreadExists)
        {
            errors.Add(StatusCodes.Status404NotFound, "Thread ID not found.");
        }

        return errors;
    }

    public async Task<ChatbotAssistantAnswer> SendQuestionToAssistant(
        ChatbotAssistantQuestion requestData,
        CancellationToken token
    )
    {
        try
        {
            // Create a thread
            var threadId = requestData.ThreadId;

            if (string.IsNullOrEmpty(requestData.ThreadId))
            {
                var threadResp = await azureAssistantsService.CreateThreadAsync(token);
                var thread = threadResp.Value;

                threadId = thread.Id;
            }
            else
            {
                var oldThreadMsgResp = await azureAssistantsService.GetMessagesAsync(requestData.ThreadId, token);
                var oldThreadMsgList = oldThreadMsgResp.Value;
                var odlThreadMsgCount = oldThreadMsgList.Count();

                // If the thread has too many messages, create a new thread
                // https://platform.openai.com/docs/assistants/quickstart#step-3-add-a-message-to-the-thread
                if (odlThreadMsgCount >= MAX_MESSAGES)
                {
                    var threadResp = await azureAssistantsService.CreateThreadAsync(token);
                    var thread = threadResp.Value;

                    threadId = thread.Id;
                }
            }

            // Add a user question to the thread
            await azureAssistantsService.CreateMessageAsync(
                threadId,
                MessageRole.User,
                requestData.Question,
                token
            );

            // Run the thread
            var document = await documentService.GetDocument(requestData.DocumentId.Value);

            var threadRunResp = await azureAssistantsService.CreateRunAsync(threadId, document.AssistantId, token);
            var threadRun = threadRunResp.Value;

            // Wait for the assistant to respond
            do
            {
                await Task.Delay(TimeSpan.FromMilliseconds(500), token);
                threadRunResp = await azureAssistantsService.GetRunAsync(threadId, threadRun.Id, token);
            } while (
                threadRunResp.Value.Status == RunStatus.Queued
                || threadRunResp.Value.Status == RunStatus.InProgress
            );

            // Check the thread once the run completes
            if (threadRunResp.Value.Status != RunStatus.Completed)
            {
                throw new AzureOpenAIThreadRunException(threadRunResp.Value);
            }

            // Get the first message in the thread once the run has completed
            var afterRunMsgResp = await azureAssistantsService.GetMessagesAsync(threadId, limit: 1, token);

            if (afterRunMsgResp.Value.Data == null || afterRunMsgResp.Value.Data.Count == 0)
            {
                throw new AzureOpenAIThreadMsgException("An exception occurred while retrieving the last message in the conversation.");
            }

            var threadMsg = afterRunMsgResp.Value.Data[0];

            // If the message is not from the assistant, return null
            if (threadMsg.Role != MessageRole.Assistant)
            {
                throw new AzureOpenAIThreadMsgException("The last message in the conversation is not from the assistant.");
            }

            // Get the assistant's answer
            var contentItem = (MessageTextContent)threadMsg.ContentItems.FirstOrDefault(x => x is MessageTextContent);

            if (contentItem == null)
            {
                throw new AzureOpenAIThreadMsgException("The last message from the assistant has no answer.");
            }

            var result = new ChatbotAssistantAnswer
            {
                ThreadId = threadId,
                Role = threadMsg.Role.ToString(),
                Content = contentItem.Text,
                CreatedAt = threadMsg.CreatedAt,
            };

            foreach (var annotation in contentItem.Annotations)
            {
                result.Content = result.Content.Replace(annotation.Text, string.Empty);
            }

            return result;
        }
        catch (Exception ex)
        {
            throw new AzureOpenAIException(ex.Message);
        }
    }

    public async Task<IDictionary<int, string>> ValidateAssistantQuestion(
        ChatbotAssistantQuestion requestData,
        ChatbotUser user,
        CancellationToken token
    )
    {
        // Validate the private access code if provided
        var errors = await ValidatePrivateAccessCode(requestData, user);

        if (errors.Count > 0)
        {
            return errors;
        }

        // Validate the document and assistant
        errors = await ValidateDocumentAndAssistant(requestData);

        if (errors.Count > 0)
        {
            return errors;
        }

        // Validate the thread ID
        errors = await ValidateAssistantThread(requestData.ThreadId, token);

        if (errors.Count > 0)
        {
            return errors;
        }

        // Validate the question
        if (string.IsNullOrEmpty(requestData.Question))
        {
            errors.Add(StatusCodes.Status400BadRequest, "Question is required.");
        }

        return errors;
    }
}
