﻿using DocumentViewer.Database;
using DocumentViewer.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using WilsonNet.Services.EntityFrameworkServices.Entities;

namespace DocumentViewer.Services;

public class Repository<T>(DbContext context)
    : WilsonNet.Services.EntityFrameworkServices.Repository<T, int>(context), IRepository<T>
    where T : BaseEntity<int>, new()
{
    public override int GenerateId()
    {
        throw new System.NotImplementedException();
    }
}