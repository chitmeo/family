﻿using DocumentViewer.Database.ChatbotModels;
using DocumentViewer.Exceptions.Chatbot;
using DocumentViewer.Extensions.Common;
using DocumentViewer.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace DocumentViewer.Controllers;

[ApiController]
[Route("[controller]")]
public class ChatbotController (ILogger<ChatbotController> logger, IChatbotService chatbotService) : DocumentViewerControllerBase
{
    [HttpPost]
    [Route("question")]
    public async Task<IActionResult> SendQuestionToAssistant(
        [FromBody] ChatbotAssistantQuestion requestData,
        CancellationToken token
    )
    {
        try
        {
            var user = ChatbotUser.Map(HttpContext);

            // Validate the request data
            var validationErrors = await chatbotService.ValidateAssistantQuestion(requestData, user, token);

            if (validationErrors.Count > 0)
            {
                var validationError = validationErrors.First();
                var errResp = new ChatbotErrorResponse(validationError.Value);

                return StatusCode(validationError.Key, errResp);
            }

            // Retrieve the answer from the assistant
            var resp = await chatbotService.SendQuestionToAssistant(requestData, token);

            if (string.IsNullOrEmpty(resp.Content))
                throw new ChatbotAnswerEmptyException();

            return Ok(resp);
        }
        catch (Exception ex)
        {
            logger.LogError(
                nameof(SendQuestionToAssistant),
                "An exception occurred while sending a question to Azure OpenAI.",
                ex
            );

            var errMsg = "There was an error generating a response. Please try again later.";
            var errResp = new ChatbotErrorResponse(errMsg);

            return StatusCode(StatusCodes.Status500InternalServerError, errResp);
        }
    }
}
