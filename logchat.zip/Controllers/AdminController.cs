using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DocumentViewer.Database.AdminModels;
using DocumentViewer.Database.AdminModels.Overview;
using DocumentViewer.Database.AdminModels.Search;
using DocumentViewer.Database.AdminModels.Upsert;
using DocumentViewer.Database.ClientModels;
using DocumentViewer.Database.EntityModels;
using DocumentViewer.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Wilson.Net.Authentication.Attributes;
using Wilson.Net.Authentication.Models;
using Document = DocumentViewer.Database.EntityModels.Document;
using Group = DocumentViewer.Database.EntityModels.Group;

namespace DocumentViewer.Controllers;

[AuthorizationRequired([Roles.Content_Lead])]
[ApiController]
[Route("[controller]")]
public class AdminController(
    IDocumentService documentService,
    IGroupService groupService,
    IOverviewService overviewService,
    IAccessCodeService accessCodeService,
    IAccessCodeSecurityValueService accessCodeSecurityValueService)
    : DocumentViewerControllerBase
{
    [HttpGet, Route("GetDocument/{documentId}")]
    public async Task<Document> GetDocument(int documentId)
    {
        return await documentService.GetDocument(documentId);
    }

    [HttpPost, Route("UpsertDocument")]
    [RequestFormLimits(ValueLengthLimit = int.MaxValue, MultipartBodyLengthLimit = int.MaxValue)]
    // 100 MB limit, in bytes
    [RequestSizeLimit(100 * 1024 * 1024)]
    public async Task<int> UpsertDocument(IFormFile file, IFormFile thumbnailFile)
    {
        var upsert = new DocumentUpsert
        {
            Document = JsonConvert.DeserializeObject<Document>(Request.Form["document"]),
            Groups = JsonConvert.DeserializeObject<List<int>>(Request.Form["groups"]),
            Options = JsonConvert.DeserializeObject<List<int>>(Request.Form["options"]),
            Attachments = Request.Form.ContainsKey("attachments") ?
                JsonConvert.DeserializeObject<List<Attachment>>(Request.Form["attachments"]) : []
        };

        // Remove empty sample question
        if (upsert.Document != null)
        {
            if (!string.IsNullOrEmpty(upsert.Document.SampleQuestions))
            {
                var sampleQuestions = upsert.Document.SampleQuestions
                    .Split('|', StringSplitOptions.RemoveEmptyEntries)
                    .Select(x => x.Trim())
                    .ToArray();

                upsert.Document.SampleQuestions = String.Join('|', sampleQuestions);
            }

            if (string.IsNullOrEmpty(upsert.Document.SampleQuestions))
            {
                upsert.Document.SampleQuestions = null;
            }
        }

        return await documentService.UpsertDocument(upsert, file, thumbnailFile);
    }

    [HttpDelete, Route("DeleteDocument/{documentId}")]
    public async Task<int> DeleteDocument(int documentId)
    {
        return await documentService.DeleteDocument(documentId);
    }

    [HttpPost, Route("GetDocuments/{groupId}")]
    public async Task<List<Document>> GetDocuments(int groupId, [FromBody] Search searchModel)
    {
        return await documentService.GetDocuments(searchModel, groupId);
    }

    [HttpPost, Route("GetDocumentDirectory")]
    public async Task<DirectoryResponse<Document>> GetDocumentDirectory([FromBody] Search searchModel)
    {
        return new DirectoryResponse<Document>
        {
            Data = await documentService.GetDocuments(searchModel),
            Total = await documentService.GetCount(searchModel.AsParameters())
        };
    }

    [HttpPost, Route("UpsertGroup")]
    [RequestFormLimits(ValueLengthLimit = int.MaxValue, MultipartBodyLengthLimit = int.MaxValue)]
    // 100 MB limit, in bytes
    [RequestSizeLimit(100 * 1024 * 1024)]
    public async Task<int> UpsertGroup()
    {
        var files = Request.Form.Files;
        var group = JsonConvert.DeserializeObject<Group>(Request.Form["group"]);
        var file = files.Count > 0 ? files[0] : null;
        return await groupService.UpsertGroup(group, file);
    }

    [HttpDelete, Route("DeleteGroup/{groupId}")]
    public async Task DeleteGroup(int groupId)
    {
        await groupService.Delete(groupId);
    }

    [HttpPost, Route("SortDocumentsInGroup/{groupId}")]
    public async Task<int> SortDocumentsInGroup(int groupId, [FromBody] int[] documentIds)
    {
        return await groupService.SortDocumentsInGroup(groupId, documentIds);
    }

    [HttpPost, Route("GetGroups")]
    public async Task<List<Group>> GetGroups([FromBody] Search searchModel)
    {
        return await groupService.GetGroups(searchModel);
    }

    [HttpPost, Route("GetGroupDirectory")]
    public async Task<DirectoryResponse<Group>> GetGroupDirectory([FromBody] Search searchModel)
    {
        return new DirectoryResponse<Group>
        {
            Data = await groupService.GetGroups(searchModel),
            Total = await groupService.GetCount(searchModel.AsParameters())
        };
    }

    [HttpGet, Route("GetGroup/{groupId}")]
    public async Task<Group> GetGroup(int groupId)
    {
        return await groupService.GetGroup(groupId);
    }

    [HttpGet, Route("GetOverviewStatistics")]
    public async Task<OverviewStatistics> GetOverviewStatistics([FromQuery] bool refreshCache = false)
    {
        return await overviewService.GetOverviewStatistics(refreshCache);
    }

    [Route("GetAccessCode/{accessCodeId}"), HttpGet]
    public async Task<AccessCode> GetAccessCode(int accessCodeId)
    {
        return await accessCodeService.GetAccessCode(accessCodeId);
    }

    [HttpPost, Route("GetAccessCodeDirectory")]
    public async Task<DirectoryResponse<AccessCode>> GetAccessCodeDirectory([FromBody] Search searchModel)
    {
        return new DirectoryResponse<AccessCode>
        {
            Data = await accessCodeService.GetAccessCodes(searchModel),
            Total = await accessCodeService.GetCount(searchModel.AsParameters())
        };
    }

    [HttpPost, Route("UpsertAccessCode")]
    public async Task<int> UpsertAccessCode([FromBody] AccessCode accessCode)
    {
        return await accessCodeService.UpsertAccessCode(accessCode);
    }

    [HttpDelete, Route("DeleteAccessCode/{accessCodeId}")]
    public async Task DeleteAccessCode(int accessCodeId)
    {
        await accessCodeService.Delete(accessCodeId);
    }

    [HttpPost, Route("GetAccessCodes")]
    public async Task<List<AccessCode>> GetAccessCodes([FromBody] Search searchModel)
    {
        return await accessCodeService.GetAccessCodes(searchModel);
    }

    [HttpGet, Route("GetAccessCodeSecurityTypeValues/{securityType}/{query}")]
    public async Task<Dictionary<Guid, string>> GetAccessCodeSecurityTypeValues(string query, int securityType)
    {
        return await accessCodeSecurityValueService.SearchEntriesInType(query, securityType);
    }
}