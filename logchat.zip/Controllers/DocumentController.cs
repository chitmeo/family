using System;
using System.Linq;
using System.Threading.Tasks;
using CommunityToolkit.Diagnostics;
using DocumentViewer.Database.ClientModels;
using DocumentViewer.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace DocumentViewer.Controllers;

[ApiController]
[Route("[controller]")]
public class DocumentController(
    IGroupService groupService,
    IAccessCodeSecurityValueService accessCodeSecurityValueService,
    IDocumentService documentService)
    : DocumentViewerControllerBase
{
    [Route("GetDocumentGroupByShareCode/{codeText}/{userId}"), HttpGet, ResponseCache(Duration = ResponseCacheTimeout)]
    public async Task<ViewGroup> GetDocumentGroupByShareCode(string codeText, Guid userId)
    {
        var meta = await groupService.GetDirectorySecurityInformation(codeText);
        if (meta == null)
        {
            return null;
        }
        if (meta.RequiresUniversalLogin)
        {
            // if user is not logged in or we don't have a user id, return nothing
            if (!User.Identity.IsAuthenticated || userId == Guid.Empty)
            {
                return null;
            }

            // if any required security is missing, return nothing
            foreach (var security in meta.RequiredSecurities)
            {
                if (!await accessCodeSecurityValueService.IsUserInSecurity(userId, security.Key, security.Value))
                {
                    return null;
                }
            }
        }

        // if we make it this far, than the user is good to go
        return await groupService.GetDirectoryByAccessCode(codeText);
    }

    [Route("GetDocumentGroupSecurityMetaByShareCode/{codeText}"), HttpGet]
    public async Task<ViewGroup> GetDocumentGroupSecurityMetaByShareCode(string codeText)
    {
        return await groupService.GetDirectorySecurityInformation(codeText);
    }

    [Route("GetDocumentRenderingLink/{filePath}"), HttpGet]
    public dynamic GetDocumentRenderingLink(string filePath)
    {
        Guard.IsNotNull(filePath);
        return new { FilePath = documentService.GetAzureFileLink(filePath) };
    }

    [Route("GetDocumentForDownload/{id:int}"), HttpGet]
    public async Task<dynamic> GetDocumentForDownload(int id)
    {
        Guard.IsGreaterThan(id, 0);
        var document = await documentService.GetDocument(id, true);

        var downloadable = document.DocumentOptions.Any(o => o.DocumentOptionTypeId == 1);

        return new { FilePath = downloadable ? document.FilePath : null };
    }

    [Route("GetAnnotations/{documentId}/{userId}"), HttpGet]
    public async Task<dynamic> GetAnnotations(string documentId, string userId)
    {
        return new { Data = await documentService.GetAnnotationsFile(documentId, userId) };
    }

    [Route("SaveAnnotations/{documentId}/{userId}"), HttpPost]
    public async Task SaveAnnotations(string documentId, string userId, [FromBody] dynamic annotationsData)
    {
        await documentService.SaveAnnotationsFile(annotationsData.data.ToString(), documentId, userId);
    }
}