using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace DocumentViewer.Controllers;

[AllowAnonymous]
public class KeepAliveController : Controller
{
    // GET: /KeepAlive
    [AllowAnonymous]
    public ActionResult Index()
    {
        return Content(JsonConvert.SerializeObject(new { alive = true }));
    }
}