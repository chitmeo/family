using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WilsonNet.Services.BaseDatabaseServices.Interfaces;
using IAuthenticationService = Wilson.Net.Authentication.Services.IAuthenticationService;

namespace DocumentViewer.Controllers;

[ApiController, Route("user")]
public class UserController(IAuthenticationService authenticationService) : ControllerBase
{
    /// <summary>
    /// Sends user to login page if not authed
    /// </summary>
    /// <param name="returnUrl">Where the user will be returned to after authenticating</param>
    /// <returns>A ChallengeResult with the authentication schema to be used</returns>
    [AllowAnonymous]
    [Route("login")]
    public ActionResult LoginBff(string returnUrl = "/")
    {
        return new ChallengeResult("Auth0", new AuthenticationProperties()
        { 
            RedirectUri = returnUrl
        });
    }

    /// <summary>
    /// Logs the user out, and returns them to the RedirectUri
    /// </summary>
    /// <returns></returns>
    [Route("logout")]
    public async Task<SignOutResult> LogoutBff()
    {
        await HttpContext.SignOutAsync();

        return new SignOutResult("Auth0", new AuthenticationProperties
        {
            RedirectUri = "/"
        });
    }

    /// <summary>
    /// Gets User profile information about the logged-in user
    /// </summary>
    /// <returns>A User object representing the logged-in user</returns>
    [HttpGet]
    public IUser<string> GetUser()
    {
        return authenticationService.GetUserFromIdentityClaims<string>(User.Identity);
    }
}
