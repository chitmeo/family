using Microsoft.AspNetCore.Mvc;

namespace DocumentViewer.Controllers;

public class DocumentViewerControllerBase: ControllerBase
{
    protected const int ResponseCacheTimeout = 1800;
}