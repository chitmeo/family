using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DocumentViewer.Database.ClientModels;
using DocumentViewer.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;

namespace DocumentViewer.Controllers;

[ApiController, Route("[controller]")]
public class InitialLoadController(
    IDocumentService documentService,
    IHostEnvironment environment,
    IConfiguration config) : DocumentViewerControllerBase
{
    [HttpPost]
    [Route("GetInitialLoad")]
    public async Task<InitialLoad> GetInitialLoad()
    {
        _ = bool.TryParse(System.Environment.GetEnvironmentVariable("DOCUMENT_VIEWER_MAINTENANCE"), out var downForMaintenance);
        _ = bool.TryParse(System.Environment.GetEnvironmentVariable("DOCUMENT_VIEWER_COMING_SOON"), out var showComingSoonPage);

        var datadogToken = System.Environment.GetEnvironmentVariable("DD_ENV");
        var datadogSampleRate = config.GetSection("Datadog").GetValue<int>("SessionSampleRate").ToString();
        var datadogReplaySampleRate = config.GetSection("Datadog").GetValue<int>("SessionReplaySampleRate").ToString();
        var buildNumber = System.Environment.GetEnvironmentVariable("DOCVIEWER_BUILD_NUMBER") ?? (environment.IsProduction() ? "Production Build" : "Local Build");
        var communitiesApiKey = config["CommunitiesApiClientSecret"];
        var pdfTronWebViewerKey = config["PdfTronWebViewerLicenseKey"];

        var documentTypes = await documentService.GetDocumentTypes();
        var documentOptionTypes = await documentService.GetDocumentOptionTypes();

        var tokens = new Dictionary<string, string> {
            { "DATADOG_MONITORING_ENVIRONMENT", datadogToken },
            { "DATADOG_SAMPLE_RATE", datadogSampleRate },
            { "DATADOG_REPLAY_SAMPLE_RATE", datadogReplaySampleRate },
            { "COMMUNITIES_API_KEY", communitiesApiKey },
            { "PdfTronWebViewerKey", pdfTronWebViewerKey }
        };

        var imageLocations = config
            .GetSection("Paths:Images")
            .GetChildren()
            .ToDictionary(x => x.Key, x => x.Value);

        return new InitialLoad
        {
            IsProduction = environment.IsProduction(),
            IsDownForMaintenance = downForMaintenance,
            IsComingSoon = showComingSoonPage,
            CurrentBuildNumber = buildNumber,
            DocumentTypes = documentTypes,
            DocumentOptionTypes = documentOptionTypes,
            Tokens = tokens,
            ImageLocations = imageLocations
        };
    }
}