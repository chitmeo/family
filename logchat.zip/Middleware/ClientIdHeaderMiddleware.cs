﻿using DocumentViewer.Extensions.Common;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace DocumentViewer.Middleware;

public class ClientIdHeaderMiddleware
{
    private readonly RequestDelegate _next;

    public ClientIdHeaderMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task Invoke(HttpContext context)
    {
        if (context.User.Identity?.IsAuthenticated == true)
        {
            var clientId = context.GetContactId();

            if (clientId.HasValue)
            {
                context.Request.Headers["X-ClientId"] = clientId.ToString();
            }
        }

        await _next(context);
    }
}
