﻿using System;
using System.Diagnostics.CodeAnalysis;
using Autofac;
using Azure;
using Azure.Identity;
using Azure.AI.OpenAI.Assistants;
using DocumentViewer.Database;
using DocumentViewer.Services;
using DocumentViewer.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace DocumentViewer;

[ExcludeFromCodeCoverage]
public class DefaultModule : Module
{
    private readonly IConfiguration _configuration;

    public DefaultModule(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    protected override void Load(ContainerBuilder builder)
    {
        RegisterCommonDependencies(builder);
    }

    private void RegisterCommonDependencies(ContainerBuilder builder)
    {
        // Register AssistantsClient
        builder.RegisterInstance(new AssistantsClient(
                new Uri(_configuration.GetValue<string>("AzureOpenAI:Endpoint")),
                new DefaultAzureCredential()
            ))
            .As<AssistantsClient>()
            .SingleInstance();

        builder.RegisterGeneric(typeof(Repository<>)).As(typeof(IRepository<>)).InstancePerLifetimeScope();
        builder.RegisterType<DocViewerCollectionsContext>().As<IDocViewerCollectionsContext>().InstancePerLifetimeScope();
        
        builder.Register(c =>
        {
            var config = c.Resolve<IConfiguration>();
            var opt = new DbContextOptionsBuilder<AppDbContext>();
            opt.UseSqlServer(config.GetSection("ConnectionStrings:ApplicationContextConnectionString").Value);
            opt.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);

            return new AppDbContext(opt.Options);
        }).AsSelf().As<DbContext>().InstancePerLifetimeScope();

        builder
            // Gets every type from the assembly
            .RegisterAssemblyTypes(typeof(DefaultModule).Assembly)
            // every service in assembly is registered with 
            // all implemented interfaces it inherits
            .AsImplementedInterfaces()
            // this is equivalent to the dotnet standard "AddScoped"
            // Default would have been InstancePerDependency AKA "AddTransient"
            .InstancePerLifetimeScope()
            // any service registered before this builder will be preserved (not overwritten)
            // used to register singletons
            .PreserveExistingDefaults();
    }
}