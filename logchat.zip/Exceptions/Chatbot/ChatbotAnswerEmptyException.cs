﻿using System;

namespace DocumentViewer.Exceptions.Chatbot;

public class ChatbotAnswerEmptyException(string message = "The answer from the Chatbot is empty.") : Exception(message);