﻿using System;

namespace DocumentViewer.Exceptions.Chatbot;

public class AzureOpenAIThreadMsgException(string message = null) : Exception(message);
