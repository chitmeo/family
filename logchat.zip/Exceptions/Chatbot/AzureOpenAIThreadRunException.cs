﻿using Azure.AI.OpenAI.Assistants;
using System;

namespace DocumentViewer.Exceptions.Chatbot;

public class AzureOpenAIThreadRunException : Exception
{
    private readonly string _msg;

    public AzureOpenAIThreadRunException(ThreadRun threadRun)
        : base("An exception occurred while the assistant was answering a question.")
    {
        _msg = threadRun.LastError?.Message;
    }

    public override string Message => !string.IsNullOrEmpty(_msg) ? _msg : base.Message;
}
