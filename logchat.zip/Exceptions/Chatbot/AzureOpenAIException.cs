﻿using System;

namespace DocumentViewer.Exceptions.Chatbot;

public class AzureOpenAIException(string message = null) : Exception(message);
