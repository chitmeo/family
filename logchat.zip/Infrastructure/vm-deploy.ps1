<#
.SYNOPSIS
    This script will create a Windows server with IIS for hosting .Net Core 3.1 apps
    It was originally created for Document Viewer but can be easily modified to support 
    different variations of OS, drives, dependencies etc
#>

param(
    [Parameter(Mandatory=$true)] [string] $subscription,
    [Parameter(Mandatory=$true)] [string] $resourceGroup,
    [Parameter(Mandatory=$true)] [string] $appName,
    [Parameter(Mandatory=$true)] [string] $adminPass,
    [Parameter(Mandatory=$true)] [string] $vmSize,
    [Parameter(Mandatory=$true)] [string] $backupVault
)

# Set subscription for deployment
az account set --subscription $subscription

# Create VM
az vm create `
    --resource-group $resourceGroup `
    --name $appName `
    --image win2019datacenter `
    --admin-username zues `
	--admin-password $adminpass `
    --size $vmSize

# Delete auto-created rdp rule for security
az network nsg rule delete `
    --resource-group $resourceGroup `
    --nsg-name $($appName +'NSG') `
    --name 'rdp'

# Create, initialize and format data disk
az vm disk attach `
    --resource-group $resourceGroup `
    --vm-name $appName `
    --name $($appName + '-DataDisk') `
    --size-gb 10 `
    --sku Premium_LRS `
    --new

az vm run-command invoke  --command-id RunPowerShellScript --name $appName -g $resourceGroup `
    --scripts "Get-Disk | Where partitionstyle -eq 'raw' | Initialize-Disk -PartitionStyle MBR -PassThru | New-Partition -DriveLetter F -UseMaximumSize | Format-Volume -FileSystem NTFS -NewFileSystemLabel data"

# Create, initialize and format cache disk
az vm disk attach `
    --resource-group $resourceGroup `
    --vm-name $appName `
    --name $($appName + '-CacheDisk') `
    --size-gb 200 `
    --sku StandardSSD_LRS `
    --new

az vm run-command invoke  --command-id RunPowerShellScript --name $appName -g $resourceGroup `
    --scripts "Get-Disk | Where partitionstyle -eq 'raw' | Initialize-Disk -PartitionStyle MBR -PassThru | New-Partition -DriveLetter Z -UseMaximumSize | Format-Volume -FileSystem NTFS -NewFileSystemLabel cache"

# Install IIS and dependencies
az vm run-command invoke  --command-id RunPowerShellScript --name $appName -g $resourceGroup `
    --scripts 'Install-WindowsFeature Web-Server -IncludeManagementTools' `
    'Install-WindowsFeature Web-Asp-Net45,NET-Framework-Features' `
    'Invoke-WebRequest https://download.visualstudio.microsoft.com/download/pr/cc28204e-58d7-4f2e-9539-aad3e71945d9/d4da77c35a04346cc08b0cacbc6611d5/dotnet-sdk-3.1.406-win-x64.exe -outfile $env:temp\dotnet-SDK.exe' `
    'Start-Process $env:temp\dotnet-SDK.exe -ArgumentList '/quiet' -Wait' `
    'Invoke-WebRequest https://download.visualstudio.microsoft.com/download/pr/19a5a3cc-b297-4a10-9b22-1184a0aeb990/5af443d748d2c5fb444477f202a11470/dotnet-hosting-3.1.12-win.exe -outfile $env:temp\DotNetCore.WindowsHosting.exe' `
    'Start-Process $env:temp\DotNetCore.WindowsHosting.exe -ArgumentList '/quiet' -Wait' `
    'Stop-Service was -Force' `
    'Start-Service w3svc'

# Open web ports
az network nsg rule create `
    --resource-group $resourceGroup `
    --nsg-name $($appName +'NSG') `
    --name allow_80 `
    --protocol tcp `
    --priority 500 `
    --destination-port-range 80

az network nsg rule create `
    --resource-group $resourceGroup `
    --nsg-name $($appName +'NSG') `
    --name allow_443 `
    --protocol tcp `
    --priority 501 `
    --destination-port-range 443

# Add DNS label to public IP
az network public-ip update `
    --resource-group $resourceGroup `
    --name $($appName + 'PublicIP') `
    --dns-name $appName `
    --allocation-method Static

# Add backup protection
az backup protection enable-for-vm `
    --resource-group $resourceGroup `
    --vault-name $backupVault `
    --vm $(az vm show -g $resourceGroup -n $appName --query id) `
    --policy-name DefaultPolicy

# Add Delete lock to the VM
az lock create --name $($appName +'-lock') `
    --lock-type CanNotDelete `
    --resource-group $resourceGroup `
    --resource-name $appName `
    --resource-type Microsoft.Compute/virtualMachines

# Add Delete lock to the network security group
az lock create --name $($appName +'NSG-lock') `
    --lock-type CanNotDelete `
    --resource-group $resourceGroup `
    --resource-name $($appName +'NSG') `
    --resource-type Microsoft.Network/networkSecurityGroups

az vm identity assign --resource-group $resourceGroup --name $appName

### MANUALL STEPS NEEDED ###
# Create IIS site
# Apply SSL cert
# Add to DevOps deployment group