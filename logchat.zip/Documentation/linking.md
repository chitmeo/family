# Linking

This documentation is to provide clarification on linking to groups and documents.

## Auto-Login for Iframe & Cross-Site Linking

A few things to keep in mind for linking with both iframes and cross-site functionalities:

- URL must contain an `accessCode` parameter in order to attempt auto-login.
- If "Allow anonymous entry" is checked off for the access code, no other parameters are required for login.
- If "Require Community," "Require Training," or "Require Training Template" are checked off, the user will need to be coming from a site with an active Auth0 session with the appropriate access to the community, training, or template respectively.

_See also:_ [Other Available Parameters](#other-available-parameters)

## Iframe (Deprecated)

This feature is no longer supported due to issues with authentication through an iframe, however it will remain in the code base to support any links that get missed or any one-off cases that may require the use of the iframe funnel.

### Usage

Accessing a document using the iframe funnel lets you to iframe in an entire document viewer page anywhere you want without the standard page chrome, allowing you to display the content you want virtually anywhere.

#### URL Shape

SAMPLE: https://docs.wilsonacademy.com/login?accessCode=testcode&iframe=true

- **accessCode:** Provide an access code to the target group or document.
- **iframe:** Set this parameter to true if you wish to use the iframe funnel. `iframe=false` is not ever necessary to use as it is assumed in the absence of `iframe=true`.

## Cross-Site (XSite)

The cross-site funnel was built to take the place of the iframe funnel's functionality due to the authentication issues it came along with.

### Usage

Accessing a document using the xsite funnel allows the user to link to a group or document and, with the correct parameters, link the user to any DocViewer page with a header that follows the same styling/theming from the origin site. This option allows us to avoid authentication issues with iframing the Document Viewer, while helping the user both not lose their place as well as feel like they are on the same page.

#### URL Shape

SAMPLE FUN HUB: https://docs.wilsonacademy.com/login?accessCode=TESTCODE&xSite=1&programId=hub-1&title=Fun%20Hub&reg=1&return=https://community.wilsonacademy.com/hub-1
SAMPLE COMMUNITY: https://hydra.wilsonacademy.com:5001/login?accessCode=TESTCODE&xSite=1&programId=fundations-1&title=Fundations%20Level%201&subtitle=Learning%20Community&return=https://community.wilsonacademy.com/fundations-1

- **accessCode:** Provide an access code to the target group or document.
- **xSite:** Set this parameter to `1` if you wish to use the xsite funnel. `xSite=0` is not necessary to use as it is assumed in the absence of `xSite=1`.
- **return:** The exact URL you wish the user to return to. If no URL is passed, https://wilsonacademy.com will be used.
- **programId:** Use this parameter to set the theme colors in the heading as well as the icon. Accepted program strings are as follows:
  - Fundations Level Pre-K: `fundations-pre-k`
  - Fundations Level K: `fundations-k` or `hub-k` for FunHub
  - Fundations Level 1: `fundations-1` or `hub-1` for FunHub
  - Fundations Level 2: `fundations-2` or `hub-2` for FunHub
  - Fundations Level 3: `fundations-3` or `hub-3` for FunHub
  - Fundations Ready to Rise: `fundations`
  - Just Words: `just-words`
  - Wilson Reading System: `wilson-reading-system`
  - Administrator: `admin`
- **title**: The primary (bold) portion of the header text.
- **subtitle**: The secondary (light) portion of the header text.
- **reg**: Set this parameter to `1` if your heading requires a registered trademark symbol.

## Other Available Parameters

Below are some additional parameters and their functionality that are available to use:

- Annotations: To allow/enable annotations, the parameter `ano=1` is used.
- Table of Contents: To show the table of contents on document load, the parameter `toc=1` is used.
- Document in Group: If the `accessCode` you are using is for a document group, you can load a specific document within that group simply by utilizing the `documentId` parameter and setting it equal to the ID of the target document.
- Document Page: To link directly to a specific page within a document, the parameter `documentPage` is used and set to the desired page number. Note that page offsets are set on the admin-side, if a document's page 1 is anything other than the actual first page of the file.
- Login Form: If you wish to pass in the user's details outside of an auth0 login, you can use `userName`, `userEmail`, `userSchool`, and `terms` in addition to `accessCode` to prefill the login form and auto-login the user.
