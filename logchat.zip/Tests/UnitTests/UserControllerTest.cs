using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;
using DocumentViewer.Controllers;
using DocumentViewer.Database.ClientModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Wilson.Net.Authentication.Services;
using Xunit;

namespace UnitTests;

public class UserControllerTest
{
    private readonly UserController _userController;
    private readonly User _user =
        new("123", "Michael Scott", "mscott@wilsonlanguage.com")
            { Id = "000", AuthId = "456", Roles = new List<string> { "00", "01", "02" } };
    private readonly Mock<IAuthenticationService> _mockAuthenticationService = new();

    public UserControllerTest()
    {
        _mockAuthenticationService
            .Setup(service => service.GetUserFromIdentityClaims<string>(It.IsAny<IIdentity>()))
            .Returns(_user);
        var httpContext = new DefaultHttpContext();
        _userController = new UserController(_mockAuthenticationService.Object)
        {
            ControllerContext = new ControllerContext()
            {
                HttpContext = httpContext
            }
        };
    }

    [Fact]
    public void LoginBFF_ReturnsChallengeResult()
    {
        var result = _userController.LoginBff();
        Assert.IsType<ChallengeResult>(result);
    }

    [Fact]
    public void LogoutBFF_ReturnsSignOutResult()
    {
        var result = _userController.LogoutBff();
        Assert.IsType<Task<SignOutResult>>(result);
    }

    [Fact]
    public void GetUser_ReturnsUserObjectIfAuthenticated()
    {
        var user = new ClaimsPrincipal(new ClaimsIdentity(new[]
        {
            new Claim("name", "Cool Dude")
        }, "someAuthTypeName"));
        _userController.ControllerContext.HttpContext.User = user;
        var result = _userController.GetUser();
        Assert.Equal(result.Name, _user.Name);
    }
}