using System.Threading.Tasks;
using DocumentViewer.Database;
using DocumentViewer.Services;
using DocumentViewer.Services.Interfaces;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace UnitTests;

public class OverviewServiceTest
{
    private IOverviewService Service;
    private TestAppDbContext DbContext;
    private SqliteConnection Connection;
    private Mock<ILogger<TestAppDbContext>> MockLogger;

    [Fact]
    public async Task GetOverviewStatistics_ReturnsOverviewStatisticsObject()
    {
        OpenConnection();
        try
        {
            SetupDbContext();
            SetupService();
            var overviewResult = await Service.GetOverviewStatistics(true);
            // Document Statistics
            Assert.Equal(25, overviewResult.DocumentStatistics.Total);
            Assert.Equal(1, overviewResult.DocumentStatistics.TotalUnassigned);

            // Access Code Statistics
            Assert.Equal(5, overviewResult.AccessCodeStatistics.Total);
            Assert.Equal(3, overviewResult.AccessCodeStatistics.TotalSecure);
            Assert.Equal(2, overviewResult.AccessCodeStatistics.TotalUnsecure);

            // Group Statistics
            Assert.Equal(5, overviewResult.GroupStatistics.Total);
            Assert.Equal(1, overviewResult.GroupStatistics.TotalWithoutAccessCodes);
            Assert.Equal(1, overviewResult.GroupStatistics.TotalWithoutDocuments);
        }
        finally
        {
            CloseConnection();
        }
    }

    private void SetupService()
    {
        Service = new OverviewService(DbContext);
    }

    private void OpenConnection()
    {
        Connection = new SqliteConnection("DataSource=:memory:");
        Connection.Open();
    }

    private void CloseConnection()
    {
        Connection.Close();
    }

    private void SetupDbContext()
    {
        var options = new DbContextOptionsBuilder<TestAppDbContext>()
            .UseSqlite(Connection)
            .Options;
        MockLogger = new Mock<ILogger<TestAppDbContext>>();
        DbContext = new TestAppDbContext(options, MockLogger.Object);
        DbContext.Database.EnsureCreated();
    }
}