using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using DocumentViewer.Database.AcademyModels;
using DocumentViewer.Services;
using DocumentViewer.Services.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using Xunit;

namespace UnitTests;

public class AccessCodeSecurityValueServiceTest
{
    private List<Community> Communities;
    private IConfigurationRoot MockEnvironment;
    private IAccessCodeSecurityValueService Service;
    private Mock<IHttpClientFactory> MockClientFactory;
    private Mock<ILogger<AccessCodeSecurityValueService>> MockLogger;

    [Fact]
    public async Task SearchEntriesInType_ReturnsDictionaryOfEntries()
    {
        // Arrange
        SetupMockData();
        var mockMessageHandler = new Mock<HttpMessageHandler>();
        mockMessageHandler.Protected()
            .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(JsonConvert.SerializeObject(Communities))
            });

        var httpClient = new HttpClient(mockMessageHandler.Object);
        MockClientFactory.Setup(_ => _.CreateClient(It.IsAny<string>())).Returns(httpClient);
        Service = new AccessCodeSecurityValueService(MockClientFactory.Object, MockEnvironment, MockLogger.Object);

        // Act
        var entryResult = await Service.SearchEntriesInType("Cool", 1);

        // Assert
        Assert.False(entryResult.ContainsKey(new Guid("a495feea-261c-4bbd-87bc-07f3b65d7c32")));
        Assert.True(entryResult.ContainsKey(new Guid("242a7f8e-d124-4614-ba03-8000542c4c7c")));
    }

    [Fact]
    public async Task SearchEntryById_ReturnsMatchingEntry()
    {
        // Arrange
        SetupMockData();
        var mockMessageHandler = new Mock<HttpMessageHandler>();
        mockMessageHandler.Protected()
            .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(JsonConvert.SerializeObject(Communities))
            });

        var client = new HttpClient(mockMessageHandler.Object);
        MockClientFactory.Setup(_ => _.CreateClient(It.IsAny<string>())).Returns(client);
        Service = new AccessCodeSecurityValueService(MockClientFactory.Object, MockEnvironment, MockLogger.Object);

        // Act
        var idResult = await Service.SearchEntryById(Communities[0].Id.ToString(), 1);

        // Assert
        Assert.Equal(Communities[0].Id, idResult.Key);
        Assert.Equal(Communities[0].Name, idResult.Value);
    }

    [Fact]
    public async Task IsUserInSecurity_ReturnsBool()
    {
        // Arrange
        SetupMockData();
        var userId = new Guid("a495feea-261c-4bbd-87bc-07f3b65d7c32");
        var mockMessageHandler = new Mock<HttpMessageHandler>();
        mockMessageHandler.Protected()
            .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(JsonConvert.SerializeObject(true))
            });

        var client = new HttpClient(mockMessageHandler.Object);
        MockClientFactory.Setup(_ => _.CreateClient(It.IsAny<string>())).Returns(client);
        Service = new AccessCodeSecurityValueService(MockClientFactory.Object, MockEnvironment, MockLogger.Object);

        // Act
        var userResult = await Service.IsUserInSecurity(userId, 1, Communities[0].Id.ToString());

        // Assert
        Assert.True(userResult);
    }

    private void SetupMockData()
    {
        MockClientFactory = new Mock<IHttpClientFactory>();
        MockLogger = new Mock<ILogger<AccessCodeSecurityValueService>>();

        Communities = new List<Community>
        {
            new Community {
                Id = new Guid("242a7f8e-d124-4614-ba03-8000542c4c7c"),
                Name = "Cool Community",
                Code = "Community Code"
            }
        };

        var envConfiguration = new Dictionary<string, string>
        {
            { "AcademyApi:BaseUrl", "https://dev-api.wilsonacademy.com/api/1.0" },
            { "AcademyApiSecretKey", "secret-oooooh"}
        };

        MockEnvironment = new ConfigurationBuilder()
            .AddInMemoryCollection(envConfiguration)
            .Build();
    }
}