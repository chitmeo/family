using System.Collections.Generic;
using System.Threading.Tasks;
using DocumentViewer.Controllers;
using DocumentViewer.Database.AdminModels.Search;
using DocumentViewer.Database.AdminModels.Upsert;
using DocumentViewer.Database.EntityModels;
using DocumentViewer.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using Moq;
using Newtonsoft.Json;
using WilsonNet.Services.BaseDatabaseServices.Models;
using Xunit;
using Filter = DocumentViewer.Database.AdminModels.Search.Filter;

namespace UnitTests;

public class AdminDocumentControllerTest
{
    #region properties

    private int DocumentId;
    private int GroupId;
    private int AccessCodeId;
    private Group EfGroup;
    private List<Group> EfGroupList;
    private Search SearchModel;
    private Document EFDocument;
    private List<Document> EfDocumentList;
    private DocumentViewer.Database.AdminModels.Overview.OverviewStatistics OverviewStatistics;
    private AccessCode EFAccessCode;
    private List<AccessCode> EFAccessCodeList;
    private Mock<IDocumentService> MockDocumentService;
    private Mock<IGroupService> MockGroupService;
    private Mock<IOverviewService> MockOverviewService;
    private Mock<IAccessCodeService> MockAccessCodeService;
    private Mock<IAccessCodeSecurityValueService> MockAccessCodeSecurityValueService;

    #endregion

    #region Document

    [Fact]
    public async Task GetDocument_ReturnsSingleDocument()
    {
        // Arrange data
        SetupMockData();

        // Arrange services
        CreateMockServices();
        MockDocumentService
            .Setup(service => service.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .Returns(Task.FromResult(EFDocument));
        var controller = CreateController();

        // Act
        var result = await controller.GetDocument(DocumentId);

        // Assert
        MockDocumentService.Verify(service => service.GetDocument(It.IsAny<int>(), It.IsAny<bool>()), Times.Exactly(1));
        Assert.Equal(EFDocument, result);
    }

    [Fact]
    public async Task UpsertDocument_UpsertsThenReturnsDocumentId()
    {
        // Arrange data
        SetupMockData();

        // Arrange services
        CreateMockServices();
        MockDocumentService
            .Setup(service =>
                service.UpsertDocument(It.IsAny<DocumentUpsert>(), It.IsAny<IFormFile>(), It.IsAny<IFormFile>()))
            .Returns(Task.FromResult(DocumentId));
        var controller = CreateController();

        var httpContext = new DefaultHttpContext();
        var formFields = new FormCollection(new Dictionary<string, StringValues>
        {
            { "document", JsonConvert.SerializeObject(EfDocumentList[0]) },
            { "groups", JsonConvert.SerializeObject(new List<int> { 1, 2, 3 }) },
            { "options", JsonConvert.SerializeObject(new List<int> { 1, 2 }) },
            { "attachments", JsonConvert.SerializeObject(new List<DocumentViewer.Database.ClientModels.Attachment>()) }
        });
        httpContext.Request.Form = formFields;
        controller.ControllerContext = new ControllerContext
        {
            HttpContext = httpContext
        };

        var upsertForm = new DocumentUpsert
        {
            Document = EfDocumentList[0],
            Attachments = [],
            Groups = [1, 2, 3],
            Options = [1, 2]
        };

        // Act
        var result = await controller.UpsertDocument(null, null);

        // Assert
        MockDocumentService.Verify(
            service => service.UpsertDocument(
                It.Is<DocumentUpsert>(u => u.Document.Id.Equals(upsertForm.Document.Id)), It.IsAny<IFormFile>(),
                It.IsAny<IFormFile>()), Times.Exactly(1));
        Assert.Equal(DocumentId, result);
    }

    [Fact]
    public async Task DeleteDocument_DeletesThenReturnsDocumentId()
    {
        // Arrange data
        SetupMockData();

        // Arrange services
        CreateMockServices();
        MockDocumentService
            .Setup(service => service.Delete(It.IsAny<int>(), null))
            .Returns(Task.FromResult(DocumentId));

        EFDocument.AllowAdminDelete = true;

        MockDocumentService
            .Setup(service => service.DeleteDocument(It.IsAny<int>()))
            .Returns(Task.FromResult(DocumentId));

        var controller = CreateController();

        // Act
        var result = await controller.DeleteDocument(DocumentId);

        // Assert
        MockDocumentService.Verify(service => service.DeleteDocument(It.IsAny<int>()), Times.Exactly(1));
        Assert.Equal(DocumentId, result);
    }

    [Fact]
    public async Task DeleteDocument_DoesNotDeleteWhenNotAllowed()
    {
        // Arrange data
        SetupMockData();

        // Arrange services
        CreateMockServices();
        MockDocumentService
            .Setup(service => service.Delete(It.IsAny<int>(), null))
            .Returns(Task.FromResult(DocumentId));

        EFDocument.AllowAdminDelete = false;

        MockDocumentService
            .Setup(service => service.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .Returns(Task.FromResult(EFDocument));

        var controller = CreateController();

        // Act
        var result = await controller.DeleteDocument(DocumentId);

        // Assert
        MockDocumentService.Verify(service => service.Delete(It.IsAny<int>(), null), Times.Exactly(0));
        Assert.Equal(0, result);
    }

    [Fact]
    public async Task GetDocuments_ReturnsListOfDocuments()
    {
        // Arrange data
        SetupMockData();

        // Arrange services
        CreateMockServices();
        MockDocumentService
            .Setup(service => service.GetDocuments(It.IsAny<Search>(), It.IsAny<int>()))
            .Returns(Task.FromResult(EfDocumentList));
        var controller = CreateController();

        // Act
        _ = await controller.GetDocuments(5, SearchModel);

        // Assert
        MockDocumentService.Verify(service => service.GetDocuments(It.IsAny<Search>(), It.IsAny<int>()),
            Times.Exactly(1));
        Assert.Single(EfDocumentList);
    }

    #endregion

    #region Group

    [Fact]
    public async Task UpsertGroup_UpsertsThenReturnsId()
    {
        // Arrange data
        SetupMockData();

        // Arrange services
        CreateMockServices();
        MockGroupService
            .Setup(service => service.UpsertGroup(It.IsAny<Group>(), It.IsAny<IFormFile>()))
            .Returns(Task.FromResult(GroupId));
        var controller = CreateController();

        var httpContext = new DefaultHttpContext();
        var formFields = new FormCollection(new Dictionary<string, StringValues>
        {
            { "group", JsonConvert.SerializeObject(EfGroup) }
        });
        httpContext.Request.Form = formFields;
        controller.ControllerContext = new ControllerContext
        {
            HttpContext = httpContext
        };

        // Act
        var result = await controller.UpsertGroup();

        // Assert
        MockGroupService.Verify(service => service.UpsertGroup(It.IsAny<Group>(), It.IsAny<IFormFile>()),
            Times.Exactly(1));
        Assert.Equal(GroupId, result);
    }

    [Fact]
    public async Task DeleteGroup_DeletesThenReturnsId()
    {
        // Arrange data
        SetupMockData();

        // Arrange services
        CreateMockServices();
        MockGroupService
            .Setup(service => service.Delete(It.IsAny<int>(), null))
            .Returns(Task.FromResult(GroupId));
        var controller = CreateController();

        // Act
        await controller.DeleteGroup(GroupId);

        // Assert
        MockGroupService.Verify(service => service.Delete(It.IsAny<int>(), null), Times.Exactly(1));
    }

    [Fact]
    public async Task SortDocumentsInGroup_ReturnsId()
    {
        // Arrange data
        SetupMockData();

        // Arrange services
        CreateMockServices();
        MockGroupService
            .Setup(service => service.SortDocumentsInGroup(It.IsAny<int>(), It.IsAny<int[]>()))
            .Returns(Task.FromResult(GroupId));
        var controller = CreateController();

        // Act
        var result = await controller.SortDocumentsInGroup(GroupId, new int[] { DocumentId });

        // Assert
        MockGroupService.Verify(service => service.SortDocumentsInGroup(It.IsAny<int>(), It.IsAny<int[]>()),
            Times.Exactly(1));
        Assert.Equal(result, GroupId);
    }

    [Fact]
    public async Task GetGroups_ReturnsListOfGroups()
    {
        // Arrange data
        SetupMockData();

        // Arrange services
        CreateMockServices();
        MockGroupService
            .Setup(service => service.GetGroups(It.IsAny<Search>()))
            .Returns(Task.FromResult(EfGroupList));
        var controller = CreateController();

        // Act
        var result = await controller.GetGroups(SearchModel);

        // Assert
        MockGroupService.Verify(service => service.GetGroups(It.IsAny<Search>()), Times.Exactly(1));
        Assert.Single(result);
    }

    [Fact]
    public async Task GetGroup_ReturnsSingleGroup()
    {
        // Arrange data
        SetupMockData();

        // Arrange services
        CreateMockServices();
        MockGroupService
            .Setup(service => service.GetGroup(It.IsAny<int>()))
            .Returns(Task.FromResult(EfGroup));

        var controller = CreateController();

        // Act
        var result = await controller.GetGroup(GroupId);

        // Assert
        MockGroupService.Verify(service => service.GetGroup(It.IsAny<int>()), Times.Exactly(1));
        Assert.Equal(EfGroup, result);
    }

    #endregion

    #region Access Code

    [Fact]
    public async Task GetAccessCode_ReturnsSingleAccessCode()
    {
        // Arrange data
        SetupMockData();

        // Arrange services
        CreateMockServices();
        MockAccessCodeService
            .Setup(service => service.GetAccessCode(It.IsAny<int>()))
            .Returns(Task.FromResult(EFAccessCode));
        var controller = CreateController();

        // Act
        var result = await controller.GetAccessCode(AccessCodeId);

        // Assert
        MockAccessCodeService.Verify(service => service.GetAccessCode(It.IsAny<int>()), Times.Exactly(1));
        Assert.Equal(EFAccessCode, result);
    }

    [Fact]
    public async Task UpsertAccessCode_UpsertsThenReturnsAccessCodeId()
    {
        // Arrange data
        SetupMockData();

        // Arrange services
        CreateMockServices();
        MockAccessCodeService
            .Setup(service => service.UpsertAccessCode(It.IsAny<AccessCode>()))
            .Returns(Task.FromResult(AccessCodeId));
        var controller = CreateController();

        // Act
        var result = await controller.UpsertAccessCode(EFAccessCodeList[0]);

        // Assert
        MockAccessCodeService.Verify(service => service.UpsertAccessCode(It.IsAny<AccessCode>()), Times.Exactly(1));
        Assert.Equal(AccessCodeId, result);
    }

    [Fact]
    public async Task DeleteAccessCode_DeletesThenReturnsAccessCodeId()
    {
        // Arrange data
        SetupMockData();

        // Arrange services
        CreateMockServices();
        MockAccessCodeService
            .Setup(service => service.Delete(It.IsAny<int>(), null))
            .Returns(Task.FromResult(AccessCodeId));
        var controller = CreateController();

        // Act
        await controller.DeleteAccessCode(AccessCodeId);

        // Assert
        MockAccessCodeService.Verify(service => service.Delete(It.IsAny<int>(), null), Times.Exactly(1));
    }

    [Fact]
    public async Task GetAccessCodes_ReturnsListOfAccessCodes()
    {
        // Arrange data
        SetupMockData();

        // Arrange services
        CreateMockServices();
        MockAccessCodeService
            .Setup(service => service.GetAccessCodes(It.IsAny<Search>()))
            .Returns(Task.FromResult(EFAccessCodeList));
        var controller = CreateController();

        // Act
        var result = await controller.GetAccessCodes(SearchModel);

        // Assert
        MockAccessCodeService.Verify(service => service.GetAccessCodes(It.IsAny<Search>()), Times.Exactly(1));
        Assert.Single(result);
    }

    #endregion

    #region Overview

    [Fact]
    public async Task GetOverviewStatistics_ReturnsOverviewStatisticsObject()
    {
        // Arrange data
        SetupMockData();

        // Arrange services
        CreateMockServices();
        MockOverviewService
            .Setup(service => service.GetOverviewStatistics(It.IsAny<bool>()))
            .Returns(Task.FromResult(OverviewStatistics));
        var controller = CreateController();

        // Act
        var result = await controller.GetOverviewStatistics(true);

        // Assert
        MockOverviewService.Verify(service => service.GetOverviewStatistics(It.IsAny<bool>()), Times.Exactly(1));
        Assert.Equal(OverviewStatistics, result);
    }

    #endregion

    #region setup

    private void SetupMockData()
    {
        DocumentId = 123;
        GroupId = 555;
        AccessCodeId = 3854;
        SearchModel = new Search
        {
            Filters =
            [
                new Filter
                {
                    Column = "Name",
                    Value = "TestVal",
                    FilterType = FilterTypeDefinition.Contains
                }
            ]
        };
        EFDocument = new Document
        {
            Id = DocumentId
        };
        EfDocumentList = [EFDocument];
        EfGroup = new Group
        {
            Id = GroupId,
            Title = "Test Group Title"
        };
        EfGroupList = [EfGroup];
        
        EFAccessCode = new AccessCode
        {
            Id = AccessCodeId
        };
        EFAccessCodeList = [EFAccessCode];
        OverviewStatistics = new DocumentViewer.Database.AdminModels.Overview.OverviewStatistics
        {
            DocumentStatistics = new DocumentViewer.Database.AdminModels.Overview.DocumentStatistics(),
            GroupStatistics = new DocumentViewer.Database.AdminModels.Overview.GroupStatistics(),
            AccessCodeStatistics = new DocumentViewer.Database.AdminModels.Overview.AccessCodeStatistics(),
            OverviewLastCalculated = System.DateTime.Now
        };
    }

    private void CreateMockServices()
    {
        MockDocumentService = new Mock<IDocumentService>();
        MockGroupService = new Mock<IGroupService>();
        MockOverviewService = new Mock<IOverviewService>();
        MockAccessCodeService = new Mock<IAccessCodeService>();
        MockAccessCodeSecurityValueService = new Mock<IAccessCodeSecurityValueService>();
    }

    private AdminController CreateController()
    {
        return new AdminController(
            MockDocumentService.Object,
            MockGroupService.Object,
            MockOverviewService.Object,
            MockAccessCodeService.Object,
            MockAccessCodeSecurityValueService.Object);
    }

    #endregion
}