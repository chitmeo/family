using System;
using System.Security.Claims;
using System.Threading.Tasks;
using DocumentViewer.Controllers;
using DocumentViewer.Database.ClientModels;
using DocumentViewer.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace UnitTests;

public class DocumentControllerTest
{
    private ViewGroup _documentGroup;
    private readonly Mock<IDocumentService> _mockDocumentService = new();
    private readonly Mock<IGroupService> _mockGroupService = new();
    private readonly Mock<IAccessCodeSecurityValueService> _mockAccessCodeSecurityValueService = new();

    [Fact]
    public async Task GetDocumentGroupByShareCode_returnsDocumentGroup()
    {
        // Arrange data
        SetupMockData();

        // Arrange services
        _mockGroupService
            .Setup(service => service.GetDirectoryByAccessCode(It.IsAny<string>()))
            .Returns(Task.FromResult(_documentGroup));

        _mockGroupService
            .Setup(service => service.GetDirectorySecurityInformation(It.IsAny<string>()))
            .Returns(Task.FromResult(_documentGroup));

        _mockAccessCodeSecurityValueService.Setup(service => service.IsUserInSecurity(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<string>()))
            .Returns(Task.FromResult(true));
        var controller = new DocumentController(_mockGroupService.Object, _mockAccessCodeSecurityValueService.Object, _mockDocumentService.Object);

        // Act
        var result = await controller.GetDocumentGroupByShareCode(_documentGroup.CodeText, Guid.NewGuid());

        // Assert
        _mockGroupService.Verify(service => service.GetDirectoryByAccessCode(It.IsAny<string>()), Times.Exactly(1));
        Assert.Equal(_documentGroup, result);
    }

    [Fact]
    public async Task GetDocumentGroupByShareCode_returnsNullWhenNotAuthed()
    {
        // Arrange data
        SetupMockData();
        var dg = new ViewGroup
        {
            Id = 123,
            CodeText = "An Extremely Important Code",
            Title = "Some Title",
            Description = "Some cool description",
            AllowAnonymousEntry = false,
            RequiresUniversalLogin = true,
            Documents = null
        };

        // Arrange services
        _mockGroupService
            .Setup(service => service.GetDirectoryByAccessCode(It.IsAny<string>()))
            .Returns(Task.FromResult(dg));

        _mockGroupService
            .Setup(service => service.GetDirectorySecurityInformation(It.IsAny<string>()))
            .Returns(Task.FromResult(dg));

        _mockAccessCodeSecurityValueService.Setup(service => service.IsUserInSecurity(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<string>()))
            .Returns(Task.FromResult(true));
        var controller = new DocumentController(_mockGroupService.Object, _mockAccessCodeSecurityValueService.Object, _mockDocumentService.Object)
        {
            ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    // Passing "null" as the authenticationType here creates a user with isAuthenticated set to FALSE
                    User = new ClaimsPrincipal(new ClaimsIdentity(new[]
                    {
                        new Claim("name", "Cool Dude")
                    }, null))
                }
            }
        };

        // Act
        var result = await controller.GetDocumentGroupByShareCode(dg.CodeText, Guid.NewGuid());

        // Assert
        _mockGroupService.Verify(service => service.GetDirectoryByAccessCode(It.IsAny<string>()), Times.Never());
        _mockAccessCodeSecurityValueService.Verify(service => service.IsUserInSecurity(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<string>()), Times.Never());
        Assert.Null(result);
    }

    private void SetupMockData()
    {
        _documentGroup = new ViewGroup
        {
            Id = 123,
            CodeText = "An Extremely Important Code",
            Title = "Some Title",
            Description = "Some cool description",
            AllowAnonymousEntry = false,
            RequiresUniversalLogin = false,
            Documents =
            [
                new ViewDocument
                {
                    Id = 123,
                    Title = "Document 1 Title",
                    Description = "This is the description for Document 1",
                    ThumbnailUrl =
                        "https://en.wikipedia.org/wiki/Owl#/media/File:Eastern_Barn_Owl_(Tyto_javanica_stertens),_Raigad,_Maharashtra.jpg",
                    FilePath = "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf",
                    Ordinal = 0
                }
            ]
        };
    }
}