﻿using Azure;
using Azure.AI.OpenAI.Assistants;
using Azure.Messaging;
using DocumentViewer.Database.AdminModels.Upsert;
using DocumentViewer.Database.ChatbotModels;
using DocumentViewer.Database.ClientModels;
using DocumentViewer.Database.EntityModels;
using DocumentViewer.Exceptions.Chatbot;
using DocumentViewer.Services;
using DocumentViewer.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.Amqp.Framing;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.VisualStudio.TestPlatform.PlatformAbstractions.Interfaces;
using Moq;
using Newtonsoft.Json;
using SendGrid.Helpers.Mail;
using System;
using System.ClientModel.Primitives;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace UnitTests;

public class ChatbotServiceTest
{
    #region Properties
    private Mock<Response> MockResponse;
    private Mock<IAzureAssistantsService> MockAzureAssistantsService;
    private Mock<IGroupService> MockGroupService;
    private Mock<IAccessCodeSecurityValueService> MockAccessCodeSecurityValueService;
    private Mock<IDocumentService> MockDocumentService;
    private IChatbotService Service;
    #endregion

    #region SendQuestionToAssistant
    [Fact]
    public async Task SendQuestionToAssistant_ThreadEmpty_RunFailed()
    {
        SetupService();
        SetupAzureAssistants();

        var requestData = CreateChatbotAssistantQuestion();
        var thread = CreateAssistantThread();
        var threadMsg = CreateThreadMessage();
        var document = CreateDocument();
        var threadRunProgress = CreateThreadRun(RunStatus.InProgress);
        var threadRunFailed = CreateThreadRun(RunStatus.Failed);

        MockAzureAssistantsService
           .Setup(x => x.CreateThreadAsync(It.IsAny<CancellationToken>()))
           .ReturnsAsync(Response.FromValue<AssistantThread>(thread, MockResponse.Object));
        MockAzureAssistantsService
           .Setup(x => x.CreateMessageAsync(It.IsAny<string>(), It.IsAny< MessageRole>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
           .ReturnsAsync(Response.FromValue<ThreadMessage>(threadMsg, MockResponse.Object));
        MockDocumentService
            .Setup(x => x.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .ReturnsAsync(document);
        MockAzureAssistantsService
            .Setup(x => x.CreateRunAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue<ThreadRun>(threadRunProgress, MockResponse.Object));
        MockAzureAssistantsService
            .Setup(x => x.GetRunAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue<ThreadRun>(threadRunFailed, MockResponse.Object));

        // Set the thread ID to empty
        requestData.ThreadId = string.Empty;

        Assert.Equal(threadRunFailed.Status, RunStatus.Failed);

        var azureOpenAIException = await Assert.ThrowsAsync<AzureOpenAIException>(() =>
            Service.SendQuestionToAssistant(requestData, CancellationToken.None)
        );

        Assert.NotNull(azureOpenAIException);
        Assert.Equal("An exception occurred while the assistant was answering a question.", azureOpenAIException.Message);
    }

    [Fact]
    public async Task SendQuestionToAssistant_ThreadEmpty_RunFailedWithMessage()
    {
        SetupService();
        SetupAzureAssistants();

        var requestData = CreateChatbotAssistantQuestion();
        var thread = CreateAssistantThread();
        var threadMsg = CreateThreadMessage();
        var document = CreateDocument();
        var threadRunProgress = CreateThreadRun(RunStatus.InProgress);
        var threadRunFailed = CreateThreadRun(RunStatus.Failed, "Rate Limit Exceeded.");

        MockAzureAssistantsService
           .Setup(x => x.CreateThreadAsync(It.IsAny<CancellationToken>()))
           .ReturnsAsync(Response.FromValue<AssistantThread>(thread, MockResponse.Object));
        MockAzureAssistantsService
           .Setup(x => x.CreateMessageAsync(It.IsAny<string>(), It.IsAny<MessageRole>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
           .ReturnsAsync(Response.FromValue<ThreadMessage>(threadMsg, MockResponse.Object));
        MockDocumentService
            .Setup(x => x.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .ReturnsAsync(document);
        MockAzureAssistantsService
            .Setup(x => x.CreateRunAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue<ThreadRun>(threadRunProgress, MockResponse.Object));
        MockAzureAssistantsService
            .Setup(x => x.GetRunAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue<ThreadRun>(threadRunFailed, MockResponse.Object));

        // Set the thread ID to empty
        requestData.ThreadId = string.Empty;

        Assert.Equal(threadRunFailed.Status, RunStatus.Failed);
        Assert.NotEmpty(threadRunFailed.LastError.Message);

        var azureOpenAIException = await Assert.ThrowsAsync<AzureOpenAIException>(() =>
            Service.SendQuestionToAssistant(requestData, CancellationToken.None)
        );

        Assert.NotNull(azureOpenAIException);
        Assert.Equal("Rate Limit Exceeded.", azureOpenAIException.Message);
    }

    [Fact]
    public async Task SendQuestionToAssistant_Thread_ThreadMsgEmpty()
    {
        SetupService();
        SetupAzureAssistants();

        var requestData = CreateChatbotAssistantQuestion();
        var thread = CreateAssistantThread();
        var threadMsg = CreateThreadMessage();
        var document = CreateDocument();
        var threadRunProgress = CreateThreadRun(RunStatus.InProgress);
        var threadRunCompleted = CreateThreadRun(RunStatus.Completed);
        var threadMsgs = CreatePageableListOfThreadMessages(IsEmpty: true);

        MockAzureAssistantsService
           .Setup(x => x.CreateThreadAsync(It.IsAny<CancellationToken>()))
           .ReturnsAsync(Response.FromValue<AssistantThread>(thread, MockResponse.Object));
        MockAzureAssistantsService
           .Setup(x => x.CreateMessageAsync(It.IsAny<string>(), It.IsAny<MessageRole>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
           .ReturnsAsync(Response.FromValue<ThreadMessage>(threadMsg, MockResponse.Object));
        MockDocumentService
            .Setup(x => x.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .ReturnsAsync(document);
        MockAzureAssistantsService
            .Setup(x => x.CreateRunAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue<ThreadRun>(threadRunProgress, MockResponse.Object));
        MockAzureAssistantsService
            .Setup(x => x.GetRunAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue<ThreadRun>(threadRunCompleted, MockResponse.Object));
        MockAzureAssistantsService
            .Setup(x => x.GetMessagesAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue(threadMsgs, MockResponse.Object));

        // Set the thread ID to empty
        requestData.ThreadId = string.Empty;

        Assert.Empty(threadMsgs);

        var azureOpenAIException = await Assert.ThrowsAsync<AzureOpenAIException>(() =>
            Service.SendQuestionToAssistant(requestData, CancellationToken.None)
        );

        Assert.NotNull(azureOpenAIException);
        Assert.Equal("An exception occurred while retrieving the last message in the conversation.", azureOpenAIException.Message);
    }

    [Fact]
    public async Task SendQuestionToAssistant_Thread_ThreadMsgRole_User()
    {
        SetupService();
        SetupAzureAssistants();

        var requestData = CreateChatbotAssistantQuestion();
        var thread = CreateAssistantThread();
        var threadMsg = CreateThreadMessage();
        var document = CreateDocument();
        var threadRunProgress = CreateThreadRun(RunStatus.InProgress);
        var threadRunCompleted = CreateThreadRun(RunStatus.Completed);
        var threadMsgs = CreatePageableListOfThreadMessages();

        MockAzureAssistantsService
           .Setup(x => x.CreateThreadAsync(It.IsAny<CancellationToken>()))
           .ReturnsAsync(Response.FromValue<AssistantThread>(thread, MockResponse.Object));
        MockAzureAssistantsService
           .Setup(x => x.CreateMessageAsync(It.IsAny<string>(), It.IsAny<MessageRole>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
           .ReturnsAsync(Response.FromValue<ThreadMessage>(threadMsg, MockResponse.Object));
        MockDocumentService
            .Setup(x => x.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .ReturnsAsync(document);
        MockAzureAssistantsService
            .Setup(x => x.CreateRunAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue<ThreadRun>(threadRunProgress, MockResponse.Object));
        MockAzureAssistantsService
            .Setup(x => x.GetRunAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue<ThreadRun>(threadRunCompleted, MockResponse.Object));
        MockAzureAssistantsService
            .Setup(x => x.GetMessagesAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue(threadMsgs, MockResponse.Object));

        // Set the thread ID to empty
        requestData.ThreadId = string.Empty;

        Assert.Equal(threadMsgs.First().Role, MessageRole.User);

        var azureOpenAIException = await Assert.ThrowsAsync<AzureOpenAIException>(() =>
            Service.SendQuestionToAssistant(requestData, CancellationToken.None)
        );

        Assert.NotNull(azureOpenAIException);
        Assert.Equal("The last message in the conversation is not from the assistant.", azureOpenAIException.Message);
    }

    [Fact]
    public async Task SendQuestionToAssistant_Thread_MessageContentEmpty()
    {
        SetupService();
        SetupAzureAssistants();

        var requestData = CreateChatbotAssistantQuestion();
        var thread = CreateAssistantThread();
        var threadMsg = CreateThreadMessage();
        var document = CreateDocument();
        var threadRunProgress = CreateThreadRun(RunStatus.InProgress);
        var threadRunCompleted = CreateThreadRun(RunStatus.Completed);
        var threadMsgs = CreatePageableListOfThreadMessages(role: MessageRole.Assistant);

        MockAzureAssistantsService
           .Setup(x => x.CreateThreadAsync(It.IsAny<CancellationToken>()))
           .ReturnsAsync(Response.FromValue<AssistantThread>(thread, MockResponse.Object));
        MockAzureAssistantsService
           .Setup(x => x.CreateMessageAsync(It.IsAny<string>(), It.IsAny<MessageRole>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
           .ReturnsAsync(Response.FromValue<ThreadMessage>(threadMsg, MockResponse.Object));
        MockDocumentService
            .Setup(x => x.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .ReturnsAsync(document);
        MockAzureAssistantsService
            .Setup(x => x.CreateRunAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue<ThreadRun>(threadRunProgress, MockResponse.Object));
        MockAzureAssistantsService
            .Setup(x => x.GetRunAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue<ThreadRun>(threadRunCompleted, MockResponse.Object));
        MockAzureAssistantsService
            .Setup(x => x.GetMessagesAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue(threadMsgs, MockResponse.Object));

        // Set the thread ID to empty
        requestData.ThreadId = string.Empty;

        Assert.Empty(threadMsgs.First().ContentItems);

        var azureOpenAIException = await Assert.ThrowsAsync<AzureOpenAIException>(() =>
            Service.SendQuestionToAssistant(requestData, CancellationToken.None)
        );

        Assert.NotNull(azureOpenAIException);
        Assert.Equal("The last message from the assistant has no answer.", azureOpenAIException.Message);
    }

    [Fact]
    public async Task SendQuestionToAssistant_ThreadExists_Answer()
    {
        SetupService();
        SetupAzureAssistants();

        var requestData = CreateChatbotAssistantQuestion();
        var thread = CreateAssistantThread();
        var threadMsg = CreateThreadMessage();
        var document = CreateDocument();
        var threadRunProgress = CreateThreadRun(RunStatus.InProgress);
        var threadRunCompleted = CreateThreadRun(RunStatus.Completed);
        var threadMsgs = CreatePageableListOfThreadMessages(HaveAnswers: true, count: (int)10e4);

        MockAzureAssistantsService
            .Setup(x => x.GetMessagesAsync(It.IsAny<string>(),It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue(threadMsgs, MockResponse.Object));
        MockAzureAssistantsService
           .Setup(x => x.CreateThreadAsync(It.IsAny<CancellationToken>()))
           .ReturnsAsync(Response.FromValue<AssistantThread>(thread, MockResponse.Object));
        MockAzureAssistantsService
           .Setup(x => x.CreateMessageAsync(It.IsAny<string>(), It.IsAny<MessageRole>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
           .ReturnsAsync(Response.FromValue<ThreadMessage>(threadMsg, MockResponse.Object));
        MockDocumentService
            .Setup(x => x.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .ReturnsAsync(document);
        MockAzureAssistantsService
            .Setup(x => x.CreateRunAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue<ThreadRun>(threadRunProgress, MockResponse.Object));
        MockAzureAssistantsService
            .Setup(x => x.GetRunAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue<ThreadRun>(threadRunCompleted, MockResponse.Object));
        MockAzureAssistantsService
            .Setup(x => x.GetMessagesAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue(threadMsgs, MockResponse.Object));

        var answer = await Service.SendQuestionToAssistant(requestData, CancellationToken.None);

        Assert.NotNull(answer);
        Assert.Equal(thread.Id, answer.ThreadId);
        Assert.Equal(MessageRole.Assistant.ToString(), answer.Role);
        Assert.Equal("This is an answer form the assistants.", answer.Content);
    }

    [Fact]
    public async Task SendQuestionToAssistant_ThreadExists_AnswerAnnotations()
    {
        SetupService();
        SetupAzureAssistants();

        var requestData = CreateChatbotAssistantQuestion();
        var threadMsg = CreateThreadMessage();
        var document = CreateDocument();
        var threadRunProgress = CreateThreadRun(RunStatus.InProgress);
        var threadRunCompleted = CreateThreadRun(RunStatus.Completed);
        var threadMsgs = CreatePageableListOfThreadMessages(HaveAnswers: true, HaveAnnotations: true);

        MockAzureAssistantsService
            .Setup(x => x.GetMessagesAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue(threadMsgs, MockResponse.Object));
        MockAzureAssistantsService
           .Setup(x => x.CreateMessageAsync(It.IsAny<string>(), It.IsAny<MessageRole>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
           .ReturnsAsync(Response.FromValue<ThreadMessage>(threadMsg, MockResponse.Object));
        MockDocumentService
            .Setup(x => x.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .ReturnsAsync(document);
        MockAzureAssistantsService
            .Setup(x => x.CreateRunAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue<ThreadRun>(threadRunProgress, MockResponse.Object));
        MockAzureAssistantsService
            .Setup(x => x.GetRunAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue<ThreadRun>(threadRunCompleted, MockResponse.Object));
        MockAzureAssistantsService
            .Setup(x => x.GetMessagesAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue(threadMsgs, MockResponse.Object));

        Assert.NotEmpty(((MessageTextContent)threadMsgs.First().ContentItems.First()).Annotations);

        var answer = await Service.SendQuestionToAssistant(requestData, CancellationToken.None);

        Assert.NotNull(answer);
        Assert.Equal(threadMsg.ThreadId, answer.ThreadId);
        Assert.Equal(MessageRole.Assistant.ToString(), answer.Role);
        Assert.Equal("This is an answer form the assistants.", answer.Content);
    }

    [Fact]
    public async Task SendQuestionToAssistant_ThreadExists_GetMessages_Error()
    {
        SetupService();
        SetupAzureAssistants();

        var requestData = CreateChatbotAssistantQuestion();
        var threadMsg = CreateThreadMessage();
        var document = CreateDocument();
        var threadRunProgress = CreateThreadRun(RunStatus.InProgress);
        var threadRunCompleted = CreateThreadRun(RunStatus.Completed);
        var threadMsgs = CreatePageableListOfThreadMessages(HaveAnswers: true, HaveAnnotations: true);
        var ex = new Exception("An error occurred while getting messages.");

        MockAzureAssistantsService
            .Setup(x => x.GetMessagesAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue(threadMsgs, MockResponse.Object));
        MockAzureAssistantsService
           .Setup(x => x.CreateMessageAsync(It.IsAny<string>(), It.IsAny<MessageRole>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
           .ReturnsAsync(Response.FromValue<ThreadMessage>(threadMsg, MockResponse.Object));
        MockDocumentService
            .Setup(x => x.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .ReturnsAsync(document);
        MockAzureAssistantsService
            .Setup(x => x.CreateRunAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue<ThreadRun>(threadRunProgress, MockResponse.Object));
        MockAzureAssistantsService
            .Setup(x => x.GetRunAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue<ThreadRun>(threadRunCompleted, MockResponse.Object));
        MockAzureAssistantsService
            .Setup(x => x.GetMessagesAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .Throws(ex);

        Assert.NotEmpty(((MessageTextContent)threadMsgs.First().ContentItems.First()).Annotations);

        var azureOpenAIException = await Assert.ThrowsAsync<AzureOpenAIException>(() =>
            Service.SendQuestionToAssistant(requestData, CancellationToken.None)
        );

        Assert.NotNull(azureOpenAIException);
        Assert.Equal(ex.Message, azureOpenAIException.Message);
    }
    #endregion

    #region Validation
    [Fact]
    public async Task ValidatePrivateAccessCode_AccessCode_Empty()
    {
        SetupService();

        var requestData = CreateChatbotAssistantQuestion();
        var user = CreateChatbotUser();

        // Set the access code to empty
        requestData.AccessCode = string.Empty;

        var validationErrors = await Service.ValidateAssistantQuestion(requestData, user, CancellationToken.None);

        Assert.Single(validationErrors);

        var error = validationErrors.FirstOrDefault();

        Assert.Equal(StatusCodes.Status400BadRequest, error.Key);
        Assert.Equal("Access Code is required.", error.Value);
    }

    [Fact]
    public async Task ValidatePrivateAccessCode_AccessCode_NotFound()
    {
        SetupService();

        var requestData = CreateChatbotAssistantQuestion();
        var user = CreateChatbotUser();

        MockGroupService
            .Setup(x => x.GetDirectorySecurityInformation(It.IsAny<string>()))
            .ReturnsAsync((ViewGroup)null);

        var validationErrors = await Service.ValidateAssistantQuestion(requestData, user, CancellationToken.None);

        Assert.Single(validationErrors);

        var error = validationErrors.FirstOrDefault();

        Assert.Equal(StatusCodes.Status404NotFound, error.Key);
        Assert.Equal("Access Code not found.", error.Value);
    }

    [Fact]
    public async Task ValidatePrivateAccessCode_AnonymousEntry()
    {
        SetupService();

        var requestData = CreateChatbotAssistantQuestion();
        var user = CreateChatbotUser();
        var viewGroup = CreateViewGroup();

        // Set the group to allow anonymous entry
        viewGroup.AllowAnonymousEntry = true;
        viewGroup.RequiresUniversalLogin = false;
        viewGroup.RequiredSecurities = new Dictionary<int, string>();

        MockGroupService
            .Setup(x => x.GetDirectorySecurityInformation(It.IsAny<string>()))
            .ReturnsAsync(viewGroup);

        // Set the user to not authenticated
        user.IsAuthenticated = false;

        var validationErrors = await Service.ValidateAssistantQuestion(requestData, user, CancellationToken.None);

        Assert.Single(validationErrors);

        var error = validationErrors.FirstOrDefault();

        Assert.Equal(StatusCodes.Status404NotFound, error.Key);
        Assert.Equal("Document not found.", error.Value);
    }

    [Fact]
    public async Task ValidatePrivateAccessCode_Unauthorized()
    {
        SetupService();

        var requestData = CreateChatbotAssistantQuestion();
        var user = CreateChatbotUser();
        var viewGroup = CreateViewGroup();

        MockGroupService
            .Setup(x => x.GetDirectorySecurityInformation(It.IsAny<string>()))
            .ReturnsAsync(viewGroup);

        // Set the user to not authenticated
        user.IsAuthenticated = false;

        var validationErrors = await Service.ValidateAssistantQuestion(requestData, user, CancellationToken.None);

        Assert.Single(validationErrors);

        var error = validationErrors.FirstOrDefault();

        Assert.Equal(StatusCodes.Status401Unauthorized, error.Key);
        Assert.Equal("Token is expired.", error.Value);
    }

    [Fact]
    public async Task ValidatePrivateAccessCode_UserId_Null()
    {
        SetupService();

        var requestData = CreateChatbotAssistantQuestion();
        var user = CreateChatbotUser();
        var viewGroup = CreateViewGroup();

        MockGroupService
            .Setup(x => x.GetDirectorySecurityInformation(It.IsAny<string>()))
            .ReturnsAsync(viewGroup);

        // Set the user ID to null
        user.Id = null as Guid?;

        var validationErrors = await Service.ValidateAssistantQuestion(requestData, user, CancellationToken.None);

        Assert.Single(validationErrors);

        var error = validationErrors.FirstOrDefault();

        Assert.Equal(StatusCodes.Status401Unauthorized, error.Key);
        Assert.Equal("Token is expired.", error.Value);
    }

    [Fact]
    public async Task ValidatePrivateAccessCode_UserId_GuidEmpty()
    {
        SetupService();

        var requestData = CreateChatbotAssistantQuestion();
        var user = CreateChatbotUser();
        var viewGroup = CreateViewGroup();

        MockGroupService
            .Setup(x => x.GetDirectorySecurityInformation(It.IsAny<string>()))
            .ReturnsAsync(viewGroup);

        // Set the user ID to Guid.Empty
        user.Id = Guid.Empty;

        var validationErrors = await Service.ValidateAssistantQuestion(requestData, user, CancellationToken.None);

        Assert.Single(validationErrors);

        var error = validationErrors.FirstOrDefault();

        Assert.Equal(StatusCodes.Status401Unauthorized, error.Key);
        Assert.Equal("Token is expired.", error.Value);
    }

    [Fact]
    public async Task ValidatePrivateAccessCode_User_NotSecurity()
    {
        SetupService();

        var requestData = CreateChatbotAssistantQuestion();
        var user = CreateChatbotUser();
        var viewGroup = CreateViewGroup();

        MockGroupService
            .Setup(x => x.GetDirectorySecurityInformation(It.IsAny<string>()))
            .ReturnsAsync(viewGroup);
        MockAccessCodeSecurityValueService
            .Setup(x => x.IsUserInSecurity(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<string>()))
            .ReturnsAsync(false);

        var validationErrors = await Service.ValidateAssistantQuestion(requestData, user, CancellationToken.None);

        Assert.Single(validationErrors);

        var error = validationErrors.FirstOrDefault();

        Assert.Equal(StatusCodes.Status503ServiceUnavailable, error.Key);
        Assert.Equal("The chatbot is unavailable for this document.", error.Value);
    }

    [Fact]
    public async Task ValidateDocumentAndAssistant_DocumentID_Empty()
    {
        SetupService();

        var requestData = CreateChatbotAssistantQuestion();
        var user = CreateChatbotUser();
        var viewGroup = CreateViewGroup();

        MockGroupService
            .Setup(x => x.GetDirectorySecurityInformation(It.IsAny<string>()))
            .ReturnsAsync(viewGroup);
        MockAccessCodeSecurityValueService
            .Setup(x => x.IsUserInSecurity(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<string>()))
            .ReturnsAsync(true);

        // Set the document ID to null
        requestData.DocumentId = null;

        var validationErrors = await Service.ValidateAssistantQuestion(requestData, user, CancellationToken.None);

        Assert.Single(validationErrors);

        var error = validationErrors.FirstOrDefault();

        Assert.Equal(StatusCodes.Status400BadRequest, error.Key);
        Assert.Equal("Document ID is required.", error.Value);
    }

    [Fact]
    public async Task ValidateDocumentAndAssistant_Document_NotFound()
    {
        SetupService();

        var requestData = CreateChatbotAssistantQuestion();
        var user = CreateChatbotUser();
        var viewGroup = CreateViewGroup();

        MockGroupService
            .Setup(x => x.GetDirectorySecurityInformation(It.IsAny<string>()))
            .ReturnsAsync(viewGroup);
        MockAccessCodeSecurityValueService
            .Setup(x => x.IsUserInSecurity(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<string>()))
            .ReturnsAsync(true);
        MockDocumentService
            .Setup(x => x.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .ReturnsAsync((Document)null);

        var validationErrors = await Service.ValidateAssistantQuestion(requestData, user, CancellationToken.None);

        Assert.Single(validationErrors);

        var error = validationErrors.FirstOrDefault();

        Assert.Equal(StatusCodes.Status404NotFound, error.Key);
        Assert.Equal("Document not found.", error.Value);
    }

    [Fact]
    public async Task ValidateDocumentAndAssistant_Document_DisableChatbot()
    {
        SetupService();

        var requestData = CreateChatbotAssistantQuestion();
        var user = CreateChatbotUser();
        var viewGroup = CreateViewGroup();
        var document = CreateDocument();

        MockGroupService
            .Setup(x => x.GetDirectorySecurityInformation(It.IsAny<string>()))
            .ReturnsAsync(viewGroup);
        MockAccessCodeSecurityValueService
            .Setup(x => x.IsUserInSecurity(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<string>()))
            .ReturnsAsync(true);

        // Set the document options to empty to simulate a disabled chatbot
        document.DocumentOptions = Array.Empty<DocumentOption>();

        MockDocumentService
            .Setup(x => x.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .ReturnsAsync(document);

        var validationErrors = await Service.ValidateAssistantQuestion(requestData, user, CancellationToken.None);

        Assert.Single(validationErrors);

        var error = validationErrors.FirstOrDefault();

        Assert.Equal(StatusCodes.Status503ServiceUnavailable, error.Key);
        Assert.Equal("The chatbot is unavailable for this document.", error.Value);
    }

    [Fact]
    public async Task ValidateDocumentAndAssistant_Document_AssistantEmpty()
    {
        SetupService();

        var requestData = CreateChatbotAssistantQuestion();
        var user = CreateChatbotUser();
        var viewGroup = CreateViewGroup();
        var document = CreateDocument();

        MockGroupService
            .Setup(x => x.GetDirectorySecurityInformation(It.IsAny<string>()))
            .ReturnsAsync(viewGroup);
        MockAccessCodeSecurityValueService
            .Setup(x => x.IsUserInSecurity(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<string>()))
            .ReturnsAsync(true);

        // Set the assistant ID to empty
        document.AssistantId = string.Empty;

        MockDocumentService
            .Setup(x => x.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .ReturnsAsync(document);

        var validationErrors = await Service.ValidateAssistantQuestion(requestData, user, CancellationToken.None);

        Assert.Single(validationErrors);

        var error = validationErrors.FirstOrDefault();

        Assert.Equal(StatusCodes.Status404NotFound, error.Key);
        Assert.Equal("Assistant not found.", error.Value);
    }

    [Fact]
    public async Task ValidateAssistantThread_Thread_Null()
    {
        SetupService();
        SetupAzureAssistants();

        var requestData = CreateChatbotAssistantQuestion();
        var user = CreateChatbotUser();
        var viewGroup = CreateViewGroup();
        var document = CreateDocument();

        MockGroupService
            .Setup(x => x.GetDirectorySecurityInformation(It.IsAny<string>()))
            .ReturnsAsync(viewGroup);
        MockAccessCodeSecurityValueService
            .Setup(x => x.IsUserInSecurity(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<string>()))
            .ReturnsAsync(true);
        MockDocumentService
            .Setup(x => x.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .ReturnsAsync(document);
        MockAzureAssistantsService
            .Setup(x => x.GetThreadAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue<AssistantThread>(null, MockResponse.Object));

        var validationErrors = await Service.ValidateAssistantQuestion(requestData, user, CancellationToken.None);

        Assert.Single(validationErrors);

        var error = validationErrors.FirstOrDefault();

        Assert.Equal(StatusCodes.Status404NotFound, error.Key);
        Assert.Equal("Thread ID not found.", error.Value);
    }

    [Fact]
    public async Task ValidateAssistantThread_Thread_NotFound()
    {
        SetupService();

        var requestData = CreateChatbotAssistantQuestion();
        var user = CreateChatbotUser();
        var viewGroup = CreateViewGroup();
        var document = CreateDocument();

        MockGroupService
            .Setup(x => x.GetDirectorySecurityInformation(It.IsAny<string>()))
            .ReturnsAsync(viewGroup);
        MockAccessCodeSecurityValueService
            .Setup(x => x.IsUserInSecurity(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<string>()))
            .ReturnsAsync(true);
        MockDocumentService
            .Setup(x => x.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .ReturnsAsync(document);
        MockAzureAssistantsService
            .Setup(x => x.GetThreadAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new RequestFailedException(
                status: StatusCodes.Status404NotFound,
                message: "404 NotFound",
                errorCode: "NotFound",
                innerException: null
            ));

        var validationErrors = await Service.ValidateAssistantQuestion(requestData, user, CancellationToken.None);

        Assert.Single(validationErrors);

        var error = validationErrors.FirstOrDefault();

        Assert.Equal(StatusCodes.Status404NotFound, error.Key);
        Assert.Equal("Thread ID not found.", error.Value);
    }

    [Fact]
    public async Task ValidateAssistantThread_Thread_InternalServerError()
    {
        SetupService();

        var requestData = CreateChatbotAssistantQuestion();
        var user = CreateChatbotUser();
        var viewGroup = CreateViewGroup();
        var document = CreateDocument();

        MockGroupService
            .Setup(x => x.GetDirectorySecurityInformation(It.IsAny<string>()))
            .ReturnsAsync(viewGroup);
        MockAccessCodeSecurityValueService
            .Setup(x => x.IsUserInSecurity(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<string>()))
            .ReturnsAsync(true);
        MockDocumentService
            .Setup(x => x.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .ReturnsAsync(document);
        MockAzureAssistantsService
            .Setup(x => x.GetThreadAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new RequestFailedException(
                status: StatusCodes.Status500InternalServerError,
                message: "500 Internal Server Error",
                errorCode: "InternalServerError",
                innerException: null
            ));

        var validationErrors = await Service.ValidateAssistantQuestion(requestData, user, CancellationToken.None);

        Assert.Single(validationErrors);

        var error = validationErrors.FirstOrDefault();

        Assert.Equal(StatusCodes.Status404NotFound, error.Key);
        Assert.Equal("Thread ID not found.", error.Value);
    }

    [Fact]
    public async Task ValidateAssistantQuestion_Question_Empty()
    {
        SetupService();
        SetupAzureAssistants();

        var requestData = CreateChatbotAssistantQuestion();
        var user = CreateChatbotUser();
        var viewGroup = CreateViewGroup();
        var document = CreateDocument();
        var thread = CreateAssistantThread();

        MockGroupService
            .Setup(x => x.GetDirectorySecurityInformation(It.IsAny<string>()))
            .ReturnsAsync(viewGroup);
        MockAccessCodeSecurityValueService
            .Setup(x => x.IsUserInSecurity(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<string>()))
            .ReturnsAsync(true);
        MockDocumentService
            .Setup(x => x.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .ReturnsAsync(document);
        MockAzureAssistantsService
           .Setup(x => x.GetThreadAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
           .ReturnsAsync(Response.FromValue(thread, MockResponse.Object));

        // Set the thread ID to empty
        requestData.ThreadId = string.Empty;
        // Set the question to empty
        requestData.Question = string.Empty;

        var validationErrors = await Service.ValidateAssistantQuestion(requestData, user, CancellationToken.None);

        Assert.Single(validationErrors);

        var error = validationErrors.FirstOrDefault();

        Assert.Equal(StatusCodes.Status400BadRequest, error.Key);
        Assert.Equal("Question is required.", error.Value);
    }

    [Fact]
    public async Task ValidateAssistantQuestion_Ok()
    {
        SetupService();
        SetupAzureAssistants();

        var requestData = CreateChatbotAssistantQuestion();
        var user = CreateChatbotUser();
        var viewGroup = CreateViewGroup();
        var document = CreateDocument();
        var thread = CreateAssistantThread();

        MockGroupService
            .Setup(x => x.GetDirectorySecurityInformation(It.IsAny<string>()))
            .ReturnsAsync(viewGroup);
        MockAccessCodeSecurityValueService
            .Setup(x => x.IsUserInSecurity(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<string>()))
            .ReturnsAsync(true);
        MockDocumentService
            .Setup(x => x.GetDocument(It.IsAny<int>(), It.IsAny<bool>()))
            .ReturnsAsync(document);
        MockAzureAssistantsService
           .Setup(x => x.GetThreadAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
           .ReturnsAsync(Response.FromValue(thread, MockResponse.Object));

        var validationErrors = await Service.ValidateAssistantQuestion(requestData, user, CancellationToken.None);

        Assert.Empty(validationErrors);
    }
    #endregion

    #region Setup
    private void SetupService()
    {
        MockAzureAssistantsService = new Mock<IAzureAssistantsService>();
        MockGroupService = new Mock<IGroupService>();
        MockAccessCodeSecurityValueService = new Mock<IAccessCodeSecurityValueService>();
        MockDocumentService = new Mock<IDocumentService>();

        Service = new ChatbotService(
            MockAzureAssistantsService.Object,
            MockGroupService.Object,
            MockAccessCodeSecurityValueService.Object,
            MockDocumentService.Object
        );
    }

    private void SetupAzureAssistants()
    {
        MockResponse = new Mock<Response>();
    }

    private ChatbotAssistantQuestion CreateChatbotAssistantQuestion()
    {
        return new ChatbotAssistantQuestion
        {
            AccessCode = "test-code",
            ThreadId = "test-thread",
            DocumentId = 1,
            Question = "What is the weather today?"
        };
    }

    private ChatbotUser CreateChatbotUser()
    {
        return new ChatbotUser
        {
            Id = Guid.NewGuid(),
            IsAuthenticated = true
        };
    }

    private ViewGroup CreateViewGroup()
    {
        return new ViewGroup()
        {
            CodeText = "test-code",
            AllowAnonymousEntry = false,
            RequiresUniversalLogin = true,
            RequiredSecurities = new Dictionary<int, string>()
            {
                { 1, "Test Security" }
            }
        };
    }

    private Document CreateDocument()
    {
        return new Document()
        {
            Id = 1,
            DocumentOptions = new List<DocumentOption>()
                {
                    new DocumentOption
                    {
                        DocumentOptionTypeId = (int)DocumentOptionTypeDefinition.Chatbot
                    }
                },
            AssistantId = "test-assistant"
        };
    }

    private AssistantThread CreateAssistantThread()
    {
        var thread = (AssistantThread)RuntimeHelpers
            .GetUninitializedObject(typeof(AssistantThread));

        typeof(AssistantThread)
            .GetField("<Id>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
            .SetValue(thread, "test-thread");
        typeof(AssistantThread)
            .GetField("<CreatedAt>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
            .SetValue(thread, DateTimeOffset.Now);

        return thread;
    }

    private ThreadMessage CreateThreadMessage(MessageRole? role = null)
    {
        var threadMsg = (ThreadMessage)RuntimeHelpers
            .GetUninitializedObject(typeof(ThreadMessage));

        typeof(ThreadMessage)
            .GetField("<Id>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
            .SetValue(threadMsg, "test-thread-message");
        typeof(ThreadMessage)
            .GetField("<ThreadId>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
            .SetValue(threadMsg, "test-thread");
        typeof(ThreadMessage)
            .GetField("<Role>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
            .SetValue(threadMsg, role ?? MessageRole.User);
        typeof(ThreadMessage)
            .GetField("<CreatedAt>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
            .SetValue(threadMsg, DateTimeOffset.Now);

        return threadMsg;
    }

    private ThreadRun CreateThreadRun(RunStatus status, string errMsg = "")
    {
        var threadRun = (ThreadRun)RuntimeHelpers
            .GetUninitializedObject(typeof(ThreadRun));

        typeof(ThreadRun)
           .GetField("<Id>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
           .SetValue(threadRun, "test-thread-run");
        typeof(ThreadRun)
            .GetField("<ThreadId>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
            .SetValue(threadRun, "test-thread");
        typeof(ThreadRun)
            .GetField("<Status>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
            .SetValue(threadRun, status);

        if (status == RunStatus.Failed)
        {
            var runError = (RunError)RuntimeHelpers
            .GetUninitializedObject(typeof(RunError));

            typeof(RunError)
                .GetField("<Message>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
                .SetValue(runError, errMsg);

            typeof(ThreadRun)
                .GetField("<LastError>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
                .SetValue(threadRun, runError);
        }

        typeof(ThreadRun)
            .GetField("<CreatedAt>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
            .SetValue(threadRun, DateTimeOffset.Now);

        return threadRun;
    }

    private MessageTextAnnotation CreateMessageTextAnnotation(string Text)
    {
        var data = BinaryData.FromString(JsonConvert.SerializeObject(
            new
            {
                Type = "text",
                Text = Text
            }
        ));
        var annotation = ModelReaderWriter.Read<MessageTextAnnotation>(data);

        typeof(MessageTextAnnotation)
            .GetField("<Type>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
            .SetValue(annotation, "text");
        typeof(MessageTextAnnotation)
            .GetField("<Text>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
            .SetValue(annotation, Text);

        return annotation;
    }

    private MessageTextContent CreateMessageContent(bool HaveAnnotations)
    {
        var messageContent = (MessageTextContent)RuntimeHelpers
           .GetUninitializedObject(typeof(MessageTextContent));
        var internalDetailsType = typeof(MessageTextContent)
            .Assembly
            .GetType("Azure.AI.OpenAI.Assistants.InternalMessageTextDetails");
        var internalDetails = RuntimeHelpers.GetUninitializedObject(internalDetailsType);
        var text = "This is an answer form the assistants.";
        var annotations = new List<MessageTextAnnotation>();

        if (HaveAnnotations)
        {
            var annotationText = "[1]";
            annotations.Add(CreateMessageTextAnnotation(annotationText));

            text = string.Concat(annotationText, text);
        }

        internalDetailsType
               .GetField("<Text>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
               .SetValue(internalDetails, text);
        internalDetailsType
            .GetField("<Annotations>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
            .SetValue(internalDetails, annotations);
        typeof(MessageTextContent)
               .GetField("<InternalDetails>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
               .SetValue(messageContent, internalDetails);

        return messageContent;
    }

    private PageableList<ThreadMessage> CreatePageableListOfThreadMessages(
        bool IsEmpty = false,
        MessageRole? role = null,
        bool HaveAnswers = false,
        bool HaveAnnotations = false,
        int count = 1
    )
    {
        var pageableList = (PageableList<ThreadMessage>)RuntimeHelpers
            .GetUninitializedObject(typeof(PageableList<ThreadMessage>));
        var data = new List<ThreadMessage>();

        if (!IsEmpty)
        {
            if (role == null)
            {
                role = HaveAnswers ? MessageRole.Assistant : MessageRole.User;
            }

            var threadMsg = CreateThreadMessage(role);
            var contentItems = new List<MessageTextContent>();

            if (HaveAnswers)
            {
                typeof(ThreadMessage)
                    .GetField("<RunId>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
                    .SetValue(threadMsg, "test-thread-run");

                contentItems.Add(CreateMessageContent(HaveAnnotations));
            }

            typeof(ThreadMessage)
                .GetField("<ContentItems>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
                .SetValue(threadMsg, contentItems);

            for ( var i = 0; i < count; i++)
            {
                data.Add(threadMsg);
            }
        }

        typeof(PageableList<ThreadMessage>)
            .GetField("<Data>k__BackingField", BindingFlags.NonPublic | BindingFlags.Instance)!
            .SetValue(pageableList, data);

        return pageableList;
    }
    #endregion
}
