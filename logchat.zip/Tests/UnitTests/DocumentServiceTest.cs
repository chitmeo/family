using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using DocumentViewer.Database.AdminModels.Search;
using DocumentViewer.Database.AdminModels.Upsert;
using DocumentViewer.Database.EntityModels;
using DocumentViewer.Services;
using DocumentViewer.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using WilsonNet.Services;
using Xunit;

namespace UnitTests;

public class DocumentServiceTest
{
    private IDocumentService Service;
    private TestAppDbContext _appDbContext;
    private SqliteConnection Connection;
    private Mock<Repository<Document>> MockRepository;
    private Mock<ILogger<TestAppDbContext>> MockLogger;
    private Mock<IAzureService> MockAzureService;
    private Mock<IPdfService> MockPdfService;

    [Fact]
    public async Task GetDocument_ReturnsCorrespondingDocument()
    {
        OpenConnection();
        try
        {
            SetupApplicationContext();
            SetupMockServices();
            MockAzureService
                .Setup(service => service.GetFileLinkFromAzure(It.IsAny<string>(), It.IsAny<string>()))
                .Returns("Azure_File_Path");
            SetupService();
            var documentResult = await Service.GetDocument(1);

            MockAzureService.Verify(service => service.GetFileLinkFromAzure(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
            Assert.Equal(1, documentResult.Id);
        }
        finally
        {
            CloseConnection();
        }
    }

    [Fact]
    public async Task GetDocument_ReturnsNullWhenDocumentDoesntExist()
    {
        OpenConnection();
        try
        {
            SetupApplicationContext();
            SetupMockServices();
            MockAzureService
                .Setup(service => service.GetFileLinkFromAzure(It.IsAny<string>(), It.IsAny<string>()))
                .Returns("Azure_File_Path");
            SetupService();
            var documentResult = await Service.GetDocument(5555);

            Assert.Null(documentResult);
        }
        finally
        {
            CloseConnection();
        }
    }

    [Fact]
    public async Task GetDocuments_ReturnsListOfDocuments()
    {
        OpenConnection();
        try
        {
            SetupApplicationContext();
            SetupMockServices();
            SetupService();
            var SearchModel = new Search()
            {
                Filters = [],
                Skip = 0,
                Take = 25,
                DateRanges = [],
                Sort = null
            };
            var documentResult = await Service.GetDocuments(SearchModel);
            Assert.Equal(25, documentResult.Count);
        }
        finally
        {
            CloseConnection();
        }
    }


    [Fact]
    public async Task GetDocuments_ReturnsEmptyListWhenNothingMatchesFilter()
    {
        OpenConnection();
        try
        {
            SetupApplicationContext();
            SetupMockServices();
            SetupService();
            var SearchModel = new Search
            {
                Filters = [
                      new Filter{
                          Column = "Title",
                          Value = "Something That Shouldnt Match",
                          FilterType = WilsonNet.Services.BaseDatabaseServices.Models.FilterTypeDefinition.Equals
                      }
                  ],
                Skip = 0,
                Take = 25,
                DateRanges = [],
                Sort = null
            };
            var documentResult = await Service.GetDocuments(SearchModel);
            Assert.Empty(documentResult);
        }
        finally
        {
            CloseConnection();
        }
    }

    [Fact]
    public async Task UpsertDocument_ReturnsDocumentIdAfterUpserting()
    {
        OpenConnection();
        try
        {
            // Set up DB + Services
            SetupApplicationContext();
            SetupMockServices();
            MockAzureService
              .Setup(service => service.SaveToAzure(It.IsAny<Stream>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
              .Returns(Task.FromResult("Pdf_File_Path"));
            MockAzureService
              .Setup(service => service.SaveThumbnailToAzure(It.IsAny<string>(), It.IsAny<IFormFile>()))
              .Returns(Task.FromResult("thumnail-url.com/1"));

            SetupService();

            // Set up data for this test
            DocumentUpsert doc = 
                new()
                {
                    Document =
                        new Document
                        {
                            Id = 999,
                            CreatedDate = DateTime.Now,
                            FilePath = "test-path-999",
                            Title = "Document 999",
                            Description = "Document 999 Description",
                            ThumbnailUrl = "test-image.png",
                            ThumbnailAutogenerated = true,
                            DocumentTypeId = 1,
                            DocumentOptions = [
                                new DocumentOption() {
                                     DocumentId = 555,
                                     DocumentOptionTypeId = 2
                                 }
                            ]
                        },
                    Groups = [1, 2, 3],
                    Options = [1, 2],
                    Attachments = []
                };

            _appDbContext.Documents.Add(doc.Document);
            await _appDbContext.SaveChangesAsync();

            const string pdfContext = @"
                %PDF-1.7
                %����
                1 0 obj
                << /Pages 2 0 R /Type /Catalog >>
                endobj
                2 0 obj
                << /Count 1 /Kids [ 3 0 R ] /Type /Pages >>
                endobj
                3 0 obj
                << /Contents 4 0 R /Group << /CS /DeviceRGB /I true /S /Transparency /Type /Group >> /MediaBox [ 0 0 446.25 631.5 ] /Parent 2 0 R /Resources 5 0 R /StructParents 0 /Type /Page >>
                endobj
                4 0 obj
                << /Filter /FlateDecode /Length 29 >>
                stream
                x�3T0 B]C afl�g����U�� 5T�endstream
                endobj
                5 0 obj
                << >>
                endobj
                xref
                0 6
                0000000000 65535 f 
                0000000015 00000 n 
                0000000064 00000 n 
                0000000123 00000 n 
                0000000317 00000 n 
                0000000416 00000 n 
                trailer << /Root 1 0 R /Size 6 /ID [<ad681a850d5f9bd5bfa9ed0c94ee87af><ad681a850d5f9bd5bfa9ed0c94ee87af>] >>
                startxref
                437
                %%EOF";

            MemoryStream pdf = new MemoryStream(Encoding.UTF8.GetBytes(pdfContext));
            MemoryStream png = new MemoryStream(Encoding.UTF8.GetBytes("This is a dummy thumbnail"));

            IFormFile file = new FormFile(pdf, 0, pdf.Length, "Data", "dummy.pdf");
            IFormFile thumbnail = new FormFile(png, 0, png.Length, "Data", "dummy.png");

            // Act
            pdftron.PDFNet.Initialize("demo:1646079598355:7b1305d30300000000d32cda1079892c826222968c1092056912387b84");
            var documentResult = await Service.UpsertDocument(doc, file, thumbnail);

            // Assert
            MockAzureService.Verify(service => service.SaveToAzure(It.IsAny<Stream>(), It.IsAny<string>(), It.IsAny<string>(), "pdf"), Times.Exactly(1));
            Assert.Equal(999, documentResult);
        }
        finally
        {
            CloseConnection();
        }
    }

    [Fact]
    public async Task GetDocumentOptionTypes_ReturnsListOfDocumentOptionTypes()
    {
        OpenConnection();
        try
        {
            SetupApplicationContext();
            SetupMockServices();
            SetupService();
            var docOptionTypesResult = await Service.GetDocumentOptionTypes();

            Assert.Equal(2, docOptionTypesResult.Count);
            Assert.Equal("Save", docOptionTypesResult[0].Type);
            Assert.Equal("Print", docOptionTypesResult[1].Type);
        }
        finally
        {
            CloseConnection();
        }
    }

    [Fact]
    public async Task IsDocumentInAccessCodeGroup_ReturnsBool()
    {
        OpenConnection();
        try
        {
            SetupApplicationContext();
            SetupMockServices();
            SetupService();
            var code = "flcl1";
            var doc1 = 1;
            var doc2 = 99999999;
            var IsDocumentInAccessCodeGroupResult1 = await Service.IsDocumentInAccessCodeGroup(code, doc1);
            var IsDocumentInAccessCodeGroupResult2 = await Service.IsDocumentInAccessCodeGroup(code, doc2);

            Assert.True(IsDocumentInAccessCodeGroupResult1);
            Assert.False(IsDocumentInAccessCodeGroupResult2);
        }
        finally
        {
            CloseConnection();
        }
    }

    private void SetupMockServices()
    {
        MockAzureService = new Mock<IAzureService>();
        MockPdfService = new Mock<IPdfService>();
        MockRepository = new Mock<Repository<Document>>(_appDbContext);
    }
        
    private void SetupService()
    {
        Service = new DocumentService(MockRepository.Object, _appDbContext, MockAzureService.Object, MockPdfService.Object);
    }

    private void OpenConnection()
    {
        Connection = new SqliteConnection("DataSource=:memory:");
        Connection.Open();
    }

    private void CloseConnection()
    {
        Connection.Close();
    }

    private void SetupApplicationContext()
    {
        var options = new DbContextOptionsBuilder()
            .UseSqlite(Connection)
            .Options;
        MockLogger = new Mock<ILogger<TestAppDbContext>>();
        _appDbContext = new TestAppDbContext(options, MockLogger.Object);
        _appDbContext.Database.EnsureCreated();
    }
}