using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DocumentViewer.Database;
using DocumentViewer.Database.EntityModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using WilsonNet.Services.EntityFrameworkServices.Entities;

namespace UnitTests;

public class TestAppDbContext : DbContext, IDocViewerCollectionsContext
{
    public TestAppDbContext(DbContextOptions options, ILogger<TestAppDbContext> logger)
        : base(options)
    {
    }

    public DbSet<AccessCode> AccessCodes { get; set; }
    public DbSet<AccessCodeSecurity> AccessCodeSecurities { get; set; }
    public DbSet<AccessCodeSecurityType> AccessCodeSecurityTypes { get; set; }
    public DbSet<Group> Groups { get; set; }
    public DbSet<Document> Documents { get; set; }
    public DbSet<DocumentGroup> DocumentGroups { get; set; }
    public DbSet<DocumentOption> DocumentOptions { get; set; }
    public DbSet<DocumentOptionType> DocumentOptionTypes { get; set; }
    public DbSet<DocumentType> DocumentTypes { get; set; }
    public DbSet<DocumentAttachment> DocumentAttachments { get; set; }

    public Task<int> Upsert(BaseEntity<int> entity)
    {
        Entry(entity).State = entity.Id == 0 ? EntityState.Added : EntityState.Modified;
        return SaveChangesAsync();
    }

    public Task<int> SaveChangesAsync() => Task.FromResult(SaveChanges());

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        SetupTableConstraints(modelBuilder);
        Seed(modelBuilder);
    }

    private static void SetupTableConstraints(ModelBuilder modelBuilder)
    {
        // DocumentGroup
        modelBuilder.Entity<DocumentGroup>()
            .HasKey(x => new { x.DocumentId, x.GroupId });

        modelBuilder.Entity<DocumentGroup>()
            .HasOne(x => x.Document)
            .WithMany(x => x.DocumentGroups)
            .HasForeignKey(x => x.DocumentId);

        modelBuilder.Entity<DocumentGroup>()
            .HasOne(x => x.Group)
            .WithMany(x => x.DocumentGroups)
            .HasForeignKey(x => x.GroupId);

        // AccessCode
        modelBuilder.Entity<AccessCode>().HasAlternateKey(x => x.CodeText);
        modelBuilder.Entity<AccessCode>()
            .HasOne(x => x.Group)
            .WithMany(x => x.AccessCodes)
            .HasForeignKey(x => x.GroupId);

        modelBuilder.Entity<AccessCode>()
            .HasMany(x => x.AccessCodeSecurities)
            .WithOne(x => x.AccessCode)
            .HasForeignKey(x => x.AccessCodeId);

        // AccessCodeSecurity
        modelBuilder.Entity<AccessCodeSecurity>()
            .HasKey(x => new { x.AccessCodeId, x.AccessCodeSecurityTypeId });

        modelBuilder.Entity<AccessCodeSecurity>()
            .HasOne(x => x.AccessCodeSecurityType)
            .WithMany(x => x.AccessCodeSecurities)
            .HasForeignKey(x => x.AccessCodeSecurityTypeId);


        // DocumentOption
        modelBuilder.Entity<DocumentOption>()
            .HasKey(x => new { x.DocumentId, x.DocumentOptionTypeId });

        modelBuilder.Entity<DocumentOption>()
            .HasOne(x => x.DocumentOptionType)
            .WithMany(x => x.DocumentOptions)
            .HasForeignKey(x => x.DocumentOptionTypeId);

        modelBuilder.Entity<Document>()
            .HasOne(x => x.DocumentType)
            .WithMany(x => x.Documents)
            .HasForeignKey(x => x.DocumentTypeId);

        // document attachments
        modelBuilder.Entity<DocumentAttachment>()
            .HasKey(x => new { x.DocumentId, x.PageNumber });

        modelBuilder.Entity<DocumentAttachment>()
            .HasOne(x => x.Document)
            .WithMany(x => x.DocumentAttachments)
            .HasForeignKey(x => x.DocumentId);
    }

    // Mock/Seed data to be used by all Service tests
    private static void Seed(ModelBuilder modelBuilder)
    {
        // Keep these numbers fairly low so tests run faster, since DB will be seeded
        // every time we run tests.
        var numberOfDocuments = 25;
        var numberOfGroups = 5;
        modelBuilder.Entity<DocumentType>().HasData(GenerateDocumentTypes());
        modelBuilder.Entity<Document>().HasData(GenerateDocumentSeed(numberOfDocuments));
        modelBuilder.Entity<DocumentOptionType>().HasData(GenerateDocumentOptionTypes());
        modelBuilder.Entity<DocumentOption>().HasData(GenerateDocumentOptions(numberOfDocuments));
        modelBuilder.Entity<Group>().HasData(GenerateGroupSeed(numberOfGroups));
        modelBuilder.Entity<DocumentGroup>().HasData(GenerateDocumentGroups(numberOfDocuments, numberOfGroups));
        modelBuilder.Entity<AccessCode>().HasData(GenerateAccessCodes(numberOfGroups));
        modelBuilder.Entity<AccessCodeSecurityType>().HasData(GenerateAccessCodeSecurityTypes());
        modelBuilder.Entity<AccessCodeSecurity>().HasData(GenerateAccessCodeSecurities(numberOfGroups));
    }

    private static Document[] GenerateDocumentSeed(int numberToGenerate)
    {
        var images = new List<string> {
            "https://i.ytimg.com/vi/NE2AvbROl5k/maxresdefault.jpg",
            "https://i.ytimg.com/vi/mwDwZwLcGl4/maxresdefault.jpg",
            "https://i.ytimg.com/vi/Lbeo3B0QY-4/maxresdefault.jpg",
            "https://i.ytimg.com/vi/cpaBJwHTSUQ/maxresdefault.jpg"
        };

        var documents = new List<string> {
            "Oscars_Ballot_2022.pdf",
            "Anotherr Seeded PDF File.pdf",
            "B.E.S.T Standards Correlations Fundations Grade K.pdf",
            "Wilson Cursive Teacher's Guide.pdf"
        };

        var types = GenerateDocumentTypes();

        var rnd = new Random();
        var dateTimeStart = new DateTime(1995, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        var createdDateRange = (DateTime.Today - dateTimeStart).Days;
        var list = new List<Document>();
        for (var i = 1; i <= numberToGenerate; i++)
        {
            list.Add(new Document
            {
                Id = i,
                CreatedDate = dateTimeStart.AddDays(rnd.Next(createdDateRange)),
                FilePath = documents[rnd.Next(documents.Count)],
                Title = $"Document {i}",
                Description = $"Document {i} Description",
                DocumentTypeId = types[rnd.Next(types.Length)].Id,
                ThumbnailUrl = images[rnd.Next(images.Count)],
                ThumbnailAutogenerated = rnd.Next() > (Int32.MaxValue / 2) // random bool
            });
        }
        return list.ToArray();
    }

    private static Group[] GenerateGroupSeed(int numberToGenerate)
    {
        var images = new List<string>(){
            "/stock/administrator-community-cover.png",
            "/stock/fundations-cover.png",
            "/stock/fundations-pre-k-cover.png",
        };

        var rnd = new Random();
        var list = new List<Group>();
        var dateTimeStart = new DateTime(1995, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        var createdDateRange = (DateTime.Today - dateTimeStart).Days;
        for (int i = 1; i <= numberToGenerate; i++)
        {
            list.Add(new Group
            {
                Id = i,
                CreatedDate = dateTimeStart.AddDays(rnd.Next(createdDateRange)),
                Title = $"Group {i}",
                Description = $"Group {i} description",
                CoverImageUrl = images[rnd.Next(images.Count)],
            });
        }
        return list.ToArray();
    }

    private static DocumentGroup[] GenerateDocumentGroups(int numberOfDocuments, int numberOfGroups)
    {
        var list = new List<DocumentGroup>();

        for (int i = 1; i <= numberOfGroups; i++)
        {
            var numberOfDocInGroup = i switch
            {
                1 => numberOfDocuments - 1,// for the first group, give it every document except one (orphans the last document)
                2 => 0,// for the second, give it no documents
                _ => 2,// for each group after that, give it 2 documents
            };
            for (int j = 1; j <= numberOfDocInGroup; j++)
            {
                list.Add(new DocumentGroup
                {
                    DocumentId = j,
                    GroupId = i,
                    Ordinal = j
                });
            }
        }

        return list.ToArray();
    }

    private static AccessCode[] GenerateAccessCodes(int numberOfGroups)
    {
        var list = new List<AccessCode>();
        var rnd = new Random();
        var dateTimeStart = new DateTime(1995, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        var createdDateRange = (DateTime.Today - dateTimeStart).Days;


        for (var i = 1; i <= numberOfGroups; i++)
        {
            list.Add(new AccessCode
            {
                Id = i,
                CreatedDate = dateTimeStart.AddDays(rnd.Next(createdDateRange)),
                CodeText = $"flcl{i}",
                Expiration = DateTime.Now.AddYears(1),
                Notes = $"An access code for group {i}",
                Active = true,
                AllowAnonymousEntry = false,
                GroupId = i == numberOfGroups ? i - 1 : i // we do i-1 so that the last group is orphaned
            });
        }

        return list.ToArray();
    }

    private static AccessCodeSecurityType[] GenerateAccessCodeSecurityTypes()
    {
        return new List<AccessCodeSecurityType> {
            new()
            {
                Id = 1,
                CreatedDate = DateTime.Now,
                Type = "Community",
                Description = "A Community the user must be enrolled in"
            },
            new()
            {
                Id = 2,
                CreatedDate = DateTime.Now,
                Type = "Training",
                Description = "A commTrainingunity the user must be enrolled in"
            },
            new()
            {
                Id = 3,
                CreatedDate = DateTime.Now,
                Type = "Training Template",
                Description = "A Training Template the user must be enrolled in"
            }
        }.ToArray();
    }

    private static AccessCodeSecurity[] GenerateAccessCodeSecurities(int numberOfAccessCodes)
    {
        var rnd = new Random();
        var list = new List<AccessCodeSecurity>();
        var securityTypes = GenerateAccessCodeSecurityTypes();
        // for each access code
        for (var i = 1; i <= numberOfAccessCodes - 2; i++)
        {
            var numberOfSecurities = rnd.Next(1, securityTypes.Length + 1);
            for (var j = 0; j < numberOfSecurities; j++)
            {
                list.Add(new AccessCodeSecurity
                {
                    AccessCodeSecurityTypeId = securityTypes[j].Id,
                    Value = Guid.NewGuid().ToString(),
                    AccessCodeId = i
                });
            }
        }

        return list.ToArray();
    }

    private static DocumentOptionType[] GenerateDocumentOptionTypes()
    {
        return new List<DocumentOptionType> {
            new DocumentOptionType {
                Id = 1,
                CreatedDate = DateTime.Now,
                Type = "Save",
                Description = "The ability to download and save a document"
            },
            new DocumentOptionType {
                Id = 2,
                CreatedDate = DateTime.Now,
                Type = "Print",
                Description = "The ability to print a document"
            },
        }.ToArray();
    }

    private static DocumentOption[] GenerateDocumentOptions(int numberOfDocuments)
    {
        var rnd = new Random();
        var list = new List<DocumentOption>();
        var optionTypes = GenerateDocumentOptionTypes();
        // for each document
        for (var i = 1; i <= numberOfDocuments; i++)
        {
            var numberOfOptions = rnd.Next(0, optionTypes.Length + 1);
            for (var j = 0; j < numberOfOptions; j++)
            {
                list.Add(new DocumentOption
                {
                    DocumentOptionTypeId = optionTypes[j].Id,
                    DocumentId = i
                });
            }
        }

        return list.ToArray();
    }

    private static DocumentType[] GenerateDocumentTypes()
    {
        return new List<DocumentType> {
            new()
            {
                Id = 1,
                CreatedDate = DateTime.Now,
                Type = "PDF"
            }
        }.ToArray();
    }
}