using System.Threading.Tasks;
using DocumentViewer.Services;
using DocumentViewer.Services.Interfaces;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace UnitTests;

public class AccessCodeSecurityTypeServiceTest
{
    private IAccessCodeSecurityTypeService Service;
    private TestAppDbContext DbContext;
    private SqliteConnection Connection;
    private Mock<ILogger<TestAppDbContext>> MockLogger;

    [Fact]
    public async Task GetAccessCodeSecurityTypes_ReturnsListOfTypes()
    {
        OpenConnection();
        try
        {
            SetupDbContext();
            SetupService();
            var typesResult = await Service.GetAccessCodeSecurityTypes();

            Assert.Equal(3, typesResult.Count);
            Assert.Equal("Community", typesResult[0].Type);
            Assert.Equal("Training", typesResult[1].Type);
            Assert.Equal("Training Template", typesResult[2].Type);
        }
        finally
        {
            CloseConnection();
        }
    }

    private void SetupService()
    {
        Service = new AccessCodeSecurityTypeService(DbContext);
    }

    private void OpenConnection()
    {
        Connection = new SqliteConnection("DataSource=:memory:");
        Connection.Open();
    }

    private void CloseConnection()
    {
        Connection.Close();
    }

    private void SetupDbContext()
    {
        var options = new DbContextOptionsBuilder<TestAppDbContext>()
            .UseSqlite(Connection)
            .Options;
        MockLogger = new Mock<ILogger<TestAppDbContext>>();
        DbContext = new TestAppDbContext(options, MockLogger.Object);
        DbContext.Database.EnsureCreated();
    }
}