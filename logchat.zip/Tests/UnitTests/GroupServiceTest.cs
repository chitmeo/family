using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using DocumentViewer.Database.AdminModels.Search;
using DocumentViewer.Database.EntityModels;
using DocumentViewer.Services;
using DocumentViewer.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using WilsonNet.Services;
using Xunit;

namespace UnitTests;

public class GroupServiceTest
{
    private Group Group;
    private IGroupService Service;
    private TestAppDbContext DbContext;
    private SqliteConnection Connection;
    private Mock<Repository<Group>> MockRepository;
    private Mock<ILogger<TestAppDbContext>> MockLogger;
    private Mock<IAzureService> MockAzureService;

    [Fact]
    public async Task GetGroup_ReturnsCorrespondingGroup()
    {
        OpenConnection();
        try
        {
            SetupDbContext();
            SetupMockServices();
            SetupService();
            var groupResult = await Service.GetGroup(1);

            Assert.Equal(1, groupResult.Id);
            Assert.Equal("Group 1", groupResult.Title);
        }
        finally
        {
            CloseConnection();
        }
    }

    [Fact]
    public async Task GetGroup_ReturnsNullWhenGroupDoesntExist()
    {
        OpenConnection();
        try
        {
            SetupDbContext();
            SetupMockServices();
            SetupService();
            var groupResult = await Service.GetGroup(797979);

            Assert.Null(groupResult);
        }
        finally
        {
            CloseConnection();
        }
    }

    [Fact]
    public async Task GetGroups_ReturnsListOfGroups()
    {
        OpenConnection();
        try
        {
            SetupDbContext();
            SetupMockServices();
            SetupService();

            
            var SearchModel = new Search
            {
                Filters = 
                    [
                        new Filter
                        {
                            Column = "title",
                            Value = "Group", 
                            FilterType = WilsonNet.Services.BaseDatabaseServices.Models.FilterTypeDefinition.NotEquals
                        }
                    ],
                Skip = 0,
                Take = 25,
                DateRanges = new List<DateRange>() { },
                Sort = new ()
                {
                    Column = "createdDate",
                    Direction = WilsonNet.Services.BaseDatabaseServices.Models.SortDirectionDefinition.Descending
                }
            };
            var groupResult = await Service.GetGroups(SearchModel);
            Assert.Equal(5, groupResult.Count);
        }
        finally
        {
            CloseConnection();
        }
    }

    [Fact]
    public async Task GetGroups_ReturnsEmptyListWhenNothingMatchesFilter()
    {
        OpenConnection();
        try
        {
            
            SetupDbContext();
            SetupMockServices();
            SetupService();
            var SearchModel = new Search()
            {
                Filters = [
                     new Filter{
                         Column = "title",
                         Value = "Something That Shouldnt Match",
                         FilterType = WilsonNet.Services.BaseDatabaseServices.Models.FilterTypeDefinition.Equals
                     }
                 ],
                Skip = 0,
                Take = 25,
                DateRanges = new List<DateRange>() { },
                Sort = new Sort()
                {
                    Column = "createdDate",
                    Direction = WilsonNet.Services.BaseDatabaseServices.Models.SortDirectionDefinition.Descending
                }
            };
            var groupResult = await Service.GetGroups(SearchModel);
            Assert.Empty(groupResult);
        }
        finally
        {
            CloseConnection();
        }
    }

    [Fact]
    public async Task SortDocumentsInGroup_SortsThenReturnsResult()
    {
        OpenConnection();
        try
        {
            SetupDbContext();
            SetupMockServices();
            SetupService();
            var arr = new int[] { 1, 2, 3 };
            var groupResult = await Service.SortDocumentsInGroup(1, arr);

            Assert.Equal(3, groupResult);
        }
        finally
        {
            CloseConnection();
        }
    }

    [Fact]
    public async Task GetDirectoryByAccessCode_ReturnsGroup()
    {
        OpenConnection();
        try
        {
            SetupDbContext();
            SetupMockServices();
            SetupService();
            var code = "flcl1";
            var groupResult = await Service.GetDirectoryByAccessCode(code);

            Assert.Equal(code, groupResult.CodeText);
        }
        finally
        {
            CloseConnection();
        }
    }

    [Fact]
    public async Task GetDirectorySecurityInformation_ReturnsGroup()
    {
        OpenConnection();
        try
        {
            SetupDbContext();
            SetupMockServices();
            SetupService();
            var code = "flcl1";
            var groupResult = await Service.GetDirectorySecurityInformation(code);

            Assert.NotEmpty(groupResult.RequiredSecurities);
        }
        finally
        {
            CloseConnection();
        }
    }

    [Fact]
    public async Task UpsertGroup_ReturnsGroupIdAfterUpserting()
    {
        OpenConnection();
        try
        {
            // Set up DB + Services
            SetupDbContext();
            SetupMockServices();
            MockAzureService
                .Setup(service => service.SaveThumbnailToAzure(It.IsAny<string>(), It.IsAny<IFormFile>()))
                .Returns(Task.FromResult("thumnail-url.com/1"));
            SetupService();

            // Set up data for this test
            Group = new Group
            {
                Id = 777,
                Title = "Test Group Title",
                DocumentGroups = new List<DocumentGroup> {
                    new()
                    {
                        DocumentId = 1,
                        GroupId = 777,
                        Ordinal = 1
                    }
                }
            };
            DbContext.Groups.Add(Group);
            await DbContext.SaveChangesAsync();
            IFormFile thumbnail = new FormFile(new MemoryStream("This is a dummy thumbnail"u8.ToArray()), 0, 0, "Data", "dummy.png");

            // Act
            var groupResult = await Service.UpsertGroup(Group, thumbnail);

            // Assert
            MockAzureService.Verify(service => service.SaveThumbnailToAzure(It.IsAny<string>(), It.IsAny<IFormFile>()), Times.Exactly(1));
            Assert.Equal(777, groupResult);
        }
        finally
        {
            CloseConnection();
        }
    }

    private void SetupMockServices()
    {
        MockAzureService = new Mock<IAzureService>();
        MockRepository = new Mock<Repository<Group>>(DbContext);
    }
        
    private void SetupService()
    {
        Service = new GroupService(MockRepository.Object, DbContext, MockAzureService.Object);
    }

    private void OpenConnection()
    {
        Connection = new SqliteConnection("DataSource=:memory:");
        Connection.Open();
    }

    private void CloseConnection()
    {
        Connection.Close();
    }

    private void SetupDbContext()
    {
        var options = new DbContextOptionsBuilder<TestAppDbContext>()
            .UseSqlite(Connection)
            .Options;
        MockLogger = new Mock<ILogger<TestAppDbContext>>();
        DbContext = new TestAppDbContext(options, MockLogger.Object);
        DbContext.Database.EnsureCreated();
    }
}