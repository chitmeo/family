using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DocumentViewer.Controllers;
using DocumentViewer.Services.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Moq;
using Xunit;

namespace UnitTests;

public class InitialLoadControllerTest
{
    private Mock<IDocumentService> MockDocumentService;
    private Mock<IHostEnvironment> MockHostEnvironment;
    private IConfigurationRoot MockConfiguration;

    [Fact]
    public async Task GetInitialLoad_ReturnsInitialLoadObject()
    {
        // Arrange data
        SetupMockData();

        // Arrange services
        CreateMockServices();
        var controller = new InitialLoadController(MockDocumentService.Object, MockHostEnvironment.Object, MockConfiguration);

        // Act
        var result = await controller.GetInitialLoad();

        var getInitialLoadResult = Assert.IsType<DocumentViewer.Database.ClientModels.InitialLoad>(result);

        Assert.False(getInitialLoadResult.IsProduction);
        Assert.False(getInitialLoadResult.IsComingSoon);
        Assert.False(getInitialLoadResult.IsDownForMaintenance);
        Assert.True(getInitialLoadResult.Tokens.ContainsKey("DATADOG_MONITORING_ENVIRONMENT"));
        Assert.Equal("8675309", getInitialLoadResult.CurrentBuildNumber);
    }

    private void SetupMockData()
    {
        // Set up environment vars
        Environment.SetEnvironmentVariable("DOCUMENT_VIEWER_MAINTENANCE", "false");
        Environment.SetEnvironmentVariable("DOCUMENT_VIEWER_COMING_SOON", "false");
        Environment.SetEnvironmentVariable("DD_ENV", "some-datadog-token");
        Environment.SetEnvironmentVariable("DOCVIEWER_BUILD_NUMBER", "8675309");

        var config = new Dictionary<string, string>
        {
            { "Paths:Images:Banners",  "https://teststorage.blob.core.windows.net/public/images/banners/programs/" }
        };

        MockConfiguration = new ConfigurationBuilder()
            .AddInMemoryCollection(config)
            .Build();
    }

    private void CreateMockServices()
    {
        MockHostEnvironment = new Mock<IHostEnvironment>();
        MockDocumentService = new Mock<IDocumentService>();
    }
}