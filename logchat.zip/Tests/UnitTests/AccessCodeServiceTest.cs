using System.Threading.Tasks;
using DocumentViewer.Database.AdminModels.Search;
using DocumentViewer.Database.EntityModels;
using DocumentViewer.Services;
using DocumentViewer.Services.Interfaces;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using WilsonNet.Services.BaseDatabaseServices.Models;
using Xunit;
using Filter = DocumentViewer.Database.AdminModels.Search.Filter;

namespace UnitTests;

public class AccessCodeServiceTest
{
    private IAccessCodeService Service;
    private TestAppDbContext DbContext;
    private SqliteConnection Connection;
    private Mock<Repository<AccessCode>> MockRepository;
    private Mock<ILogger<TestAppDbContext>> MockLogger;
    private Mock<IAccessCodeSecurityValueService> MockAccessCodeSecurityValueService;

    [Fact]
    public async Task GetAccessCode_ReturnsTheCorrespondingCode()
    {
        OpenConnection();
        try
        {
            SetupDbContext();
            SetupService();
            var accessCodeResult = await Service.GetAccessCode(2);
            Assert.Equal("flcl2", accessCodeResult.CodeText);
        }
        finally
        {
            CloseConnection();
        }
    }

    [Fact]
    public async Task GetAccessCode_ReturnsNullWhenRequestingNonExistentCode()
    {
        OpenConnection();
        try
        {
            SetupDbContext();
            SetupService();
            var accessCodeResult = await Service.GetAccessCode(555);
            Assert.Null(accessCodeResult);
        }
        finally
        {
            CloseConnection();
        }
    }

    [Fact]
    public async Task GetAccessCodes_ReturnsListOfAccessCodes()
    {
        OpenConnection();
        try
        {
            SetupDbContext();
            SetupService();
            var searchModel = new Search
            {
                Filters =
                [
                    new Filter
                    {
                        Column = "CodeText",
                        Value = "flcl3",
                        FilterType = FilterTypeDefinition.Contains
                    }
                ]
            };
            var accessCodeResult = await Service.GetAccessCodes(searchModel);
            Assert.Single(accessCodeResult);
        }
        finally
        {
            CloseConnection();
        }
    }

    [Fact]
    public async Task GetAccessCodes_ReturnsEmptyListWhenSearchModelHasNoMatches()
    {
        OpenConnection();
        try
        {
            SetupDbContext();
            SetupService();
            var searchModel = new Search
            {
                Filters =
                [
                    new Filter
                    {
                        Column = "CodeText",
                        Value = "lol",
                        FilterType = FilterTypeDefinition.Contains
                    }
                ]
            };
            var accessCodeResult = await Service.GetAccessCodes(searchModel);
            Assert.Empty(accessCodeResult);
        }
        finally
        {
            CloseConnection();
        }
    }

    private void SetupService()
    {
        MockAccessCodeSecurityValueService = new Mock<IAccessCodeSecurityValueService>();
        MockRepository = new Mock<Repository<AccessCode>>(DbContext);
        Service = new AccessCodeService(MockRepository.Object, DbContext, MockAccessCodeSecurityValueService.Object);
    }

    private void OpenConnection()
    {
        Connection = new SqliteConnection("DataSource=:memory:");
        Connection.Open();
    }

    private void CloseConnection()
    {
        Connection.Close();
    }

    private void SetupDbContext()
    {
        var options = new DbContextOptionsBuilder<TestAppDbContext>()
            .UseSqlite(Connection)
            .Options;
        MockLogger = new Mock<ILogger<TestAppDbContext>>();
        DbContext = new TestAppDbContext(options, MockLogger.Object);
        DbContext.Database.EnsureCreated();
    }
}