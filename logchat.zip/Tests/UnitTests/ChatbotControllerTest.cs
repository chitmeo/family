﻿using Amazon.Runtime.Internal.Util;
using DocumentViewer.Controllers;
using DocumentViewer.Database.ChatbotModels;
using DocumentViewer.Exceptions.Chatbot;
using DocumentViewer.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace UnitTests;

public class ChatbotControllerTest
{
    #region Properties
    private const string ERROR_500_MESSAGE = "There was an error generating a response. Please try again later.";

    private Mock<HttpContext> MockHttpContext;
    private Mock<ILogger<ChatbotController>> MockLooger;
    private Mock<IChatbotService> MockChatbotService;
    private ChatbotController Controller;
    #endregion

    #region SendQuestionToAssistant
    [Fact]
    public async Task SendQuestionToAssistant_HttpContext_Null()
    {
        SetupController();

        var requestData = CreateChatbotAssistantQuestion();

        var resp = await Controller.SendQuestionToAssistant(requestData, CancellationToken.None);

        MockLooger
            .Verify(
                x => x.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.IsAny<It.IsAnyType>(),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()
                ),
                Times.Once
            );

        Assert.IsType<ObjectResult>(resp);

        var (statusCode, errorResponse) = MapObjectResult((ObjectResult)resp);

        Assert.Equal(StatusCodes.Status500InternalServerError, statusCode);
        Assert.Equal(ERROR_500_MESSAGE, errorResponse.message);
    }

    [Fact]
    public async Task SendQuestionToAssistant_User_NotLoggedIn()
    {
        SetupController();

        var requestData = CreateChatbotAssistantQuestion();
        var validationErrors = CreateValidationErrors(StatusCodes.Status401Unauthorized);

        MockHttpContext
            .Setup(x => x.User)
            .Returns((ClaimsPrincipal)null);
        MockChatbotService
            .Setup(x => x.ValidateAssistantQuestion(It.IsAny<ChatbotAssistantQuestion>(), It.IsAny<ChatbotUser>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(validationErrors);

        // Set the HttpContext for the controller
        Controller.ControllerContext = new ControllerContext
        {
            HttpContext = MockHttpContext.Object
        };

        var resp = await Controller.SendQuestionToAssistant(requestData, CancellationToken.None);

        Assert.IsType<ObjectResult>(resp);

        var (statusCode, errorResponse) = MapObjectResult((ObjectResult)resp);

        Assert.Equal(StatusCodes.Status401Unauthorized, statusCode);
        Assert.Equal(validationErrors.First().Value, errorResponse.message);
    }

    [Fact]
    public async Task SendQuestionToAssistant_User_Unauthorized()
    {
        SetupController();

        var requestData = CreateChatbotAssistantQuestion();
        var principal = CreateClaimsPrincipal(IsClaimsIdentityEmpty: true);
        var validationErrors = CreateValidationErrors(StatusCodes.Status401Unauthorized);

        MockHttpContext
            .Setup(x => x.User)
            .Returns(new ClaimsPrincipal(Enumerable.Empty<ClaimsIdentity>()));
        MockChatbotService
            .Setup(x => x.ValidateAssistantQuestion(It.IsAny<ChatbotAssistantQuestion>(), It.IsAny<ChatbotUser>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(validationErrors);

        // Set the HttpContext for the controller
        Controller.ControllerContext = new ControllerContext
        {
            HttpContext = MockHttpContext.Object
        };

        var resp = await Controller.SendQuestionToAssistant(requestData, CancellationToken.None);

        Assert.IsType<ObjectResult>(resp);

        var (statusCode, errorResponse) = MapObjectResult((ObjectResult)resp);

        Assert.Equal(StatusCodes.Status401Unauthorized, statusCode);
        Assert.Equal(validationErrors.First().Value, errorResponse.message);
    }

    [Fact]
    public async Task SendQuestionToAssistant_User_NotLoggedInAuth0()
    {
        SetupController();

        var requestData = CreateChatbotAssistantQuestion();
        var principal = CreateClaimsPrincipal(IsClaimsIdentityEmpty: true);
        var validationErrors = CreateValidationErrors(StatusCodes.Status401Unauthorized);

        MockHttpContext
            .Setup(x => x.User)
            .Returns(principal);
        MockChatbotService
            .Setup(x => x.ValidateAssistantQuestion(It.IsAny<ChatbotAssistantQuestion>(), It.IsAny<ChatbotUser>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(validationErrors);

        // Set the HttpContext for the controller
        Controller.ControllerContext = new ControllerContext
        {
            HttpContext = MockHttpContext.Object
        };

        var resp = await Controller.SendQuestionToAssistant(requestData, CancellationToken.None);

        Assert.IsType<ObjectResult>(resp);

        var (statusCode, errorResponse) = MapObjectResult((ObjectResult)resp);

        Assert.Equal(StatusCodes.Status401Unauthorized, statusCode);
        Assert.Equal(validationErrors.First().Value, errorResponse.message);
    }

    [Fact]
    public async Task SendQuestionToAssistant_Answer_ContentEmpty()
    {
        SetupController();

        var requestData = CreateChatbotAssistantQuestion();
        var contactClaim = new Claim("contactid", Guid.NewGuid().ToString());
        var principal = CreateClaimsPrincipal(IsWilson: true, ContactClaim: contactClaim);
        var answer = CreateChatbotAssistantAnswer(IsContentEmpty: true);

        MockHttpContext
            .Setup(x => x.User)
            .Returns(principal);
        MockChatbotService
            .Setup(x => x.ValidateAssistantQuestion(It.IsAny<ChatbotAssistantQuestion>(), It.IsAny<ChatbotUser>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new Dictionary<int, string>());
        MockChatbotService
            .Setup(x => x.SendQuestionToAssistant(It.IsAny<ChatbotAssistantQuestion>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(answer);

        // Set the HttpContext for the controller
        Controller.ControllerContext = new ControllerContext
        {
            HttpContext = MockHttpContext.Object
        };

        var resp = await Controller.SendQuestionToAssistant(requestData, CancellationToken.None);

        MockLooger
            .Verify(
                x => x.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.IsAny<It.IsAnyType>(),
                    It.Is<ChatbotAnswerEmptyException>(ex => ex is ChatbotAnswerEmptyException),
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()
                ),
                Times.Once
            );

        Assert.IsType<ObjectResult>(resp);

        var (statusCode, errorResponse) = MapObjectResult((ObjectResult)resp);

        Assert.Equal(StatusCodes.Status500InternalServerError, statusCode);
        Assert.Equal(ERROR_500_MESSAGE, errorResponse.message);
    }

    [Fact]
    public async Task SendQuestionToAssistant_Answer_Error()
    {
        SetupController();

        var requestData = CreateChatbotAssistantQuestion();
        var principal = CreateClaimsPrincipal(IsWilson: true);

        MockHttpContext
            .Setup(x => x.User)
            .Returns(principal);
        MockChatbotService
            .Setup(x => x.ValidateAssistantQuestion(It.IsAny<ChatbotAssistantQuestion>(), It.IsAny<ChatbotUser>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new Dictionary<int, string>());
        MockChatbotService
            .Setup(x => x.SendQuestionToAssistant(It.IsAny<ChatbotAssistantQuestion>(), It.IsAny<CancellationToken>()))
            .Throws(new AzureOpenAIException());

        // Set the HttpContext for the controller
        Controller.ControllerContext = new ControllerContext
        {
            HttpContext = MockHttpContext.Object
        };

        var resp = await Controller.SendQuestionToAssistant(requestData, CancellationToken.None);

        MockLooger
            .Verify(
                x => x.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.IsAny <It.IsAnyType>(),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()
                ),
                Times.Once
            );

        Assert.IsType<ObjectResult>(resp);

        var (statusCode, errorResponse) = MapObjectResult((ObjectResult)resp);

        Assert.Equal(StatusCodes.Status500InternalServerError, statusCode);
        Assert.Equal(ERROR_500_MESSAGE, errorResponse.message);
    }

    [Fact]
    public async Task SendQuestionToAssistant_Answer_Ok()
    {
        SetupController();

        var requestData = CreateChatbotAssistantQuestion();
        var principal = CreateClaimsPrincipal(IsWilson: true);
        var answer = CreateChatbotAssistantAnswer();

        MockHttpContext
            .Setup(x => x.User)
            .Returns(principal);
        MockChatbotService
            .Setup(x => x.ValidateAssistantQuestion(It.IsAny<ChatbotAssistantQuestion>(), It.IsAny<ChatbotUser>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new Dictionary<int, string>());
        MockChatbotService
            .Setup(x => x.SendQuestionToAssistant(It.IsAny<ChatbotAssistantQuestion>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(answer);

        // Set the HttpContext for the controller
        Controller.ControllerContext = new ControllerContext
        {
            HttpContext = MockHttpContext.Object
        };

        var resp = await Controller.SendQuestionToAssistant(requestData, CancellationToken.None);

        Assert.IsType<OkObjectResult>(resp);

        var (statusCode, result) = MapOkObjectResult((OkObjectResult)resp);

        Assert.Equal(StatusCodes.Status200OK, statusCode);
        Assert.Equal(answer.ThreadId, result.ThreadId);
        Assert.Equal(answer.Role, result.Role);
        Assert.False(string.IsNullOrEmpty(result.Content));
        Assert.Equal(answer.Content, result.Content);
    }
    #endregion

    #region Setup
    private void SetupController()
    {
        MockHttpContext = new Mock<HttpContext>();
        MockLooger = new Mock<ILogger<ChatbotController>>();
        MockChatbotService = new Mock<IChatbotService>();

        Controller = new ChatbotController(MockLooger.Object, MockChatbotService.Object);
    }

    private ChatbotAssistantQuestion CreateChatbotAssistantQuestion()
    {
        return new ChatbotAssistantQuestion
        {
            AccessCode = "test-code",
            ThreadId = "test-thread",
            DocumentId = 1,
            Question = "What is the weather today?"
        };
    }

    private (int?, ChatbotErrorResponse) MapObjectResult(ObjectResult objectResult)
    {
        var statusCode = objectResult.StatusCode;
        var resp = objectResult.Value as ChatbotErrorResponse;

        return (statusCode, resp);
    }

    private Dictionary<int, string> CreateValidationErrors(int statusCode)
    {
        var errors = new Dictionary<int, string>();

        if (statusCode == StatusCodes.Status401Unauthorized)
            errors.Add(StatusCodes.Status401Unauthorized, "Token is expired.");

        return errors;
    }

    private ClaimsPrincipal CreateClaimsPrincipal(
        bool IsClaimsIdentityEmpty = false,
        bool IsWilson = false,
        Claim ContactClaim = null
    )
    {
        var principal = new ClaimsPrincipal();
        var claimsIdentities = new List<ClaimsIdentity>();

        if (!IsClaimsIdentityEmpty)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, "Test User"),
                new Claim(ClaimTypes.Email, "test@example.com"),
                new Claim(ClaimTypes.Role, "Admin"),
            };

            if (IsWilson)
            {
                if (ContactClaim == null)
                {
                    ContactClaim = new Claim("https://wilsonacademy.com/contactId", Guid.NewGuid().ToString());
                }

                claims.Add(ContactClaim);
            }

            var claimsIdentity = new ClaimsIdentity(claims, authenticationType: "TestAuth");

            claimsIdentities.Add(claimsIdentity);
        }

        principal.AddIdentities(claimsIdentities);

        return principal;
    }

    private ChatbotAssistantAnswer CreateChatbotAssistantAnswer(bool IsContentEmpty = false)
    {
        return new ChatbotAssistantAnswer
        {
            ThreadId = "test-thread",
            Role = "assistant",
            Content = !IsContentEmpty ? "The weather today is sunny with a high of 75°F." : string.Empty,
            CreatedAt = DateTimeOffset.UtcNow
        };
    }

    private (int?, ChatbotAssistantAnswer) MapOkObjectResult(OkObjectResult objectResult)
    {
        var statusCode = objectResult.StatusCode;
        var resp = objectResult.Value as ChatbotAssistantAnswer;

        return (statusCode, resp);
    }
    #endregion
}
