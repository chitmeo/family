using System;

namespace DocumentViewer.Database.AcademyModels;

public class Community
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public string Code { get; set; }
}