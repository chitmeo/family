using System;

namespace DocumentViewer.Database.AcademyModels;

public class TrainingTemplate
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public int? EventType { get; set; }
    public int? VirtualTrainingType { get; set; }
    public string Description { get; set; }
    public int? ProductLine { get; set; }
}