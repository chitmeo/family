using System;

namespace DocumentViewer.Database.AcademyModels;

public class Training
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public string TrainingNumber { get; set; }
    public string StartDate { get; set; }
    public string EndDate { get; set; }
    public int? CourseYear { get; set; }
}