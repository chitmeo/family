namespace DocumentViewer.Database.ClientModels;

public class DocumentOptionType
{
    public int Id { get; set; }
    public string Type { get; set; }
    public string Description { get; set; }
}
