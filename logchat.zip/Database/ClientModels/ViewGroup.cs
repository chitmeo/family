using System.Collections.Generic;

namespace DocumentViewer.Database.ClientModels;

public class ViewGroup
{
    public int Id { get; set; }
    public string CodeText { get; set; }
    public string Title { get; set; }
    public string Description { get; set; }
    public string CoverImageUrl { get; set; }
    public bool AllowAnonymousEntry { get; set; }
    public List<ViewDocument> Documents { get; set; }
    public bool RequiresUniversalLogin { get; set; }
    public Dictionary<int, string> RequiredSecurities { get; set; }
}