﻿using System;
using System.Collections.Generic;
using System.Linq;
using CommunityToolkit.Diagnostics;
using WilsonNet.Services.BaseDatabaseServices.Interfaces;

namespace DocumentViewer.Database.ClientModels;

public record User : IUser<string>
{
    public User(string wilsonId, string name, string email)
    {
        Guard.IsNotNullOrWhiteSpace(wilsonId);
        Guard.IsNotNullOrWhiteSpace(name);
        Guard.IsNotNullOrWhiteSpace(email);

        WilsonId = wilsonId;
        Name = name;
        Email = email;
        Roles = new List<string>();
    }
    
    public string Id { get; set; }
    public string WilsonId { get; set; }
    public string AuthId { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public DateTime LastLogin { get; set; }
    public IEnumerable<string> Roles { get; set; }
    public string Initials { get; set; }
    
    public bool HasRole(string roleId)
    {
        return Roles?.Contains(roleId) ?? false;
    }
}