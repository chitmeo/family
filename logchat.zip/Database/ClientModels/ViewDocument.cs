using System.Collections.Generic;

namespace DocumentViewer.Database.ClientModels;

public class ViewDocument
{
    public int Id { get; set; }
    public string Title { get; set; }
    public string Description { get; set; }
    public string ThumbnailUrl { get; set; }
    public string FilePath { get; set; }
    public int Ordinal { get; set; }
    public int PageOffset { get; set; }
    public bool AllowSave { get; set; }
    public bool AllowPrint { get; set; }
    public bool Watermark { get; set; }
    public bool Selectable { get; set; }
    public bool AllowAdminDelete { get; set; }
    public string IntroductoryVideoUrl { get; set; }
    public bool EnableChatbot { get; set; }
    public string SampleQuestions { get; set; }
    public IEnumerable<Attachment> Attachments { get; set; }
}
