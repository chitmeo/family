namespace DocumentViewer.Database.ClientModels;

public class DocumentType
{
    public int Id { get; set; }
    public string Type { get; set; }
}
