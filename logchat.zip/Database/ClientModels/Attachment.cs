namespace DocumentViewer.Database.ClientModels;

public class Attachment
{
    /// <summary>
    /// The page number the attachments are in relation to
    /// </summary>
    public int PageNumber { get; set; }

    /// <summary>
    /// A list of comma separated ordered resource ids (from communities) that represent the attachments
    /// </summary>
    public string ResourceIds { get; set; }
}
