using System.Collections.Generic;

namespace DocumentViewer.Database.ClientModels;

public class InitialLoad
{
    public bool IsProduction { get; set; }
    public bool IsDownForMaintenance { get; set; }
    public bool IsComingSoon { get; set; }
    public string CurrentBuildNumber { get; set; }
    public List<DocumentType> DocumentTypes { get; set; }
    public List<DocumentOptionType> DocumentOptionTypes { get; set; }
    public Dictionary<string, string> Tokens { get; set; }
    public Dictionary<string, string> ImageLocations { get; set; }
}