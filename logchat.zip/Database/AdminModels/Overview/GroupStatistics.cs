namespace DocumentViewer.Database.AdminModels.Overview;

public class GroupStatistics
{
    public int Total { get; set; }
    public int TotalWithoutDocuments { get; set; }
    public int TotalWithoutAccessCodes { get; set; }
}