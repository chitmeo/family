using System.Collections.Generic;

namespace DocumentViewer.Database.AdminModels.Overview;

public class DocumentStatistics
{
    public int Total { get; set; }
    public int TotalUnassigned { get; set; }
    public List<OverviewDocument> Recent { get; set; }
}