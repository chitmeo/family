using System;

namespace DocumentViewer.Database.AdminModels.Overview;

public class OverviewDocument
{
    public int Id { get; set; }
    public DateTime CreatedDate { get; set; }
    public DateTime ModifiedDate { get; set; }
    public string ModifiedBy { get; set; }
    public string CreatedBy { get; set; }
    public string Title { get; set; }
    public string Description { get; set; }
    public bool IsInGroup { get; set; }
}