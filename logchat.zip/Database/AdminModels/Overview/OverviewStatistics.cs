using System;

namespace DocumentViewer.Database.AdminModels.Overview;

public class OverviewStatistics
{
    public DocumentStatistics DocumentStatistics { get; set; }
    public GroupStatistics GroupStatistics { get; set; }
    public AccessCodeStatistics AccessCodeStatistics { get; set; }
    public DateTime OverviewLastCalculated { get; set; }
}