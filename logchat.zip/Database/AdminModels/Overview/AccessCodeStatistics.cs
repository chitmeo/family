namespace DocumentViewer.Database.AdminModels.Overview;

public class AccessCodeStatistics
{
    public int Total { get; set; }
    public int TotalUnsecure { get; set; }
    public int TotalSecure { get; set; }
}