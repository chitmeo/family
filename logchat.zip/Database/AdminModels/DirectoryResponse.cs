using System.Collections.Generic;
using WilsonNet.Services.EntityFrameworkServices.Entities;

namespace DocumentViewer.Database.AdminModels;

public class DirectoryResponse<T> where T : BaseEntity<int>
{
    public List<T> Data { get; set; }
    public int Total { get; set; }
}