﻿using System.Collections.Generic;
using System.Linq;
using WilsonNet.Services.BaseDatabaseServices.Models;

namespace DocumentViewer.Database.AdminModels.Search;

public class Search
{
    public int Skip { get; set; }
    public int Take { get; set; }
    public Sort Sort { get; set; }
    public Filter[] Filters { get; set; }
    public List<DateRange> DateRanges { get; set; }

    public Parameters AsParameters()
    {
        return new Parameters
        {
            Skip = Skip,
            Take = Take,
            Sort = new WilsonNet.Services.BaseDatabaseServices.Models.Sort { Column = Sort.Column, Direction = Sort.Direction },
            Filters = Filters
                .Select(f => 
                    new WilsonNet.Services.BaseDatabaseServices.Models.Filter { Column = f.Column, FilterType = f.FilterType, Value = f.Value }
                ).ToList(),
            DateRanges = DateRanges
                .Select(dr => 
                    new KeyValuePair<string, SearchDateRange>(
                        dr.Column, new SearchDateRange { Start = dr.Start, End = dr.End })
                ).ToList()
        };
    }
}
