﻿using WilsonNet.Services.BaseDatabaseServices.Models;

namespace DocumentViewer.Database.AdminModels.Search;

public class Filter
{
    public string Column { get; set; }

    public object Value { get; set; }

    public FilterTypeDefinition FilterType { get; set; }
}