﻿using WilsonNet.Services.BaseDatabaseServices.Models;

namespace DocumentViewer.Database.AdminModels.Search;

public class Sort
{
    public string Column { get; set; }

    public SortDirectionDefinition Direction { get; set; }
}