﻿using System;

namespace DocumentViewer.Database.AdminModels.Search;

public class DateRange
{
    public string Column { get; set; }
    
    public DateTime? Start { get; set; }

    public DateTime? End { get; set; }
}