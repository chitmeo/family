using System.Collections.Generic;
using DocumentViewer.Database.ClientModels;

namespace DocumentViewer.Database.AdminModels.Upsert;

public class DocumentUpsert
{
    public EntityModels.Document Document { get; init; }
    public List<int> Groups { get; init; }
    public List<int> Options { get; init; }
    public List<Attachment> Attachments { get; init; }
}