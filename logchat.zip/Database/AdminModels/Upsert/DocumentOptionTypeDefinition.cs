﻿namespace DocumentViewer.Database.AdminModels.Upsert;

public enum DocumentOptionTypeDefinition
{
    /// <summary>
    /// Apply the chatbot to the document
    /// </summary>
    Chatbot = 5
}
