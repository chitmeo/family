using System.Collections.Generic;
using WilsonNet.Services.EntityFrameworkServices.Entities;

namespace DocumentViewer.Database.EntityModels;

public class DocumentOptionType : BaseEntity<int>
{
    public string Type { get; set; }
    public string Description { get; set; }
    public virtual ICollection<DocumentOption> DocumentOptions { get; set; } = null!;
}