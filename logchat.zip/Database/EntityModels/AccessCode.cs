using System;
using System.Collections.Generic;
using WilsonNet.Services.EntityFrameworkServices.Entities;

namespace DocumentViewer.Database.EntityModels;

public class AccessCode : BaseEntity<int>
{
    public string CodeText { get; set; }
    public DateTime Expiration { get; set; }
    public string Notes { get; set; }
    public bool Active { get; set; }
    public bool AllowAnonymousEntry { get; set; }
    public int GroupId { get; set; }
    public DateTime ModifiedDate { get; set; }
    public string ModifiedBy { get; set; }
    public string CreatedBy { get; set; }
    public virtual ICollection<AccessCodeSecurity> AccessCodeSecurities { get; set; } = null!;
    public virtual Group Group { get; set; } = null!;
}