namespace DocumentViewer.Database.EntityModels;

public class DocumentGroup
{
    public int DocumentId { get; set; }
    public int GroupId { get; set; }
    public int Ordinal { get; set; }

    public virtual Document Document { get; set; } = null!;
    public virtual Group Group { get; set; } = null!;
}