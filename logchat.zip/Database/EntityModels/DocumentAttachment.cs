namespace DocumentViewer.Database.EntityModels;

public class DocumentAttachment
{
    /// <summary>
    /// The id of the document the attachments reference
    /// </summary>
    public int DocumentId { get; set; }

    /// <summary>
    /// The page number the attachments are in relation to
    /// </summary>
    public int PageNumber { get; set; }

    /// <summary>
    /// A list of comma separated ordered resource ids (from communities) that represent the attachments
    /// </summary>
    public string ResourceIds { get; set; }

    /// <summary>
    /// The virtual link to the document
    /// </summary>
    public virtual Document Document { get; set; } = null!;
}