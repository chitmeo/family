namespace DocumentViewer.Database.EntityModels;

public class ConversionLog
{
    public int NewId { get; set; }
    public int OriginalId { get; set; }
    public int Type { get; set; }
    public string StatusCode { get; set; }
    public string StatusMessage { get; set; }
}