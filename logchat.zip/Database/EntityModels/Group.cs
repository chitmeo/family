using System;
using System.Collections.Generic;
using WilsonNet.Services.EntityFrameworkServices.Entities;

namespace DocumentViewer.Database.EntityModels;

public class Group : BaseEntity<int>
{
    public string Title { get; set; }
    public string Description { get; set; }
    public string CoverImageUrl { get; set; }
    public DateTime ModifiedDate { get; set; }
    public string ModifiedBy { get; set; }
    public string CreatedBy { get; set; }
    public virtual ICollection<AccessCode> AccessCodes { get; set; } = null!;
    public virtual ICollection<DocumentGroup> DocumentGroups { get; set; } = null!;
}