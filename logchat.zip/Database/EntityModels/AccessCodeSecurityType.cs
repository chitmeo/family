using System.Collections.Generic;
using WilsonNet.Services.EntityFrameworkServices.Entities;

namespace DocumentViewer.Database.EntityModels;

public class AccessCodeSecurityType : BaseEntity<int>
{
    public string Type { get; set; }
    public string Description { get; set; }
    public virtual ICollection<AccessCodeSecurity> AccessCodeSecurities { get; set; } = null!;
}