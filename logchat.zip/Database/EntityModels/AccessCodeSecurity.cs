using System.ComponentModel.DataAnnotations.Schema;

namespace DocumentViewer.Database.EntityModels;

public class AccessCodeSecurity
{
    [NotMapped] public string Name { get; set; }
    public int AccessCodeSecurityTypeId { get; set; }
    public int AccessCodeId { get; set; }
    public string Value { get; set; }
    public virtual AccessCode AccessCode { get; set; } = null!;
    public virtual AccessCodeSecurityType AccessCodeSecurityType { get; set; } = null!;
}