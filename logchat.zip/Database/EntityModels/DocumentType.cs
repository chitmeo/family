using System.Collections.Generic;
using WilsonNet.Services.EntityFrameworkServices.Entities;

namespace DocumentViewer.Database.EntityModels;

public class DocumentType : BaseEntity<int>
{
    public string Type { get; set; }
    public virtual ICollection<Document> Documents { get; set; } = null!;
}