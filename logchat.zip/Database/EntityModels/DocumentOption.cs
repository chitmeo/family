namespace DocumentViewer.Database.EntityModels;

public class DocumentOption
{
    public int DocumentOptionTypeId { get; set; }
    public int DocumentId { get; set; }
    public virtual Document Document { get; set; } = null!;
    public virtual DocumentOptionType DocumentOptionType { get; set; } = null!;
}