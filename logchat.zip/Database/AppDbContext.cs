using System;
using System.Collections.Generic;
using System.IO;
using Azure.Core;
using Azure.Identity;
using DocumentViewer.Database.EntityModels;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace DocumentViewer.Database;

public sealed class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions options)
        : base(options)
    {
        var env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

        if (env is null or "Development") return;

        var conn = (SqlConnection)Database.GetDbConnection();
        var tokenCredential = new DefaultAzureCredential();
        var tokenRequestContext = new TokenRequestContext(["https://database.windows.net/.default"]);
        conn.AccessToken = tokenCredential.GetToken(tokenRequestContext).Token;
    }

    public DbSet<AccessCode> AccessCodes { get; set; }
    public DbSet<AccessCodeSecurity> AccessCodeSecurities { get; set; }
    public DbSet<AccessCodeSecurityType> AccessCodeSecurityTypes { get; set; }
    public DbSet<Group> Groups { get; set; }
    public DbSet<Document> Documents { get; set; }
    public DbSet<DocumentGroup> DocumentGroups { get; set; }
    public DbSet<DocumentOption> DocumentOptions { get; set; }
    public DbSet<DocumentOptionType> DocumentOptionTypes { get; set; }
    public DbSet<DocumentType> DocumentTypes { get; set; }
    public DbSet<ConversionLog> Conversions { get; set; }
    public DbSet<DocumentAttachment> DocumentAttachments { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        SetupTableConstraints(modelBuilder);
        Seed(modelBuilder);
    }

    private static void SetupTableConstraints(ModelBuilder modelBuilder)
    {
        // DocumentGroup
        modelBuilder.Entity<DocumentGroup>()
            .HasKey(x => new { x.DocumentId, x.GroupId });

        modelBuilder.Entity<DocumentGroup>()
            .HasOne(x => x.Document)
            .WithMany(x => x.DocumentGroups)
            .HasForeignKey(x => x.DocumentId);

        modelBuilder.Entity<DocumentGroup>()
            .HasOne(x => x.Group)
            .WithMany(x => x.DocumentGroups)
            .HasForeignKey(x => x.GroupId);

        // AccessCode
        modelBuilder.Entity<AccessCode>().HasAlternateKey(x => x.CodeText);
        modelBuilder.Entity<AccessCode>()
            .HasOne(x => x.Group)
            .WithMany(x => x.AccessCodes)
            .HasForeignKey(x => x.GroupId);

        modelBuilder.Entity<AccessCode>()
            .HasMany(x => x.AccessCodeSecurities)
            .WithOne(x => x.AccessCode)
            .HasForeignKey(x => x.AccessCodeId);

        // AccessCodeSecurity
        modelBuilder.Entity<AccessCodeSecurity>()
            .HasKey(x => new { x.AccessCodeId, x.AccessCodeSecurityTypeId });

        modelBuilder.Entity<AccessCodeSecurity>()
            .HasOne(x => x.AccessCodeSecurityType)
            .WithMany(x => x.AccessCodeSecurities)
            .HasForeignKey(x => x.AccessCodeSecurityTypeId);


        // DocumentOption
        modelBuilder.Entity<DocumentOption>()
            .HasKey(x => new { x.DocumentId, x.DocumentOptionTypeId });

        modelBuilder.Entity<DocumentOption>()
            .HasOne(x => x.DocumentOptionType)
            .WithMany(x => x.DocumentOptions)
            .HasForeignKey(x => x.DocumentOptionTypeId);

        modelBuilder.Entity<Document>()
            .HasOne(x => x.DocumentType)
            .WithMany(x => x.Documents)
            .HasForeignKey(x => x.DocumentTypeId);

        modelBuilder.Entity<ConversionLog>()
            .HasKey(x => new { x.OriginalId, x.Type });

        // document attachments
        modelBuilder.Entity<DocumentAttachment>()
            .HasKey(x => new { x.DocumentId, x.PageNumber });

        modelBuilder.Entity<DocumentAttachment>()
            .HasOne(x => x.Document)
            .WithMany(x => x.DocumentAttachments)
            .HasForeignKey(x => x.DocumentId);
    }

    private static void Seed(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<DocumentType>().HasData(GenerateDocumentTypes());
        modelBuilder.Entity<DocumentOptionType>().HasData(GenerateDocumentOptionTypes());
        modelBuilder.Entity<AccessCodeSecurityType>().HasData(GenerateAccessCodeSecurityTypes());
    }

    private static AccessCodeSecurityType[] GenerateAccessCodeSecurityTypes()
    {
        return new List<AccessCodeSecurityType>
        {
            new AccessCodeSecurityType
            {
                Id = 1,
                CreatedDate = DateTime.UtcNow,
                Type = "Community",
                Description = "A Community the user must be enrolled in"
            },
            new AccessCodeSecurityType
            {
                Id = 2,
                CreatedDate = DateTime.UtcNow,
                Type = "Training",
                Description = "A Training the user must be enrolled in"
            },
            new AccessCodeSecurityType
            {
                Id = 3,
                CreatedDate = DateTime.UtcNow,
                Type = "Training Template",
                Description = "A Training Template the user must be enrolled in"
            }
        }.ToArray();
    }

    private static DocumentOptionType[] GenerateDocumentOptionTypes()
    {
        return new List<DocumentOptionType>
        {
            new DocumentOptionType
            {
                Id = 1,
                CreatedDate = DateTime.UtcNow,
                Type = "Save",
                Description = "The ability to download and save a document"
            },
            new DocumentOptionType
            {
                Id = 2,
                CreatedDate = DateTime.UtcNow,
                Type = "Print",
                Description = "The ability to print a document"
            },
            new DocumentOptionType
            {
                Id = 3,
                CreatedDate = DateTime.UtcNow,
                Type = "Watermark",
                Description = "Applies a watermark to the document"
            },
            new DocumentOptionType
            {
                Id = 4,
                CreatedDate = DateTime.UtcNow,
                Type = "Selectable",
                Description = "The ability to select text within a document"
            }
        }.ToArray();
    }

    private static DocumentType[] GenerateDocumentTypes()
    {
        return new List<DocumentType>
        {
            new DocumentType
            {
                Id = 1,
                CreatedDate = DateTime.UtcNow,
                Type = "PDF"
            }
        }.ToArray();
    }
}

/// <summary>
/// Used for when "Startup" was not called but an instance of ApplicationContext
/// needs to be configured. Specifically for use in the build pipelines which
/// create ef migrations scripts using 
/// </summary>
public class ApplicationContextFactory : IDesignTimeDbContextFactory<AppDbContext>
{
    public AppDbContext CreateDbContext(string[] args)
    {
        // Build config
        IConfiguration config = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .AddJsonFile(
                $"appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production"}.json",
                optional: true)
            .Build();

        var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
        optionsBuilder.UseSqlServer(config.GetConnectionString("ApplicationContextConnectionString"));
        return new AppDbContext(optionsBuilder.Options);
    }
}