﻿using System.Threading.Tasks;
using DocumentViewer.Database.EntityModels;
using Microsoft.EntityFrameworkCore;
using WilsonNet.Services.EntityFrameworkServices.Entities;

namespace DocumentViewer.Database;

public class DocViewerCollectionsContext(AppDbContext db) : IDocViewerCollectionsContext
{
    public DbSet<AccessCode> AccessCodes => db.AccessCodes;
    public DbSet<AccessCodeSecurity> AccessCodeSecurities => db.AccessCodeSecurities;
    public DbSet<AccessCodeSecurityType> AccessCodeSecurityTypes => db.AccessCodeSecurityTypes;
    public DbSet<Group> Groups => db.Groups;
    public DbSet<Document> Documents => db.Documents;
    public DbSet<DocumentGroup> DocumentGroups => db.DocumentGroups;
    public DbSet<DocumentOption> DocumentOptions => db.DocumentOptions;
    public DbSet<DocumentOptionType> DocumentOptionTypes => db.DocumentOptionTypes;
    public DbSet<DocumentType> DocumentTypes => db.DocumentTypes;
    public DbSet<DocumentAttachment> DocumentAttachments => db.DocumentAttachments;
    
    public Task<int> SaveChangesAsync()
    {
        return db.SaveChangesAsync();
    }

    public Task<int> Upsert(BaseEntity<int> entity)
    {
        db.Entry(entity).State = entity.Id == 0 ? EntityState.Added : EntityState.Modified;
        return db.SaveChangesAsync();
    }
}