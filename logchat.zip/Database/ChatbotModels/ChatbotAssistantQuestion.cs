﻿namespace DocumentViewer.Database.ChatbotModels;

public class ChatbotAssistantQuestion
{
    public string AccessCode { get; set; }
    /// <summary>
    /// The Document ID is required
    /// </summary>
    public int? DocumentId { get; set; }
    public string ThreadId { get; set; }
    public string Question { get; set; }
}
