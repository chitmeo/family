﻿using System;

namespace DocumentViewer.Database.ChatbotModels;

public class ChatbotAssistantAnswer
{
    public string ThreadId { get; set; }
    public string Role { get; set; }
    public string Content { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
}
