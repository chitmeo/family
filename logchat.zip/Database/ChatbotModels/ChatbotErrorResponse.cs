﻿namespace DocumentViewer.Database.ChatbotModels;

public class ChatbotErrorResponse
{
    public bool success { get; set; }
    public string message { get; set; }

    public ChatbotErrorResponse(string message)
    {
        success = false;
        this.message = message;
    }
}
