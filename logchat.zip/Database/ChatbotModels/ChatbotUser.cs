﻿using DocumentViewer.Extensions.Common;
using Microsoft.AspNetCore.Http;
using System;

namespace DocumentViewer.Database.ChatbotModels;

public class ChatbotUser
{
    public Guid? Id { get; set; }
    public bool IsAuthenticated { get; set; }

    public static ChatbotUser Map(HttpContext httpContext)
    {
        return new ChatbotUser
        {
            Id = httpContext.GetContactId(),
            IsAuthenticated = httpContext.User?.Identity?.IsAuthenticated ?? false
        };
    }
}
