using System.Threading.Tasks;
using DocumentViewer.Database.EntityModels;
using Microsoft.EntityFrameworkCore;
using WilsonNet.Services.EntityFrameworkServices.Entities;

namespace DocumentViewer.Database;

public interface IDocViewerCollectionsContext
{
    public DbSet<AccessCode> AccessCodes { get; }
    public DbSet<AccessCodeSecurity> AccessCodeSecurities { get; }
    public DbSet<AccessCodeSecurityType> AccessCodeSecurityTypes { get; }
    public DbSet<Group> Groups { get; }
    public DbSet<Document> Documents { get; }
    public DbSet<DocumentGroup> DocumentGroups { get; }
    public DbSet<DocumentOption> DocumentOptions { get; }
    public DbSet<DocumentOptionType> DocumentOptionTypes { get; }
    public DbSet<DocumentType> DocumentTypes { get; }
    public DbSet<DocumentAttachment> DocumentAttachments { get; }
        
    Task<int> SaveChangesAsync();
    Task<int> Upsert(BaseEntity<int> entity);
}