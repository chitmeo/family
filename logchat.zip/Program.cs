using System;
using Autofac.Extensions.DependencyInjection;
using CommunityToolkit.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Serilog;
using WilsonNet.ExtensionMethods.IHostBuilderExtensions;

namespace DocumentViewer;

public static class Program
{
    public static void Main(string[] args)
    {
        SetupLogging();

        try
        {
            Log.Information("Starting up");
            CreateHostBuilder(args)
                .UseSerilog()
                .UseServiceProviderFactory(new AutofacServiceProviderFactory())
                .AddKeyVaultConfiguration("KeyVault", true)
                .Build().Run();
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, "Application start-up failed");
        }
        finally
        {
            Log.CloseAndFlush();
        }
    }

    public static IHostBuilder CreateHostBuilder(string[] args) =>
        Host.CreateDefaultBuilder(args)
            .ConfigureWebHostDefaults(webBuilder =>
            {
                webBuilder
                    .UseStartup<Startup>()
                    .ConfigureKestrel(options =>
                    {
                        //550mb limit
                        options.Limits.MaxRequestBodySize = 550000000;
                    });
            });

    private static void SetupLogging()
    {
        string apiKey = Environment.GetEnvironmentVariable("DD_API_KEY");
        string environment = Environment.GetEnvironmentVariable("DD_ENV");
        string serviceName = Environment.GetEnvironmentVariable("DD_SERVICE");

        // these environmental variables missing is a critical failure. 
        Guard.IsNotNullOrWhiteSpace(apiKey);
        Guard.IsNotNullOrWhiteSpace(environment);

        Log.Logger = new LoggerConfiguration()
            .Enrich.FromLogContext()
            .MinimumLevel.Error()
            .Enrich.WithProperty("Application Name", serviceName)
            .WriteTo.Console()
            .WriteTo.DatadogLogs(apiKey, source: "Serilog", service: serviceName,
                tags: ["env:" + environment])
            .CreateLogger();
    }
}