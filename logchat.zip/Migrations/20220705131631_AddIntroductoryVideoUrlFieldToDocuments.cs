﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DocumentViewer.Migrations
{
    public partial class AddIntroductoryVideoUrlFieldToDocuments : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "IntroductoryVideoUrl",
                table: "Documents",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 7, 5, 9, 16, 31, 522, DateTimeKind.Local).AddTicks(2044));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 7, 5, 9, 16, 31, 522, DateTimeKind.Local).AddTicks(2048));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedDate",
                value: new DateTime(2022, 7, 5, 9, 16, 31, 522, DateTimeKind.Local).AddTicks(2050));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 7, 5, 9, 16, 31, 522, DateTimeKind.Local).AddTicks(2010));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 7, 5, 9, 16, 31, 522, DateTimeKind.Local).AddTicks(2017));

            migrationBuilder.UpdateData(
                table: "DocumentTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 7, 5, 9, 16, 31, 522, DateTimeKind.Local).AddTicks(1746));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IntroductoryVideoUrl",
                table: "Documents");

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 20, 11, 14, 30, 641, DateTimeKind.Local).AddTicks(8405));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 20, 11, 14, 30, 641, DateTimeKind.Local).AddTicks(8414));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 20, 11, 14, 30, 641, DateTimeKind.Local).AddTicks(8421));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 20, 11, 14, 30, 641, DateTimeKind.Local).AddTicks(8351));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 20, 11, 14, 30, 641, DateTimeKind.Local).AddTicks(8363));

            migrationBuilder.UpdateData(
                table: "DocumentTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 20, 11, 14, 30, 641, DateTimeKind.Local).AddTicks(8149));
        }
    }
}
