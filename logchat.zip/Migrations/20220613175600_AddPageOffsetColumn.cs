﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DocumentViewer.Migrations
{
    public partial class AddPageOffsetColumn : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "PageOffset",
                table: "Documents",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 13, 13, 55, 59, 841, DateTimeKind.Local).AddTicks(2405));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 13, 13, 55, 59, 841, DateTimeKind.Local).AddTicks(2408));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 13, 13, 55, 59, 841, DateTimeKind.Local).AddTicks(2410));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 13, 13, 55, 59, 841, DateTimeKind.Local).AddTicks(2382));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 13, 13, 55, 59, 841, DateTimeKind.Local).AddTicks(2386));

            migrationBuilder.UpdateData(
                table: "DocumentTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 13, 13, 55, 59, 841, DateTimeKind.Local).AddTicks(2160));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PageOffset",
                table: "Documents");

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 5, 24, 11, 21, 1, 86, DateTimeKind.Local).AddTicks(8610));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 5, 24, 11, 21, 1, 86, DateTimeKind.Local).AddTicks(8614));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedDate",
                value: new DateTime(2022, 5, 24, 11, 21, 1, 86, DateTimeKind.Local).AddTicks(8616));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 5, 24, 11, 21, 1, 86, DateTimeKind.Local).AddTicks(8590));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 5, 24, 11, 21, 1, 86, DateTimeKind.Local).AddTicks(8595));

            migrationBuilder.UpdateData(
                table: "DocumentTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 5, 24, 11, 21, 1, 86, DateTimeKind.Local).AddTicks(8414));
        }
    }
}
