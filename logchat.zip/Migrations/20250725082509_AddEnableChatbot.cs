﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DocumentViewer.Migrations
{
    /// <inheritdoc />
    public partial class AddEnableChatbot : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "AssistantId",
                table: "Documents",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SampleQuestions",
                table: "Documents",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.InsertData(
                table: "DocumentOptionTypes",
                columns: new[] { "Id", "CreatedDate", "Description", "Type" },
                values: new object[] { 5, new DateTime(2025, 7, 25, 8, 30, 55, 25, DateTimeKind.Utc).AddTicks(6587), "Apply the chatbot to the document", "Chatbot" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AssistantId",
                table: "Documents");

            migrationBuilder.DropColumn(
                name: "SampleQuestions",
                table: "Documents");

            migrationBuilder.DeleteData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 5);
        }
    }
}
