﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DocumentViewer.Migrations
{
    public partial class AddIsSelectable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "DocumentOptionTypes",
                columns: new[] { "Id", "CreatedDate", "Description", "Type" },
                values: new object[] { 4, new DateTime(2024, 4, 4, 17, 32, 53, 667, DateTimeKind.Utc).AddTicks(6573), "The ability to select text within a document", "Selectable" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 4);
        }
    }
}
