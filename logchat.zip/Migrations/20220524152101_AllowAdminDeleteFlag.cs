﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DocumentViewer.Migrations
{
    public partial class AllowAdminDeleteFlag : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "AllowAdminDelete",
                table: "Documents",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 5, 24, 11, 21, 1, 86, DateTimeKind.Local).AddTicks(8610));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 5, 24, 11, 21, 1, 86, DateTimeKind.Local).AddTicks(8614));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedDate",
                value: new DateTime(2022, 5, 24, 11, 21, 1, 86, DateTimeKind.Local).AddTicks(8616));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 5, 24, 11, 21, 1, 86, DateTimeKind.Local).AddTicks(8590));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 5, 24, 11, 21, 1, 86, DateTimeKind.Local).AddTicks(8595));

            migrationBuilder.UpdateData(
                table: "DocumentTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 5, 24, 11, 21, 1, 86, DateTimeKind.Local).AddTicks(8414));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AllowAdminDelete",
                table: "Documents");

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 14, 11, 25, 34, 821, DateTimeKind.Local).AddTicks(6628));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 14, 11, 25, 34, 821, DateTimeKind.Local).AddTicks(6632));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 14, 11, 25, 34, 821, DateTimeKind.Local).AddTicks(6634));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 14, 11, 25, 34, 821, DateTimeKind.Local).AddTicks(6601));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 14, 11, 25, 34, 821, DateTimeKind.Local).AddTicks(6606));

            migrationBuilder.UpdateData(
                table: "DocumentTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 14, 11, 25, 34, 821, DateTimeKind.Local).AddTicks(6399));
        }
    }
}
