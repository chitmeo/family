﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DocumentViewer.Migrations
{
    public partial class DocumentAttachments : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "DocumentAttachments",
                columns: table => new
                {
                    DocumentId = table.Column<int>(type: "int", nullable: false),
                    PageNumber = table.Column<int>(type: "int", nullable: false),
                    ResourceIds = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DocumentAttachments", x => new { x.DocumentId, x.PageNumber });
                    table.ForeignKey(
                        name: "FK_DocumentAttachments_Documents_DocumentId",
                        column: x => x.DocumentId,
                        principalTable: "Documents",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 14, 11, 25, 34, 821, DateTimeKind.Local).AddTicks(6628));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 14, 11, 25, 34, 821, DateTimeKind.Local).AddTicks(6632));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 14, 11, 25, 34, 821, DateTimeKind.Local).AddTicks(6634));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 14, 11, 25, 34, 821, DateTimeKind.Local).AddTicks(6601));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 14, 11, 25, 34, 821, DateTimeKind.Local).AddTicks(6606));

            migrationBuilder.UpdateData(
                table: "DocumentTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 14, 11, 25, 34, 821, DateTimeKind.Local).AddTicks(6399));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DocumentAttachments");

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 2, 12, 18, 44, 217, DateTimeKind.Local).AddTicks(5585));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 2, 12, 18, 44, 217, DateTimeKind.Local).AddTicks(5590));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 2, 12, 18, 44, 217, DateTimeKind.Local).AddTicks(5592));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 2, 12, 18, 44, 217, DateTimeKind.Local).AddTicks(5534));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 2, 12, 18, 44, 217, DateTimeKind.Local).AddTicks(5539));

            migrationBuilder.UpdateData(
                table: "DocumentTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 3, 2, 12, 18, 44, 217, DateTimeKind.Local).AddTicks(5403));
        }
    }
}
