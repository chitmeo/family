﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DocumentViewer.Migrations
{
    public partial class CreatedAndModifiedFields : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CreatedBy",
                table: "Groups",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ModifiedBy",
                table: "Groups",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedDate",
                table: "Groups",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "CreatedBy",
                table: "Documents",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ModifiedBy",
                table: "Documents",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedDate",
                table: "Documents",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "CreatedBy",
                table: "AccessCodes",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ModifiedBy",
                table: "AccessCodes",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedDate",
                table: "AccessCodes",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 20, 11, 14, 30, 641, DateTimeKind.Local).AddTicks(8405));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 20, 11, 14, 30, 641, DateTimeKind.Local).AddTicks(8414));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 20, 11, 14, 30, 641, DateTimeKind.Local).AddTicks(8421));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 20, 11, 14, 30, 641, DateTimeKind.Local).AddTicks(8351));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 20, 11, 14, 30, 641, DateTimeKind.Local).AddTicks(8363));

            migrationBuilder.UpdateData(
                table: "DocumentTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 20, 11, 14, 30, 641, DateTimeKind.Local).AddTicks(8149));

            migrationBuilder.Sql("Update a set a.ModifiedDate = b.CreatedDate from dbo.Documents a left join Documents as b on a.Id = b.Id");
            migrationBuilder.Sql("Update a set a.ModifiedDate = b.CreatedDate from dbo.Groups a left join Groups as b on a.Id = b.Id");
            migrationBuilder.Sql("Update a set a.ModifiedDate = b.CreatedDate from dbo.AccessCodes a left join AccessCodes as b on a.Id = b.Id");
            migrationBuilder.Sql("Update dbo.Documents set CreatedBy='System'");
            migrationBuilder.Sql("Update dbo.Groups set CreatedBy='System'");
            migrationBuilder.Sql("Update dbo.AccessCodes set CreatedBy='System'");
            migrationBuilder.Sql("Update dbo.Documents set ModifiedBy='System'");
            migrationBuilder.Sql("Update dbo.Groups set ModifiedBy='System'");
            migrationBuilder.Sql("Update dbo.AccessCodes set ModifiedBy='System'");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CreatedBy",
                table: "Groups");

            migrationBuilder.DropColumn(
                name: "ModifiedBy",
                table: "Groups");

            migrationBuilder.DropColumn(
                name: "ModifiedDate",
                table: "Groups");

            migrationBuilder.DropColumn(
                name: "CreatedBy",
                table: "Documents");

            migrationBuilder.DropColumn(
                name: "ModifiedBy",
                table: "Documents");

            migrationBuilder.DropColumn(
                name: "ModifiedDate",
                table: "Documents");

            migrationBuilder.DropColumn(
                name: "CreatedBy",
                table: "AccessCodes");

            migrationBuilder.DropColumn(
                name: "ModifiedBy",
                table: "AccessCodes");

            migrationBuilder.DropColumn(
                name: "ModifiedDate",
                table: "AccessCodes");

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 13, 13, 55, 59, 841, DateTimeKind.Local).AddTicks(2405));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 13, 13, 55, 59, 841, DateTimeKind.Local).AddTicks(2408));

            migrationBuilder.UpdateData(
                table: "AccessCodeSecurityTypes",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 13, 13, 55, 59, 841, DateTimeKind.Local).AddTicks(2410));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 13, 13, 55, 59, 841, DateTimeKind.Local).AddTicks(2382));

            migrationBuilder.UpdateData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 13, 13, 55, 59, 841, DateTimeKind.Local).AddTicks(2386));

            migrationBuilder.UpdateData(
                table: "DocumentTypes",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2022, 6, 13, 13, 55, 59, 841, DateTimeKind.Local).AddTicks(2160));
        }
    }
}
