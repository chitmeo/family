﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DocumentViewer.Migrations
{
    public partial class AddHasWatermark : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "DocumentOptionTypes",
                columns: new[] { "Id", "CreatedDate", "Description", "Type" },
                values: new object[] { 3, new DateTime(2023, 5, 10, 9, 46, 9, 357, DateTimeKind.Local).AddTicks(8159), "Applies a watermark to the document", "Watermark" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "DocumentOptionTypes",
                keyColumn: "Id",
                keyValue: 3);
        }
    }
}
