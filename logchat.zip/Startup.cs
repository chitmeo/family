using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using AspNetCoreRateLimit;
using Autofac;
using Azure.Identity;
using Azure.Storage.Blobs;
using DocumentViewer.Database.AcademyModels;
using DocumentViewer.Database.AdminModels;
using DocumentViewer.Database.AdminModels.Overview;
using DocumentViewer.Database.AdminModels.Search;
using DocumentViewer.Database.ClientModels;
using DocumentViewer.Database.EntityModels;
using DocumentViewer.Middleware;
using DocumentViewer.Services.Interfaces;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.SpaServices.AngularCli;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Wilson.Net.Authentication;
using Wilson.Net.Authentication.Models;
using WilsonNet;
using WilsonNet.Generators;
using WilsonNet.Services.BaseDatabaseServices.Models;
using WilsonNet.Services.EntityFrameworkServices.Entities;
using Document = DocumentViewer.Database.EntityModels.Document;
using Filter = DocumentViewer.Database.AdminModels.Search.Filter;
using Group = DocumentViewer.Database.EntityModels.Group;
using Sort = DocumentViewer.Database.AdminModels.Search.Sort;

namespace DocumentViewer;

public class Startup
{
    private readonly IConfiguration _configuration;
    private readonly IWebHostEnvironment _env;
    public Startup(IConfiguration configuration, IWebHostEnvironment env)
    {
        _configuration = configuration;
        _env = env;
    }

    // This method gets called by the runtime. Use this method to add services to the container.
    public void ConfigureServices(IServiceCollection services)
    {
        services.AddControllersWithViews();
        services.AddHttpClient();
        services.AddHttpContextAccessor();
        // In production, the Angular files will be served from this directory
        services.AddSpaStaticFiles(configuration =>
        {
            configuration.RootPath = "ClientApp/dist";
        });

        if (_env.IsDevelopment())
        {
            services.AddDataProtection()
                .SetApplicationName("DocumentViewer")
                .PersistKeysToFileSystem(new DirectoryInfo(Path.Combine(Path.GetTempPath(), "document-viewer-keys")));
        }
        else
        {
            var container = new BlobContainerClient(_configuration["AzureStorageConnectionString"], "document-viewer-data-protection");
            container.CreateIfNotExists();

            var blobClient = container.GetBlobClient("keys.xml");
            services.AddDataProtection()
                .SetApplicationName("DocumentViewer")
                .PersistKeysToAzureBlobStorage(blobClient)
                .ProtectKeysWithAzureKeyVault(
                    new Uri($"https://{_configuration.GetValue<string>("KeyVault")}.vault.azure.net/keys/DocumentViewerDataProtectionEncryptionKey/"),
                    new DefaultAzureCredential());
        }

        services.AddMvc(option => option.EnableEndpointRouting = false).AddNewtonsoftJson();

        services.AddControllers().AddNewtonsoftJson(options => options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore);

        services.RegisterWilsonLibrary();
        services.RegisterAuthenticationServices(new AuthConfig
        (
            _configuration["Auth0:ApiAudience"],
            "Auth0",
            _configuration["Auth0:Domain"],
            "Auth0",
            _configuration["Auth0:ClientId"],
            _configuration["DocViewerAuthSecret"]
        )
        {
            AdditionalScopes = ["read:members", "read:registrant", "read:training", "read:trainingtemplate"],
            OnRemoteFailure = context =>
            {
                if (context.Failure is null) return Task.CompletedTask;

                if (context.Failure.Message.Contains("correlation failed", StringComparison.OrdinalIgnoreCase))
                {
                    context.Response.Redirect("/");
                    context.HandleResponse(); // Suppress the exception
                }
                else if (context.Failure.Message.Contains("access_denied", StringComparison.OrdinalIgnoreCase) ||
                         context.Failure.Message.Contains("invalid_request", StringComparison.OrdinalIgnoreCase))
                {
                    var failure = context.Failure.Message.Split(",");
                    var failureDictionary = failure.Select(pair => pair.Split(":"))
                        .ToDictionary(p => p[0].Trim(), p => p.Length > 1 ? p[1].Trim() : "");
                    var failureMessage = failureDictionary.TryGetValue("error_description", out var desc)
                        ? desc.Trim('\'')
                        : "An error occurred while attempting to login.";

                    var challengeProps = new AuthenticationProperties
                    {
                        RedirectUri = context.Properties?.RedirectUri
                    };

                    challengeProps.Items.Add("prompt", "login");
                    challengeProps.Items.Add("error", failureMessage);

                    context.HandleResponse(); // Suppress the exception

                    return context.HttpContext.ChallengeAsync("Auth0", challengeProps);
                }

                return Task.CompletedTask;
            }
        });

        AddRateLimiting(services, _configuration);
    }

    // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
        app.Use(async (context, next) =>
        {
            SetHeaders(context);
            await next();
        });

        if (env.IsDevelopment())
        {
            GenerateTypescriptDefinitionFile();
            app.UseDeveloperExceptionPage();
        }
        else
        {
            app.UseExceptionHandler("/Error");
            // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
            app.UseHsts();
        }

        pdftron.PDFNet.Initialize(_configuration["PdfTronLicenseKey"]);

        app.InitializeAzureService(_configuration["AzureAccessKey"], _configuration["AzureStorageAccountName"]);

        app.UseMiddleware<ClientIdHeaderMiddleware>();
        app.UseClientRateLimiting();
        app.UseHttpsRedirection();

        SetupStaticFiles(app, env);

        app.UseRouting();
        app.UseAuthentication();
        app.UseAuthorization();

        app.UseEndpoints(endpoints =>
        {
            endpoints.MapControllerRoute(
                name: "default",
                pattern: "{controller}/{action=Index}/{id?}");
        });

        using (var serviceScope = app.ApplicationServices.GetRequiredService<IServiceScopeFactory>().CreateScope())
        {
            if (!env.IsProduction())
            {
                serviceScope.ServiceProvider.GetService<IWarmUpSeederService>().Seed();
            }
        }

        app.UseSpa(spa =>
        {
            // To learn more about options for serving an Angular SPA from ASP.NET Core,
            // see https://go.microsoft.com/fwlink/?linkid=864501
            spa.Options.SourcePath = "ClientApp/dist";

            if (env.IsDevelopment())
            {
                spa.UseAngularCliServer(npmScript: "start");
            }
        });
    }

    public void ConfigureContainer(ContainerBuilder builder)
    {
        builder.RegisterModule(new DefaultModule(_configuration));
    }

    private static void SetupStaticFiles(IApplicationBuilder app, IWebHostEnvironment env)
    {
        var provider = new FileExtensionContentTypeProvider();
        // Add new MIME type mappings required by pdftron
        provider.Mappings[".res"] = "application/octet-stream";
        provider.Mappings[".pexe"] = "application/x-pnacl";
        provider.Mappings[".nmf"] = "application/octet-stream";
        provider.Mappings[".mem"] = "application/octet-stream";
        provider.Mappings[".wasm"] = "application/wasm";
        provider.Mappings[".xod"] = "application/octet-stream";

        app.UseStaticFiles();

        app.UseStaticFiles(new StaticFileOptions
        {
            RequestPath = "/assets",
            FileProvider = new PhysicalFileProvider(
                Path.Combine(Directory.GetCurrentDirectory(), @"ClientApp\dist\assets")),
            ContentTypeProvider = provider
        });

        if (!env.IsDevelopment())
        {
            app.UseSpaStaticFiles();
        }
    }

    private static void SetHeaders(HttpContext context)
    {
        context.Response.Headers.Append("Cache-Control", "no-store,no-cache");
        context.Response.Headers.Append("Pragma", "no-cache");
        context.Response.Headers.Append("X-Content-Type-Options", "nosniff");

        var scriptSrcElem = string.Join(' ',
            // fontAwesome
            "https://kit.fontawesome.com",
            "'sha256-fynwwNeatXCacHQ6swcxEezVAL4vYjU1A7aWVSTlQ+Q='",
            "'sha256-3Ey30PJkNcf9LrK7CIqrujoq79a+uJqKgYsaBDj15Eo='",
            "'sha256-fW9cA2AUnTLeeXg+oxSDoZHh5MhJOPnVA4vBFrTaPCU='",
            //google analytics
            "https://www.googletagmanager.com",
            "https://www.google-analytics.com",
            // index page "no js detected"
            "'sha256-kgwMF4D/4Z1VFylgyS6yU54470jVNCuTA2Uhfgr8FYM='",
            // pdftron webviewer
            "'sha256-8VWEfV1MHXcCbi/lcOneF2oDbPdYwskZilS/Xih/+zc='",
            "'sha256-lHgryqiyITfa3GlKd5zc0Wy+Yz/7MTXFKAHsC/7mOy0='"
        );

        var connectSrc = string.Join(' ',
            "https://ka-p.fontawesome.com",
            "https://www.google-analytics.com",
            "https://rum-http-intake.logs.datadoghq.com",
            "https://browser-intake-datadoghq.com",
            "https://dev-community.wilsonacademy.com",
            "https://community.wilsonacademy.com",
            "https://devacademystorage.blob.core.windows.net",
            "https://prodacademystorage.blob.core.windows.net",
            "https://api-js.mixpanel.com"
        );

        var frameSrc = string.Join(' ',
            "https://videos.sproutvideo.com",
            "https://vimeo.com/",
            "https://player.vimeo.com/",
            "https://dev-auth.wilsonacademy.com",
            "https://auth.wilsonacademy.com"
        );

        var imgSrc = string.Join(' ',
            "https://www.google-analytics.com",
            "https://devacademystorage.blob.core.windows.net",
            "https://prodacademystorage.blob.core.windows.net",
            "https://devcommunities.blob.core.windows.net",
            "https://prodcommunities.blob.core.windows.net",
            "https://images.sproutvideo.com"
        );

        var cspHeaders = string.Join(' ',
            "default-src 'self'; base-uri 'self';",
            // unsafe-eval required for pdftron, which sucks
            "script-src 'self' 'unsafe-eval';",
            $"script-src-elem 'self' blob: {scriptSrcElem};",
            $"connect-src 'self' {connectSrc};",
            $"frame-src 'self' {frameSrc};",
            "frame-ancestors 'self' *.wilsonacademy.com wilsonacademy.com;",
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;",
            "font-src 'self' data: https://fonts.gstatic.com https://filespub.wilsonacademy.com;",
            $"img-src 'self' data: blob: {imgSrc};",
            "object-src 'none';"
        );

        context.Response.Headers.Append("Content-Security-Policy", cspHeaders);
    }

    private static void GenerateTypescriptDefinitionFile()
    {
        List<Type> singleTypes =
        [
            typeof(BaseEntity<>), typeof(DatabaseEntity<>), typeof(Search), typeof(Filter), typeof(Sort),
            typeof(DateRange), typeof(SortDirectionDefinition), typeof(FilterTypeDefinition)
        ];
        List<Type> entities =
        [
            typeof(AccessCode), typeof(AccessCodeSecurity), typeof(AccessCodeSecurityType), typeof(Document),
            typeof(DocumentAttachment), typeof(DocumentOption), typeof(DocumentGroup), typeof(Group)
        ];

        var assemblyNamespaces = new Dictionary<Assembly, List<string>>
        {
            {
                typeof(Community).Assembly,
                [
                    typeof(DirectoryResponse<>).Namespace,
                    typeof(OverviewStatistics).Namespace,
                    typeof(InitialLoad).Namespace,
                    typeof(Search).Namespace
                ]
            }
        };

        TypescriptInterfaceGenerator.GenerateWilsonDefinitionFile("ClientApp/src/def/", assemblyNamespaces, singleTypes.Concat(entities).ToList());
    }

    private static void AddRateLimiting(IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<ClientRateLimitOptions>(configuration.GetSection("DocViewerRateLimiting"));

        services.AddSingleton<IMemoryCache, MemoryCache>();
        services.AddSingleton<IRateLimitCounterStore, MemoryCacheRateLimitCounterStore>();
        services.AddSingleton<IProcessingStrategy, AsyncKeyLockProcessingStrategy>();
        services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
        services.AddSingleton<IClientPolicyStore, MemoryCacheClientPolicyStore>();
        services.AddSingleton<IRateLimitConfiguration, RateLimitConfiguration>();
    }
}