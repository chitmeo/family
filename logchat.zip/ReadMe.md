# About

The Document Viewer is a secure way to access and view a repository of documents using access codes.

# First Time Setup

## Add your azure user and certificate to get shared npm packages:

- Make sure you have nodejs and npm installed: https://docs.npmjs.com/downloading-and-installing-node-js-and-npm
- Run `npm install -g vsts-npm-auth --registry https://registry.npmjs.com --always-auth false` to install the azure artifacts credential provider.
- In `ClientApp`, run `vsts-npm-auth -config .npmrc -TargetConfig ~/.npmrc` to log in to your azure account.
- Run `npm i`

## Add your azure user to get shared nuget packages:

- Install the credential provider
  - Save the powershell script:
    - https://github.com/microsoft/artifacts-credprovider/blob/master/helpers/installcredprovider.ps1
  - Run the script in powershell using this command
    - `iex "& { $(irm https://aka.ms/install-artifacts-credprovider.ps1) }"`
  - Run `dotnet restore --interactive`
    - If you get errors such as "can't find package"...
      - Delete the nuget.config
      - Run the command again
      - Restore the nuget.config
      - Run the command again.

## Setting up the database and EntityFramework

- You may need to install the tools globally if you have not done so already:
  - `dotnet tool install --global dotnet-ef`
- You must have a localdb to run this project
  - If you do not already have a localDB, run this: https://download.microsoft.com/download/7/c/1/7c14e92e-bdcb-4f89-b7cf-93543e7112d1/SqlLocalDB.msi

# Updating Your Database

```shell
dotnet ef database update
```

# Adding a migration (when you change schema)

```shell
dotnet ef migrations add <insertMigrationNameHere>
```

# Required Environment Variables

You can reach out to someone on the Hydra team for the values:

```
AZURE_AccessKey
AZURE_StorageAccountName
```

# To Run The Project

1. Hit F5 to run the project in debug mode
2. In your browser of choice, navigate to "https://localhost:5001/"
