﻿using Microsoft.Extensions.Logging;
using System;

namespace DocumentViewer.Extensions.Common;

public static class LogExtension
{
    public static void LogError(this ILogger logger, string actionName, string msg, Exception ex)
    {
        logger.LogError(ex, "[{ActionName}] - Error: {Message}", actionName, msg);
    }
}
