﻿using Microsoft.AspNetCore.Http;
using System;
using System.Linq;
using System.Security.Claims;

namespace DocumentViewer.Extensions.Common;

public static class HttpContextExtension
{
    public static Guid? GetContactId(this HttpContext httpContext)
    {
        ArgumentNullException.ThrowIfNull(httpContext);

        if (httpContext.User == null || httpContext.User.Identity == null)
            return null;

        if (httpContext.User.Identity is not ClaimsIdentity identity)
            return null;

        var idClaim = identity.Claims?.FirstOrDefault(c =>
            c.Type == "contactid" || c.Type == "https://wilsonacademy.com/contactId"
        );

        if (idClaim == null)
            return null;

        return Guid.TryParse(idClaim.Value, out var value) ? value : null;
    }
}
